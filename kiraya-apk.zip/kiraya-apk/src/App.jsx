import React from "react";
import { BrowserRouter as Router, Routes, Route, Navigate, Outlet } from "react-router-dom";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClientInstance } from "@/lib/query-client";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider, useAuth } from "@/lib/AuthContext";
import { CartProvider } from "@/context/CartContext";
import ScrollToTop from "@/components/ScrollToTop";

// Auth pages
import Login          from "@/pages/auth/Login";
import Register       from "@/pages/auth/Register";
import ForgotPassword from "@/pages/auth/ForgotPassword";
import CompleteProfile from "@/pages/auth/CompleteProfile";
import Terms          from "@/pages/auth/Terms";
import Privacy        from "@/pages/auth/Privacy";

// Customer
import CustomerLayout  from "@/components/customer/CustomerLayout";
import Home            from "@/pages/customer/Home";
import Explore         from "@/pages/customer/Explore";
import StoreDetail     from "@/pages/customer/StoreDetail";
import Cart            from "@/pages/customer/Cart";
import Checkout        from "@/pages/customer/Checkout";
import Orders          from "@/pages/customer/Orders";
import OrderTracking   from "@/pages/customer/OrderTracking";
import Profile         from "@/pages/customer/Profile";
import Notifications   from "@/pages/customer/Notifications";

// Store
import StoreLayout     from "@/components/store/StoreLayout";
import StoreDashboard  from "@/pages/store/Dashboard";
import StoreOrders     from "@/pages/store/Orders";
import StoreProducts   from "@/pages/store/Products";
import StoreInventory  from "@/pages/store/Inventory";
import StoreEarnings   from "@/pages/store/Earnings";
import StoreSettings   from "@/pages/store/Settings";

// Delivery
import DeliveryLayout  from "@/components/delivery/DeliveryLayout";
import DeliveryHome    from "@/pages/delivery/Home";
import ActiveDelivery  from "@/pages/delivery/ActiveDelivery";
import DeliveryEarnings from "@/pages/delivery/Earnings";
import DeliveryProfile from "@/pages/delivery/Profile";

// Admin
import AdminLayout     from "@/components/admin/AdminLayout";
import AdminDashboard  from "@/pages/admin/Dashboard";
import AdminOrders     from "@/pages/admin/Orders";
import AdminStores     from "@/pages/admin/Stores";
import AdminCustomers  from "@/pages/admin/Customers";
import AdminAnalytics  from "@/pages/admin/Analytics";

const Spinner = () => (
  <div className="fixed inset-0 grid place-items-center bg-background">
    <div className="w-9 h-9 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin" />
  </div>
);

// Requires login
function AuthGate() {
  const { loading, isAuthenticated } = useAuth();
  if (loading) return <Spinner />;
  if (!isAuthenticated) return <Navigate to="/login" replace />;
  return <Outlet />;
}

// Requires profile completion
function ProfileGate() {
  const { loading, profile } = useAuth();
  if (loading) return <Spinner />;
  if (!profile?.profile_complete) return <Navigate to="/complete-profile" replace />;
  return <Outlet />;
}

// Redirect logged-in users by role
function RoleRouter() {
  const { loading, profile } = useAuth();
  if (loading) return <Spinner />;
  const role = profile?.role || "customer";
  if (role === "admin")            return <Navigate to="/admin"    replace />;
  if (role === "store_owner")      return <Navigate to="/store"    replace />;
  if (role === "delivery_partner") return <Navigate to="/delivery" replace />;
  return <Navigate to="/home" replace />;
}

// Restrict by role
function RoleOnly({ allow }) {
  const { profile } = useAuth();
  if (!allow.includes(profile?.role)) return <Navigate to="/" replace />;
  return <Outlet />;
}

export default function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <CartProvider>
          <Router>
            <ScrollToTop />
            <Routes>
              {/* Public */}
              <Route path="/login"          element={<Login />} />
              <Route path="/register"       element={<Register />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/terms"          element={<Terms />} />
              <Route path="/privacy"        element={<Privacy />} />

              {/* Needs login but not complete profile */}
              <Route element={<AuthGate />}>
                <Route path="/complete-profile" element={<CompleteProfile />} />
              </Route>

              {/* Needs login + complete profile */}
              <Route element={<AuthGate />}>
                <Route element={<ProfileGate />}>
                  {/* Role-based redirect from "/" */}
                  <Route path="/" element={<RoleRouter />} />

                  {/* ── Customer ───────────────────────────── */}
                  <Route element={<RoleOnly allow={["customer"]} />}>
                    <Route element={<CustomerLayout />}>
                      <Route path="/home"              element={<Home />} />
                      <Route path="/explore"           element={<Explore />} />
                      <Route path="/store/:id"         element={<StoreDetail />} />
                      <Route path="/cart"              element={<Cart />} />
                      <Route path="/checkout"          element={<Checkout />} />
                      <Route path="/orders"            element={<Orders />} />
                      <Route path="/orders/:id"        element={<OrderTracking />} />
                      <Route path="/profile"           element={<Profile />} />
                      <Route path="/notifications"     element={<Notifications />} />
                    </Route>
                  </Route>

                  {/* ── Store owner ────────────────────────── */}
                  <Route element={<RoleOnly allow={["store_owner", "admin"]} />}>
                    <Route element={<StoreLayout />}>
                      <Route path="/store"             element={<StoreDashboard />} />
                      <Route path="/store/orders"      element={<StoreOrders />} />
                      <Route path="/store/products"    element={<StoreProducts />} />
                      <Route path="/store/inventory"   element={<StoreInventory />} />
                      <Route path="/store/earnings"    element={<StoreEarnings />} />
                      <Route path="/store/settings"    element={<StoreSettings />} />
                    </Route>
                  </Route>

                  {/* ── Delivery partner ───────────────────── */}
                  <Route element={<RoleOnly allow={["delivery_partner", "admin"]} />}>
                    <Route element={<DeliveryLayout />}>
                      <Route path="/delivery"          element={<DeliveryHome />} />
                      <Route path="/delivery/active"   element={<ActiveDelivery />} />
                      <Route path="/delivery/earnings" element={<DeliveryEarnings />} />
                      <Route path="/delivery/profile"  element={<DeliveryProfile />} />
                    </Route>
                  </Route>

                  {/* ── Admin ──────────────────────────────── */}
                  <Route element={<RoleOnly allow={["admin"]} />}>
                    <Route element={<AdminLayout />}>
                      <Route path="/admin"             element={<AdminDashboard />} />
                      <Route path="/admin/orders"      element={<AdminOrders />} />
                      <Route path="/admin/stores"      element={<AdminStores />} />
                      <Route path="/admin/customers"   element={<AdminCustomers />} />
                      <Route path="/admin/analytics"   element={<AdminAnalytics />} />
                    </Route>
                  </Route>
                </Route>
              </Route>

              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
            <Toaster />
          </Router>
        </CartProvider>
      </QueryClientProvider>
    </AuthProvider>
  );
}
