// Admin / store / delivery mock data. Same USE_MOCK_DATA switch as customer.
import { APP_CONFIG } from "@/lib/appConfig";

export const adminStats = [
  { key: "revenue", label: "Total Revenue", value: 482300, prefix: APP_CONFIG.currency, delta: "+12.4%", up: true },
  { key: "orders", label: "Today's Orders", value: 1284, delta: "+6.1%", up: true },
  { key: "activeDeliveries", label: "Active Deliveries", value: 96, delta: "+3", up: true },
  { key: "customers", label: "Active Customers", value: 8420, delta: "+182", up: true },
  { key: "stores", label: "Active Stores", value: 142, delta: "+4", up: true },
  { key: "partners", label: "Delivery Partners", value: 318, delta: "+8", up: true },
  { key: "pending", label: "Pending Orders", value: 37, delta: "—", up: null },
  { key: "cancelled", label: "Cancelled", value: 21, delta: "-4", up: false },
];

export const weeklyRevenue = [
  { day: "Mon", revenue: 54000, orders: 980 },
  { day: "Tue", revenue: 61000, orders: 1120 },
  { day: "Wed", revenue: 58500, orders: 1040 },
  { day: "Thu", revenue: 72000, orders: 1310 },
  { day: "Fri", revenue: 89000, orders: 1620 },
  { day: "Sat", revenue: 96000, orders: 1780 },
  { day: "Sun", revenue: 71500, orders: 1340 },
];

export const categoryShare = [
  { name: "Food", value: 38, color: "hsl(152 58% 38%)" },
  { name: "Grocery", value: 24, color: "hsl(142 60% 42%)" },
  { name: "Electronics", value: 12, color: "hsl(220 70% 52%)" },
  { name: "Beauty", value: 10, color: "hsl(280 60% 60%)" },
  { name: "Other", value: 16, color: "hsl(38 92% 50%)" },
];

export const adminOrders = [
  { id: "ORD-2041", customer: "Aarav Sharma", store: "Spice Route Kitchen", amount: 478, payment: "UPI", partner: "Vikram S.", status: "OUT_FOR_DELIVERY", time: "1:24 PM" },
  { id: "ORD-2042", customer: "Priya Meena", store: "FreshBasket Grocers", amount: 612, payment: "Card", partner: "Ramesh K.", status: "PREPARING", time: "1:31 PM" },
  { id: "ORD-2043", customer: "Rohit Gupta", store: "TechPoint Mobile", amount: 1899, payment: "UPI", partner: "—", status: "PENDING", time: "1:33 PM" },
  { id: "ORD-2038", customer: "Sneha Jain", store: "FreshBasket Grocers", amount: 381, payment: "COD", partner: "Imran A.", status: "DELIVERED", time: "12:10 PM" },
  { id: "ORD-2030", customer: "Kabir Singh", store: "Crust & Crumb Bakery", amount: 499, payment: "UPI", partner: "Vikram S.", status: "DELIVERED", time: "Aug 27" },
  { id: "ORD-2015", customer: "Nisha Rao", store: "TechPoint Mobile", amount: 1299, payment: "Wallet", partner: "—", status: "CANCELLED", time: "Aug 22" },
  { id: "ORD-2009", customer: "Aditya Verma", store: "Glow & Co. Beauty", amount: 698, payment: "Card", partner: "Ramesh K.", status: "READY", time: "11:45 AM" },
];

export const adminCustomers = [
  { id: "u1", name: "Aarav Sharma", phone: "+91 90000 00001", email: "aarav@example.com", orders: 24, spend: 18420, joined: "Jan 2026", status: "Active" },
  { id: "u2", name: "Priya Meena", phone: "+91 90000 00002", email: "priya@example.com", orders: 18, spend: 12380, joined: "Feb 2026", status: "Active" },
  { id: "u3", name: "Rohit Gupta", phone: "+91 90000 00003", email: "rohit@example.com", orders: 9, spend: 6240, joined: "Mar 2026", status: "Active" },
  { id: "u4", name: "Sneha Jain", phone: "+91 90000 00004", email: "sneha@example.com", orders: 31, spend: 24190, joined: "Dec 2025", status: "VIP" },
  { id: "u5", name: "Kabir Singh", phone: "+91 90000 00005", email: "kabir@example.com", orders: 3, spend: 1620, joined: "Aug 2026", status: "New" },
];

export const adminPartners = [
  { id: "d1", name: "Vikram S.", vehicle: "Bike", status: "On delivery", active: 1, completed: 412, earnings: 18420, rating: 4.8, online: true },
  { id: "d2", name: "Ramesh K.", vehicle: "Bike", status: "On delivery", active: 1, completed: 388, earnings: 16940, rating: 4.7, online: true },
  { id: "d3", name: "Imran A.", vehicle: "Scooter", status: "Available", active: 0, completed: 510, earnings: 22100, rating: 4.9, online: true },
  { id: "d4", name: "Suresh P.", vehicle: "Bike", status: "Offline", active: 0, completed: 276, earnings: 11280, rating: 4.5, online: false },
];

// ---- Store owner data ----
export const storeStats = [
  { key: "sales", label: "Today's Sales", value: 18420, prefix: APP_CONFIG.currency, delta: "+9.2%", up: true },
  { key: "pending", label: "Pending Orders", value: 7, delta: "—", up: null },
  { key: "completed", label: "Completed Today", value: 42, delta: "+5", up: true },
  { key: "prepTime", label: "Avg Prep Time", value: 18, suffix: " min", delta: "-2 min", up: true },
];

export const storeOrders = [
  { id: "ORD-2042", customer: "Priya Meena", items: 3, amount: 612, status: "PREPARING", time: "1:31 PM", payment: "Card" },
  { id: "ORD-2044", customer: "Rahul D.", items: 2, amount: 358, status: "NEW", time: "1:40 PM", payment: "UPI" },
  { id: "ORD-2045", customer: "Meera T.", items: 1, amount: 499, status: "READY", time: "1:42 PM", payment: "UPI" },
  { id: "ORD-2038", customer: "Sneha Jain", items: 4, amount: 381, status: "COMPLETED", time: "12:10 PM", payment: "COD" },
  { id: "ORD-2036", customer: "Aditya V.", items: 2, amount: 698, status: "CANCELLED", time: "11:30 AM", payment: "Card" },
];

export const storeInventory = [
  { id: "p2", name: "Veg Biryani", stock: 24, status: "ok" },
  { id: "p1", name: "Paneer Butter Masala", stock: 8, status: "low" },
  { id: "p3", name: "Garlic Naan (2 pc)", stock: 60, status: "ok" },
  { id: "p9", name: "Amul Gold Milk 1L", stock: 0, status: "out" },
  { id: "p18", name: "Choco Chip Cookies", stock: 14, status: "low" },
];

export const storeProducts = [
  { id: "p1", name: "Paneer Butter Masala", price: 220, mrp: 260, stock: 8, available: true, category: "food" },
  { id: "p2", name: "Veg Biryani", price: 189, mrp: 220, stock: 24, available: true, category: "food" },
  { id: "p3", name: "Garlic Naan (2 pc)", price: 69, mrp: 80, stock: 60, available: true, category: "food" },
  { id: "p4", name: "Aloo Paratha", price: 79, mrp: 90, stock: 0, available: false, category: "food" },
];

// ---- Delivery partner data ----
export const deliveryStats = [
  { key: "today", label: "Today's Earnings", value: 1240, prefix: APP_CONFIG.currency, delta: "+₹320", up: true },
  { key: "week", label: "This Week", value: 8960, prefix: APP_CONFIG.currency, delta: "+12", up: true },
  { key: "completed", label: "Completed", value: 34, delta: "+5", up: true },
  { key: "rating", label: "Rating", value: 4.8, delta: "—", up: null },
];

export const deliveryRequests = [
  { id: "ORD-2043", store: "TechPoint Mobile", pickup: "C Scheme", drop: "Malviya Nagar", distance: "3.4 km", eta: "12 min", earnings: 48, size: "Small" },
  { id: "ORD-2046", store: "FreshBasket Grocers", pickup: "Vidhyadhar Nagar", drop: "Vaishali Nagar", distance: "2.1 km", eta: "9 min", earnings: 35, size: "Medium" },
  { id: "ORD-2047", store: "Crust & Crumb Bakery", pickup: "Raja Park", drop: "Civil Lines", distance: "1.8 km", eta: "8 min", earnings: 30, size: "Small" },
];

export const activeDelivery = {
  id: "ORD-2041",
  store: "Spice Route Kitchen",
  storeAddr: "Shop 12, C Scheme, Jaipur",
  customer: "Aarav Sharma",
  customerAddr: "Flat 302, Amber Residency, Vidhyadhar Nagar",
  customerPhone: "+91 90000 00001",
  distance: "1.2 km",
  eta: "8 min",
  earnings: 42,
  items: ["Paneer Butter Masala", "Veg Biryani", "Garlic Naan (2 pc)"],
  total: 478,
  stage: "PICKED_UP",
};

export const payoutHistory = [
  { id: "w1", week: "Aug 25–31", amount: 8960, status: "Pending" },
  { id: "w2", week: "Aug 18–24", amount: 7240, status: "Paid" },
  { id: "w3", week: "Aug 11–17", amount: 6810, status: "Paid" },
];