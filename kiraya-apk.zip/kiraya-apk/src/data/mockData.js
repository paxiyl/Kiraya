// Mock data — Indian names & pricing. Separated from Firebase layer.
// Flip APP_CONFIG.USE_MOCK_DATA to false to switch to real Firestore data.
import {
  Apple, Carrot, Pill, Sparkles, Smartphone, Shirt, Home as HomeIcon,
  Cake, Gift, BookOpen, PawPrint, Store, UtensilsCrossed, Leaf,
} from "lucide-react";

export const categories = [
  { id: "food", name: "Food", icon: UtensilsCrossed, tint: "152 58% 38%" },
  { id: "grocery", name: "Grocery", icon: Leaf, tint: "142 60% 42%" },
  { id: "veg", name: "Fruits & Veg", icon: Carrot, tint: "20 90% 56%" },
  { id: "pharmacy", name: "Pharmacy", icon: Pill, tint: "210 70% 56%" },
  { id: "beauty", name: "Beauty", icon: Sparkles, tint: "280 60% 60%" },
  { id: "electronics", name: "Electronics", icon: Smartphone, tint: "220 70% 52%" },
  { id: "fashion", name: "Fashion", icon: Shirt, tint: "340 70% 58%" },
  { id: "home", name: "Home", icon: HomeIcon, tint: "30 80% 54%" },
  { id: "bakery", name: "Bakery", icon: Cake, tint: "40 90% 56%" },
  { id: "gifts", name: "Gifts", icon: Gift, tint: "12 76% 60%" },
  { id: "stationery", name: "Stationery", icon: BookOpen, tint: "200 60% 48%" },
  { id: "pets", name: "Pets", icon: PawPrint, tint: "160 60% 44%" },
  { id: "more", name: "More", icon: Store, tint: "220 8% 50%" },
];

export const stores = [
  { id: "s1", name: "Spice Route Kitchen", type: "restaurant", tag: "North Indian • Chinese", rating: 4.6, eta: "25-35 min", fee: 29, distance: "1.2 km", offer: "20% OFF up to ₹100", open: true, busy: false, image: null, category: "food" },
  { id: "s2", name: "FreshBasket Grocers", type: "store", tag: "Grocery • Daily needs", rating: 4.7, eta: "15-25 min", fee: 19, distance: "0.8 km", offer: "Free delivery over ₹299", open: true, busy: false, image: null, category: "grocery" },
  { id: "s3", name: "Glow & Co. Beauty", type: "store", tag: "Cosmetics • Skincare", rating: 4.5, eta: "30-45 min", fee: 25, distance: "2.1 km", offer: "Buy 1 Get 1", open: true, busy: true, image: null, category: "beauty" },
  { id: "s4", name: "TechPoint Mobile", type: "store", tag: "Electronics • Accessories", rating: 4.4, eta: "40-60 min", fee: 39, distance: "3.4 km", offer: "10% OFF on accessories", open: true, busy: false, image: null, category: "electronics" },
  { id: "s5", name: "Daily Mart", type: "store", tag: "Home essentials", rating: 4.3, eta: "30-50 min", fee: 29, distance: "1.9 km", offer: null, open: false, busy: false, image: null, category: "home" },
  { id: "s6", name: "Crust & Crumb Bakery", type: "restaurant", tag: "Bakery • Desserts", rating: 4.8, eta: "20-30 min", fee: 25, distance: "1.5 km", offer: "₹50 OFF over ₹399", open: true, busy: false, image: null, category: "bakery" },
  { id: "s7", name: "Green Leaf Veggies", type: "store", tag: "Fresh produce", rating: 4.6, eta: "15-25 min", fee: 15, distance: "0.6 km", offer: "Free delivery", open: true, busy: false, image: null, category: "veg" },
  { id: "s8", name: "MediPlus Pharmacy", type: "store", tag: "Pharmacy • Wellness", rating: 4.7, eta: "25-40 min", fee: 0, distance: "1.1 km", offer: "Free delivery on medicines", open: true, busy: false, image: null, category: "pharmacy" },
];

const p = (id, name, storeId, storeName, price, mrp, rating, eta, category, badge) => ({
  id, name, storeId, storeName, price, mrp, rating, eta, category, badge, image: null,
});

export const products = [
  p("p1", "Paneer Butter Masala", "s1", "Spice Route Kitchen", 220, 260, 4.5, "25-35 min", "food", "Bestseller"),
  p("p2", "Veg Biryani", "s1", "Spice Route Kitchen", 189, 220, 4.6, "25-35 min", "food", null),
  p("p3", "Garlic Naan (2 pc)", "s1", "Spice Route Kitchen", 69, 80, 4.4, "25-35 min", "food", null),
  p("p4", "Aloo Paratha", "s1", "Spice Route Kitchen", 79, 90, 4.3, "25-35 min", "food", null),
  p("p5", "Farm Fresh Tomatoes 1kg", "s7", "Green Leaf Veggies", 39, 60, 4.5, "15-25 min", "veg", "20% OFF"),
  p("p6", "Bananas 1 Dozen", "s7", "Green Leaf Veggies", 49, 60, 4.6, "15-25 min", "veg", null),
  p("p7", "Onions 2kg", "s7", "Green Leaf Veggies", 64, 80, 4.4, "15-25 min", "veg", null),
  p("p8", "Aashirvaad Atta 5kg", "s2", "FreshBasket Grocers", 279, 320, 4.7, "15-25 min", "grocery", "Deal"),
  p("p9", "Amul Gold Milk 1L", "s2", "FreshBasket Grocers", 74, 78, 4.8, "15-25 min", "grocery", null),
  p("p10", "Tata Salt 1kg", "s2", "FreshBasket Grocers", 28, 30, 4.6, "15-25 min", "grocery", null),
  p("p11", "Lakmé Sunscreen SPF50", "s3", "Glow & Co. Beauty", 399, 599, 4.4, "30-45 min", "beauty", "33% OFF"),
  p("p12", "Matte Lipstick - Berry", "s3", "Glow & Co. Beauty", 299, 399, 4.5, "30-45 min", "beauty", null),
  p("p13", "USB-C Fast Charger 25W", "s4", "TechPoint Mobile", 599, 899, 4.3, "40-60 min", "electronics", "33% OFF"),
  p("p14", "Wireless Earbuds Pro", "s4", "TechPoint Mobile", 1299, 1999, 4.4, "40-60 min", "electronics", "Bestseller"),
  p("p15", "Phone Case (Soft)", "s4", "TechPoint Mobile", 199, 299, 4.2, "40-60 min", "electronics", null),
  p("p16", "Premium Detergent 2kg", "s5", "Daily Mart", 349, 399, 4.3, "30-50 min", "home", null),
  p("p17", "Floor Cleaner 1L", "s5", "Daily Mart", 149, 175, 4.2, "30-50 min", "home", null),
  p("p18", "Choco Chip Cookies", "s6", "Crust & Crumb Bakery", 129, 149, 4.7, "20-30 min", "bakery", "Bestseller"),
  p("p19", "Butter Croissant", "s6", "Crust & Crumb Bakery", 89, 99, 4.6, "20-30 min", "bakery", null),
  p("p20", "Chocolate Truffle Cake 500g", "s6", "Crust & Crumb Bakery", 499, 599, 4.8, "20-30 min", "bakery", "₹100 OFF"),
  p("p21", "Paracetamol 500mg (15)", "s8", "MediPlus Pharmacy", 35, 40, 4.6, "25-40 min", "pharmacy", null),
  p("p22", "Vitamin C Tablets 30", "s8", "MediPlus Pharmacy", 249, 299, 4.5, "25-40 min", "pharmacy", null),
];

export const coupons = [
  { code: "WELCOME100", title: "₹100 OFF", desc: "Minimum order ₹499", expiry: "Expires tomorrow", type: "flat", value: 100, min: 499 },
  { code: "FRESH20", title: "20% OFF", desc: "Up to ₹120 on groceries", expiry: "Valid this week", type: "pct", value: 20, max: 120, min: 199 },
  { code: "FREEDEL", title: "Free Delivery", desc: "On orders above ₹299", expiry: "Limited time", type: "delivery", min: 299 },
];

export const orders = [
  { id: "ORD-2041", storeId: "s1", store: "Spice Route Kitchen", items: ["Paneer Butter Masala", "Veg Biryani", "Garlic Naan (2 pc)"], total: 478, date: "Today, 1:24 PM", status: "OUT_FOR_DELIVERY", eta: "Arriving in 8 min", partner: { name: "Vikram S.", phone: "+91 90000 12345", rating: 4.8 } },
  { id: "ORD-2038", storeId: "s2", store: "FreshBasket Grocers", items: ["Aashirvaad Atta 5kg", "Amul Gold Milk 1L", "Tata Salt 1kg"], total: 381, date: "Yesterday, 7:10 PM", status: "DELIVERED", eta: "Delivered", partner: null },
  { id: "ORD-2030", storeId: "s6", store: "Crust & Crumb Bakery", items: ["Chocolate Truffle Cake 500g"], total: 499, date: "Aug 27, 5:45 PM", status: "DELIVERED", eta: "Delivered", partner: null },
  { id: "ORD-2015", storeId: "s4", store: "TechPoint Mobile", items: ["Wireless Earbuds Pro"], total: 1299, date: "Aug 22, 3:20 PM", status: "CANCELLED", eta: "Cancelled", partner: null },
];

export const notifications = [
  { id: "n1", icon: "package", title: "Order #ORD-2041 is on the way", desc: "Vikram will arrive in ~8 min", time: "2m ago", unread: true, tone: "accent" },
  { id: "n2", icon: "tag", title: "FRESH20 applied to your cart", desc: "You saved ₹84 on groceries", time: "1h ago", unread: true, tone: "success" },
  { id: "n3", icon: "sparkles", title: "New stores near you", desc: "3 new local shops opened in Jaipur", time: "5h ago", unread: false, tone: "neutral" },
  { id: "n4", icon: "gift", title: "₹100 OFF just for you", desc: "Code WELCOME100 expires tomorrow", time: "1d ago", unread: false, tone: "warning" },
];

export const addresses = [
  { id: "a1", label: "Home", line: "Flat 302, Amber Residency, Vidhyadhar Nagar", city: "Jaipur", state: "Rajasthan", pin: "302039", phone: "+91 90000 00000", default: true },
  { id: "a2", label: "Work", line: "4th Floor, Tech Park, Malviya Nagar", city: "Jaipur", state: "Rajasthan", pin: "302017", phone: "+91 90000 00000", default: false },
];

export const getProduct = (id) => products.find((x) => x.id === id);
export const getStore = (id) => stores.find((x) => x.id === id);
export const productsByStore = (storeId) => products.filter((x) => x.storeId === storeId);
export const quickProducts = () => products.filter((x) => x.eta && /15-25|20-30/.test(x.eta));
export const byCategory = (cat) => products.filter((x) => x.category === cat);