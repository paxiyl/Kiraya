import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Loader2, LogIn } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { signInEmail, signInGoogle } from "@/lib/db";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [gLoading, setGLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    const { error: err } = await signInEmail(email, password);
    setLoading(false);
    if (err) { setError(friendly(err.message)); return; }
    navigate("/");
  };

  const googleLogin = async () => {
    setError(""); setGLoading(true);
    const { error: err } = await signInGoogle();
    setGLoading(false);
    if (err) setError(err.message);
  };

  return (
    <AuthLayout icon={LogIn} title="Welcome back" subtitle="Log in to your account"
      footer={<>Don't have an account? <Link to="/register" className="text-primary font-medium hover:underline">Sign up</Link></>}>

      <button onClick={googleLogin} disabled={gLoading}
        className="press w-full h-12 rounded-2xl border border-[hsl(var(--border))] flex items-center justify-center gap-2 text-sm font-medium mb-5">
        {gLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <GoogleIcon className="w-5 h-5" />}
        Continue with Google
      </button>

      <div className="relative mb-5">
        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[hsl(var(--border))]" /></div>
        <div className="relative flex justify-center text-xs"><span className="bg-card px-3 text-[hsl(var(--text-tertiary))] uppercase">or</span></div>
      </div>

      {error && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm">{error}</div>}

      <form onSubmit={submit} className="space-y-4">
        <Field icon={Mail} type="email" placeholder="you@example.com" value={email} onChange={setEmail} autoComplete="email" required />
        <Field icon={Lock} type="password" placeholder="••••••••" value={password} onChange={setPassword} autoComplete="current-password" required />
        <div className="text-right"><Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</Link></div>
        <button type="submit" disabled={loading} className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Log in"}
        </button>
      </form>
    </AuthLayout>
  );
}

function Field({ icon: Icon, ...props }) {
  const { onChange, ...rest } = props;
  return (
    <div className="relative">
      <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
      <input {...rest} onChange={e => onChange(e.target.value)} className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
    </div>
  );
}

const friendly = (msg = "") => {
  if (msg.includes("Invalid login")) return "Invalid email or password.";
  if (msg.includes("Email not confirmed")) return "Please verify your email first.";
  if (msg.includes("Too many")) return "Too many attempts. Try again later.";
  return msg || "Something went wrong.";
};
