import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, Loader2, LogIn } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import { signInEmail } from "@/lib/db";

export default function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError(""); setLoading(true);
    const { error: err } = await signInEmail(email, password);
    setLoading(false);
    if (err) { setError(friendly(err.message)); return; }
    navigate("/");
  };

  return (
    <AuthLayout icon={LogIn} title="Welcome back" subtitle="Log in to your account"
      footer={<>Don't have an account? <Link to="/register" className="text-primary font-medium hover:underline">Sign up</Link></>}>

      {error && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm">{error}</div>}

      <form onSubmit={submit} className="space-y-4">
        <div>
          <label className="text-xs text-[hsl(var(--text-tertiary))]">Email</label>
          <div className="relative mt-1">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            <input type="email" required autoComplete="email" placeholder="you@example.com"
              value={email} onChange={e => setEmail(e.target.value)}
              className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
          </div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs text-[hsl(var(--text-tertiary))]">Password</label>
            <Link to="/forgot-password" className="text-xs text-primary hover:underline">Forgot password?</Link>
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            <input type="password" required autoComplete="current-password" placeholder="••••••••"
              value={password} onChange={e => setPassword(e.target.value)}
              className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
          </div>
        </div>

        <button type="submit" disabled={loading}
          className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60 flex items-center justify-center gap-2">
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" />Logging in…</> : "Log in"}
        </button>
      </form>
    </AuthLayout>
  );
}

const friendly = (msg = "") => {
  if (msg.includes("Invalid login")) return "Invalid email or password.";
  if (msg.includes("Email not confirmed")) return "Please verify your email first.";
  if (msg.includes("Too many")) return "Too many attempts. Try again later.";
  return msg || "Something went wrong.";
};
