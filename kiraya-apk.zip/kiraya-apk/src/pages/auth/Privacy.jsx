import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Lock } from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-background px-5 py-8">
      <div className="max-w-2xl mx-auto">
        <Link to="/register" className="press inline-flex items-center gap-2 text-sm text-[hsl(var(--text-secondary))] mb-6">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <div className="flex items-center gap-3 mb-6">
          <Lock className="w-6 h-6 text-[hsl(var(--accent))]" />
          <h1 className="text-2xl font-bold">Privacy Policy</h1>
        </div>
        <p className="text-xs text-[hsl(var(--text-tertiary))] mb-6">Last updated: September 2026</p>

        <div className="space-y-6 text-sm text-[hsl(var(--text-secondary))] leading-relaxed">
          {[
            ["1. Information We Collect", `When you use ${APP_CONFIG.name}, we collect: your name, email, phone number, and delivery address; order history and payment information; device information and usage data; location data (for delivery tracking, with your permission).`],
            ["2. How We Use Your Data", "We use your data to: process and deliver your orders; send order updates and notifications; improve our platform and personalise your experience; communicate about promotions (with your consent); comply with legal obligations."],
            ["3. Data Sharing", "We share your data with: stores (to fulfil your order); delivery partners (your name, phone, and delivery address); payment processors; legal authorities when required by law. We do not sell your personal data to third parties."],
            ["4. Data Storage", "Your data is stored securely using Supabase infrastructure with encryption at rest and in transit. We retain your data for as long as your account is active and for up to 3 years after deletion for legal compliance."],
            ["5. Your Rights", "You have the right to: access your personal data; correct inaccurate data; request deletion of your account and data; withdraw consent for marketing communications; file a complaint with the relevant data protection authority."],
            ["6. Cookies", "We use essential cookies to keep you logged in and remember your preferences. We do not use advertising or tracking cookies."],
            ["7. Children's Privacy", `${APP_CONFIG.name} is not intended for children under 18. We do not knowingly collect data from minors.`],
            ["8. Security", "We implement industry-standard security measures including HTTPS encryption, secure authentication, and regular security audits. However, no system is completely secure and we cannot guarantee absolute security."],
            ["9. Changes to This Policy", "We may update this policy and will notify you via email or in-app notification. Continued use after changes means you accept the updated policy."],
            ["10. Contact Us", `For privacy-related requests or concerns, email us at ${APP_CONFIG.supportEmail} or write to us at ${APP_CONFIG.city}, Rajasthan, India.`],
          ].map(([title, body]) => (
            <div key={title}>
              <h2 className="font-semibold text-[hsl(var(--text-primary))] mb-1">{title}</h2>
              <p>{body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
