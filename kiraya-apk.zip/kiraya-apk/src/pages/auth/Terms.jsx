import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Shield } from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";

export default function Terms() {
  return (
    <div className="min-h-screen bg-background px-5 py-8">
      <div className="max-w-2xl mx-auto">
        <Link to="/register" className="press inline-flex items-center gap-2 text-sm text-[hsl(var(--text-secondary))] mb-6">
          <ArrowLeft className="w-4 h-4" /> Back
        </Link>
        <div className="flex items-center gap-3 mb-6">
          <Shield className="w-6 h-6 text-[hsl(var(--accent))]" />
          <h1 className="text-2xl font-bold">Terms of Service</h1>
        </div>
        <p className="text-xs text-[hsl(var(--text-tertiary))] mb-6">Last updated: September 2026</p>

        <div className="space-y-6 text-sm text-[hsl(var(--text-secondary))] leading-relaxed">
          {[
            ["1. Acceptance", `By creating an account on ${APP_CONFIG.name}, you agree to be bound by these Terms of Service. If you do not agree, please do not use our services. These terms apply to all users including customers, store owners, and delivery partners.`],
            ["2. Our Service", `${APP_CONFIG.name} is a hyperlocal delivery platform that connects customers with local stores and independent delivery partners in ${APP_CONFIG.city}. We act as an intermediary and are not responsible for the quality of products sold by stores.`],
            ["3. User Accounts", "You must provide accurate information when creating your account. You are responsible for maintaining the confidentiality of your account credentials. You must be at least 18 years old to use this service. One person may not maintain more than one account."],
            ["4. Store Owners", "Store owners are responsible for the accuracy of their listings, pricing, and product availability. Stores must comply with all applicable food safety and business laws. Kiraya reserves the right to remove any listing that violates our policies or applicable law."],
            ["5. Delivery Partners", "Delivery partners are independent contractors, not employees of Kiraya. Partners must hold a valid driving licence and vehicle registration. Partners are responsible for safe and timely delivery of orders. Kiraya may deactivate partner accounts for violations of conduct standards."],
            ["6. Orders & Payments", "Orders placed through the platform are binding contracts between the customer and the store. Kiraya facilitates payment collection on behalf of stores. Prices displayed include applicable taxes. Delivery fees are shown before order confirmation."],
            ["7. Cancellations & Refunds", "Customers may cancel orders before the store accepts them. Refunds for eligible cancellations or incorrect orders will be processed within 5–7 business days. Kiraya's decision on disputes is final."],
            ["8. Prohibited Conduct", "You agree not to: use the platform for illegal purposes, submit false information, harass other users, attempt to circumvent our systems, or engage in fraudulent transactions."],
            ["9. Limitation of Liability", `${APP_CONFIG.name} is not liable for any indirect, incidental, or consequential damages arising from your use of the platform. Our maximum liability is limited to the value of the transaction in question.`],
            ["10. Changes to Terms", "We may update these terms at any time. We will notify users of significant changes via email or in-app notification. Continued use of the platform after changes constitutes acceptance of the new terms."],
            ["11. Governing Law", "These terms are governed by the laws of India. Any disputes shall be subject to the exclusive jurisdiction of courts in Jaipur, Rajasthan."],
            ["12. Contact", `For questions about these terms, contact us at ${APP_CONFIG.supportEmail} or call ${APP_CONFIG.supportPhone}.`],
          ].map(([title, body]) => (
            <div key={title}>
              <h2 className="font-semibold text-[hsl(var(--text-primary))] mb-1">{title}</h2>
              <p>{body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
