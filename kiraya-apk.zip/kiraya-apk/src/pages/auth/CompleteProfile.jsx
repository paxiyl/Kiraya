import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Phone, MapPin, Loader2, ChevronRight } from "lucide-react";
import { upsertProfile } from "@/lib/db";
import { useAuth } from "@/lib/AuthContext";
import { APP_CONFIG } from "@/lib/appConfig";

const ROLES = [
  { id: "customer", label: "Customer", desc: "Order from local stores", emoji: "🛍️" },
  { id: "store_owner", label: "Store Owner", desc: "List and manage my store", emoji: "🏪" },
  { id: "delivery_partner", label: "Delivery Partner", desc: "Deliver orders and earn", emoji: "🚴" },
];

export default function CompleteProfile() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState(0); // 0=role, 1=details, 2=address
  const [role, setRole] = useState("");
  const [name, setName] = useState(user?.user_metadata?.full_name || "");
  const [phone, setPhone] = useState("");
  const [addressLine, setAddressLine] = useState("");
  const [city, setCity] = useState(APP_CONFIG.city);
  const [pin, setPin] = useState("");
  const [vehicle, setVehicle] = useState("");
  const [vehicleNo, setVehicleNo] = useState("");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  const finish = async () => {
    if (!name.trim()) { setError("Please enter your name."); return; }
    setSaving(true);
    try {
      await upsertProfile(user.id, {
        display_name: name.trim(),
        phone,
        role,
        vehicle_type: vehicle,
        vehicle_number: vehicleNo,
        address: { line: addressLine, city, pin },
        agreed_terms: true,
        profile_complete: true,
      });
      await refreshProfile();
      navigate("/");
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen bg-background flex flex-col px-5 py-10">
      <div className="mb-8">
        <p className="text-xs text-[hsl(var(--text-tertiary))] mb-1">Step {step + 1} of 3</p>
        <div className="flex gap-1.5">
          {[0,1,2].map(i => <div key={i} className={`flex-1 h-1.5 rounded-full transition-colors ${i <= step ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--muted))]"}`} />)}
        </div>
      </div>

      {error && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm">{error}</div>}

      {/* Step 0 — Pick role */}
      {step === 0 && (
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-2xl font-bold">How will you use {APP_CONFIG.name}?</h1>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">Choose your role. You can contact support to change it later.</p>
          </div>
          <div className="space-y-3 mt-6">
            {ROLES.map(r => (
              <button key={r.id} onClick={() => setRole(r.id)}
                className={`press w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-colors text-left ${role === r.id ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-[hsl(var(--border))]"}`}>
                <span className="text-3xl">{r.emoji}</span>
                <div>
                  <p className="font-semibold text-sm">{r.label}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{r.desc}</p>
                </div>
                {role === r.id && <ChevronRight className="w-4 h-4 text-[hsl(var(--accent))] ml-auto" />}
              </button>
            ))}
          </div>
          <button onClick={() => { if (!role) { setError("Please pick a role."); return; } setError(""); setStep(1); }}
            disabled={!role} className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold mt-6 disabled:opacity-50">
            Continue
          </button>
        </div>
      )}

      {/* Step 1 — Personal details */}
      {step === 1 && (
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-2xl font-bold">Your details</h1>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">This is how stores and delivery partners will know you.</p>
          </div>
          <div className="space-y-3 mt-4">
            <InputField icon={User} label="Full name" placeholder="Your full name" value={name} onChange={setName} />
            <InputField icon={Phone} label="Phone number" placeholder="+91 9XXXXXXXXX" value={phone} onChange={setPhone} type="tel" />
            {role === "delivery_partner" && (
              <>
                <div>
                  <label className="text-xs text-[hsl(var(--text-tertiary))]">Vehicle type</label>
                  <select value={vehicle} onChange={e => setVehicle(e.target.value)}
                    className="w-full mt-1 h-12 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]">
                    <option value="">Select vehicle</option>
                    {["Bicycle","Motorcycle","Scooter","Auto","Car"].map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <InputField label="Vehicle number" placeholder="RJ14 XX 1234" value={vehicleNo} onChange={setVehicleNo} />
              </>
            )}
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setStep(0)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={() => { if (!name.trim() || !phone) { setError("Please fill all fields."); return; } setError(""); setStep(2); }}
              className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold">Continue</button>
          </div>
        </div>
      )}

      {/* Step 2 — Address */}
      {step === 2 && (
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-2xl font-bold">Your address</h1>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">Used for delivery and store setup. You can update this anytime.</p>
          </div>
          <div className="space-y-3 mt-4">
            <InputField icon={MapPin} label="Street / flat / area" placeholder="Flat 302, MG Road…" value={addressLine} onChange={setAddressLine} />
            <InputField label="City" placeholder="Jaipur" value={city} onChange={setCity} />
            <InputField label="PIN code" placeholder="302001" value={pin} onChange={setPin} type="number" />
          </div>
          <div className="flex gap-3 mt-6">
            <button onClick={() => setStep(1)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={finish} disabled={saving}
              className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60">
              {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Finish setup"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function InputField({ icon: Icon, label, ...props }) {
  const { onChange, ...rest } = props;
  return (
    <div>
      {label && <label className="text-xs text-[hsl(var(--text-tertiary))]">{label}</label>}
      <div className="relative mt-1">
        {Icon && <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />}
        <input {...rest} onChange={e => onChange(e.target.value)}
          className={`w-full h-12 ${Icon ? "pl-10" : "pl-3"} pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]`} />
      </div>
    </div>
  );
}
