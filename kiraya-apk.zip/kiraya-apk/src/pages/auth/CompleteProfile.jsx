import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { User, Phone, Loader2, ChevronRight, MapPin } from "lucide-react";
import { upsertProfile } from "@/lib/db";
import { useAuth } from "@/lib/AuthContext";
import { APP_CONFIG } from "@/lib/appConfig";
import MapPicker from "@/components/MapPicker";

const ROLES = [
  { id: "customer",         label: "Customer",          desc: "Order from local stores",    emoji: "🛍️" },
  { id: "store_owner",      label: "Store Owner",       desc: "List and manage my store",   emoji: "🏪" },
  { id: "delivery_partner", label: "Delivery Partner",  desc: "Deliver orders and earn",     emoji: "🚴" },
];

const VEHICLES = ["Bicycle", "Motorcycle", "Scooter", "Auto", "Car"];

export default function CompleteProfile() {
  const { user, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [step, setStep]       = useState(0);
  const [role, setRole]       = useState("");
  const [name, setName]       = useState(user?.user_metadata?.full_name || "");
  const [phone, setPhone]     = useState("");
  const [phoneError, setPhoneError] = useState("");
  const [vehicle, setVehicle]     = useState("");
  const [vehicleNo, setVehicleNo] = useState("");
  const [mapOpen, setMapOpen] = useState(false);
  const [location, setLocation] = useState(null); // { lat, lng, line }
  const [pin, setPin]         = useState("");
  const [saving, setSaving]   = useState(false);
  const [error, setError]     = useState("");

  const validatePhone = (val) => {
    const digits = val.replace(/\D/g, "");
    if (digits.length > 0 && digits.length !== 10) return "Phone number must be exactly 10 digits";
    if (digits.length === 10 && !/^[6-9]/.test(digits)) return "Must start with 6, 7, 8 or 9";
    return "";
  };

  const handlePhone = (val) => {
    const digits = val.replace(/\D/g, "").slice(0, 10);
    setPhone(digits);
    setPhoneError(validatePhone(digits));
  };

  const finish = async () => {
    const pErr = validatePhone(phone);
    if (pErr) { setError(pErr); return; }
    if (!name.trim()) { setError("Please enter your name."); return; }
    if (!location) { setError("Please select your delivery address on the map."); return; }
    if (!pin || pin.length !== 6) { setError("Please enter a valid 6-digit PIN code."); return; }

    setSaving(true);
    try {
      await upsertProfile(user.id, {
        display_name:   name.trim(),
        phone:          `+91${phone}`,
        role,
        vehicle_type:   vehicle,
        vehicle_number: vehicleNo,
        address: {
          line: location.line,
          city: "Hindaun City",
          pin,
          lat:  location.lat,
          lng:  location.lng,
        },
        agreed_terms:     true,
        profile_complete: true,
      });
      await refreshProfile();
      navigate("/");
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  if (mapOpen) {
    return (
      <MapPicker
        initial={location}
        onSelect={(loc) => { setLocation(loc); setMapOpen(false); }}
        onClose={() => setMapOpen(false)}
      />
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col px-5 py-10">
      {/* Progress */}
      <div className="mb-8">
        <p className="text-xs text-[hsl(var(--text-tertiary))] mb-1">Step {step + 1} of 3</p>
        <div className="flex gap-1.5">
          {[0,1,2].map(i => (
            <div key={i} className={`flex-1 h-1.5 rounded-full transition-colors ${i <= step ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--muted))]"}`} />
          ))}
        </div>
      </div>

      {error && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm">{error}</div>}

      {/* Step 0 — Role */}
      {step === 0 && (
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-2xl font-bold">How will you use {APP_CONFIG.name}?</h1>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">Choose your role.</p>
          </div>
          <div className="space-y-3 mt-4">
            {ROLES.map(r => (
              <button key={r.id} onClick={() => setRole(r.id)}
                className={`press w-full flex items-center gap-4 p-4 rounded-2xl border-2 transition-colors text-left
                  ${role === r.id ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-[hsl(var(--border))]"}`}>
                <span className="text-3xl">{r.emoji}</span>
                <div>
                  <p className="font-semibold text-sm">{r.label}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{r.desc}</p>
                </div>
                {role === r.id && <ChevronRight className="w-4 h-4 text-[hsl(var(--accent))] ml-auto" />}
              </button>
            ))}
          </div>
          <button onClick={() => { if (!role) { setError("Please pick a role."); return; } setError(""); setStep(1); }}
            disabled={!role}
            className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold mt-4 disabled:opacity-50">
            Continue
          </button>
        </div>
      )}

      {/* Step 1 — Personal details */}
      {step === 1 && (
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-2xl font-bold">Your details</h1>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">Tell us about yourself.</p>
          </div>
          <div className="space-y-3 mt-2">
            <div>
              <label className="text-xs text-[hsl(var(--text-tertiary))]">Full name</label>
              <div className="relative mt-1">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
                <input type="text" placeholder="Your full name" value={name} onChange={e => setName(e.target.value)}
                  className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
              </div>
            </div>

            <div>
              <label className="text-xs text-[hsl(var(--text-tertiary))]">Phone number (10 digits)</label>
              <div className="relative mt-1 flex items-center">
                <span className="absolute left-3 text-sm font-medium text-[hsl(var(--text-secondary))]">+91</span>
                <Phone className="absolute left-12 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
                <input type="tel" inputMode="numeric" placeholder="9XXXXXXXXX" value={phone}
                  onChange={e => handlePhone(e.target.value)} maxLength={10}
                  className={`w-full h-12 pl-20 pr-4 rounded-xl border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]
                    ${phoneError ? "border-red-400" : "border-[hsl(var(--border))]"}`} />
              </div>
              {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
              {phone.length === 10 && !phoneError && <p className="text-xs text-green-600 mt-1">✓ Valid phone number</p>}
            </div>

            {role === "delivery_partner" && (
              <>
                <div>
                  <label className="text-xs text-[hsl(var(--text-tertiary))]">Vehicle type</label>
                  <select value={vehicle} onChange={e => setVehicle(e.target.value)}
                    className="w-full mt-1 h-12 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]">
                    <option value="">Select vehicle</option>
                    {VEHICLES.map(v => <option key={v} value={v}>{v}</option>)}
                  </select>
                </div>
                <div>
                  <label className="text-xs text-[hsl(var(--text-tertiary))]">Vehicle number</label>
                  <input type="text" placeholder="RJ14 XX 1234" value={vehicleNo}
                    onChange={e => setVehicleNo(e.target.value.toUpperCase())}
                    className="w-full mt-1 h-12 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
                </div>
              </>
            )}
          </div>
          <div className="flex gap-3 mt-4">
            <button onClick={() => setStep(0)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={() => {
              if (!name.trim()) { setError("Please enter your name."); return; }
              if (phone.length !== 10 || phoneError) { setError("Please enter a valid 10-digit phone number."); return; }
              setError(""); setStep(2);
            }} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold">Continue</button>
          </div>
        </div>
      )}

      {/* Step 2 — Address via map */}
      {step === 2 && (
        <div className="flex-1 space-y-4">
          <div>
            <h1 className="text-2xl font-bold">Your address</h1>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">We only deliver within Hindaun City.</p>
          </div>

          <button onClick={() => setMapOpen(true)}
            className={`press w-full p-4 rounded-2xl border-2 text-left transition-colors
              ${location ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-dashed border-[hsl(var(--border))]"}`}>
            <div className="flex items-center gap-3">
              <MapPin className={`w-5 h-5 shrink-0 ${location ? "text-[hsl(var(--accent))]" : "text-[hsl(var(--text-tertiary))]"}`} />
              <div className="flex-1 min-w-0">
                {location ? (
                  <>
                    <p className="text-sm font-semibold text-[hsl(var(--accent))]">Location selected ✓</p>
                    <p className="text-xs text-[hsl(var(--text-secondary))] mt-0.5 line-clamp-2">{location.line}</p>
                  </>
                ) : (
                  <>
                    <p className="text-sm font-semibold">Select on map</p>
                    <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">Tap to open map and pin your location</p>
                  </>
                )}
              </div>
              <ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))] shrink-0" />
            </div>
          </button>

          <div>
            <label className="text-xs text-[hsl(var(--text-tertiary))]">PIN code</label>
            <input type="number" inputMode="numeric" placeholder="322230" value={pin}
              onChange={e => setPin(e.target.value.slice(0, 6))} maxLength={6}
              className="w-full mt-1 h-12 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
            {pin.length > 0 && pin.length !== 6 && <p className="text-xs text-red-500 mt-1">PIN code must be 6 digits</p>}
          </div>

          <div className="flex gap-3 mt-4">
            <button onClick={() => setStep(1)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={finish} disabled={saving}
              className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60 flex items-center justify-center gap-2">
              {saving ? <><Loader2 className="w-4 h-4 animate-spin" />Saving…</> : "Finish setup"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
