import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, User, Loader2, UserPlus, CheckCircle2 } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import GoogleIcon from "@/components/GoogleIcon";
import { signUpEmail, signInGoogle } from "@/lib/db";

export default function Register() {
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [agreed, setAgreed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [gLoading, setGLoading] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirm) { setError("Passwords don't match."); return; }
    if (password.length < 6) { setError("Password must be at least 6 characters."); return; }
    if (!agreed) { setError("Please accept the Terms & Privacy Policy."); return; }
    setLoading(true);
    const { error: err } = await signUpEmail(email, password);
    setLoading(false);
    if (err) { setError(err.message); return; }
    setDone(true);
  };

  const googleLogin = async () => {
    if (!agreed) { setError("Please accept the Terms & Privacy Policy first."); return; }
    setError(""); setGLoading(true);
    const { error: err } = await signInGoogle();
    setGLoading(false);
    if (err) setError(err.message);
  };

  if (done) return (
    <AuthLayout icon={CheckCircle2} title="Check your email" subtitle={`Sent a confirmation link to ${email}`}
      footer={<Link to="/login" className="text-primary font-medium hover:underline">Back to log in</Link>}>
      <div className="text-center space-y-4">
        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto">
          <Mail className="w-8 h-8 text-green-600" />
        </div>
        <p className="text-sm text-[hsl(var(--text-secondary))]">Click the link in your email to activate your account, then log in.</p>
        <button onClick={() => navigate("/login")} className="press w-full h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Go to log in</button>
      </div>
    </AuthLayout>
  );

  return (
    <AuthLayout icon={UserPlus} title="Create account" subtitle="Sign up to get started"
      footer={<>Have an account? <Link to="/login" className="text-primary font-medium hover:underline">Log in</Link></>}>

      <button onClick={googleLogin} disabled={gLoading}
        className="press w-full h-12 rounded-2xl border border-[hsl(var(--border))] flex items-center justify-center gap-2 text-sm font-medium mb-5">
        {gLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <GoogleIcon className="w-5 h-5" />}
        Continue with Google
      </button>

      <div className="relative mb-5">
        <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-[hsl(var(--border))]" /></div>
        <div className="relative flex justify-center text-xs"><span className="bg-card px-3 text-[hsl(var(--text-tertiary))] uppercase">or</span></div>
      </div>

      {error && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm">{error}</div>}

      <form onSubmit={submit} className="space-y-4">
        <Field icon={User} type="text" placeholder="Your full name" value={name} onChange={setName} autoComplete="name" required />
        <Field icon={Mail} type="email" placeholder="you@example.com" value={email} onChange={setEmail} autoComplete="email" required />
        <Field icon={Lock} type="password" placeholder="Min. 6 characters" value={password} onChange={setPassword} autoComplete="new-password" required />
        <Field icon={Lock} type="password" placeholder="Confirm password" value={confirm} onChange={setConfirm} autoComplete="new-password" required />

        <label className="flex items-start gap-3 cursor-pointer">
          <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} className="w-4 h-4 mt-0.5 shrink-0" />
          <span className="text-xs text-[hsl(var(--text-secondary))]">
            I agree to the{" "}
            <Link to="/terms" className="text-primary underline">Terms of Service</Link>{" "}and{" "}
            <Link to="/privacy" className="text-primary underline">Privacy Policy</Link>
          </span>
        </label>

        <button type="submit" disabled={loading || !agreed}
          className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Create account"}
        </button>
      </form>
    </AuthLayout>
  );
}

function Field({ icon: Icon, ...props }) {
  const { onChange, ...rest } = props;
  return (
    <div className="relative">
      <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
      <input {...rest} onChange={e => onChange(e.target.value)} className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
    </div>
  );
}
