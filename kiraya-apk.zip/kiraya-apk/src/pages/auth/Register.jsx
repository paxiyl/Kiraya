import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Mail, Lock, User, Loader2, UserPlus } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import { signUpEmail } from "@/lib/db";

export default function Register() {
  const navigate = useNavigate();
  const [name, setName]         = useState("");
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm]   = useState("");
  const [agreed, setAgreed]     = useState(false);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    if (password !== confirm)  { setError("Passwords don't match."); return; }
    if (password.length < 6)   { setError("Password must be at least 6 characters."); return; }
    if (!agreed)               { setError("Please accept the Terms & Privacy Policy."); return; }
    setLoading(true);
    const { error: err } = await signUpEmail(email, password);
    setLoading(false);
    if (err) { setError(err.message); return; }
    // Auto-navigate since email confirmation is off
    navigate("/");
  };

  return (
    <AuthLayout icon={UserPlus} title="Create account" subtitle="Sign up to get started"
      footer={<>Have an account? <Link to="/login" className="text-primary font-medium hover:underline">Log in</Link></>}>

      {error && <div className="mb-4 p-3 rounded-xl bg-red-50 text-red-600 text-sm">{error}</div>}

      <form onSubmit={submit} className="space-y-4">
        {[
          { label:"Full name",       field:name,     set:setName,     type:"text",     ph:"Your full name",    icon:User,  ac:"name" },
          { label:"Email",           field:email,    set:setEmail,    type:"email",    ph:"you@example.com",   icon:Mail,  ac:"email" },
          { label:"Password",        field:password, set:setPassword, type:"password", ph:"Min. 6 characters", icon:Lock,  ac:"new-password" },
          { label:"Confirm password",field:confirm,  set:setConfirm,  type:"password", ph:"••••••••",          icon:Lock,  ac:"new-password" },
        ].map(({ label, field, set, type, ph, icon: Icon, ac }) => (
          <div key={label}>
            <label className="text-xs text-[hsl(var(--text-tertiary))]">{label}</label>
            <div className="relative mt-1">
              <Icon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
              <input type={type} autoComplete={ac} placeholder={ph} value={field}
                onChange={e => set(e.target.value)} required
                className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
            </div>
          </div>
        ))}

        <label className="flex items-start gap-3 cursor-pointer">
          <input type="checkbox" checked={agreed} onChange={e => setAgreed(e.target.checked)} className="w-4 h-4 mt-0.5 shrink-0" />
          <span className="text-xs text-[hsl(var(--text-secondary))]">
            I agree to the{" "}
            <Link to="/terms" className="text-primary underline">Terms of Service</Link>{" "}and{" "}
            <Link to="/privacy" className="text-primary underline">Privacy Policy</Link>
          </span>
        </label>

        <button type="submit" disabled={loading || !agreed}
          className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60 flex items-center justify-center gap-2">
          {loading ? <><Loader2 className="w-4 h-4 animate-spin" />Creating account…</> : "Create account"}
        </button>
      </form>
    </AuthLayout>
  );
}
