import React, { useState } from "react";
import { Link } from "react-router-dom";
import { Mail, ArrowLeft, Loader2 } from "lucide-react";
import AuthLayout from "@/components/AuthLayout";
import { resetPassword } from "@/lib/db";

export default function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setLoading(true);
    await resetPassword(email).catch(() => {}); // Always show success (prevent email enumeration)
    setLoading(false);
    setSent(true);
  };

  return (
    <AuthLayout icon={Mail} title="Reset password" subtitle="We'll email you a reset link"
      footer={<Link to="/login" className="text-primary font-medium hover:underline flex items-center gap-1"><ArrowLeft className="w-3 h-3" />Back to log in</Link>}>
      {sent ? (
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto"><Mail className="w-8 h-8 text-blue-600" /></div>
          <p className="text-sm text-[hsl(var(--text-secondary))]">If an account exists for <strong>{email}</strong>, you'll get a reset link shortly. Check your spam folder too.</p>
          <Link to="/login"><button className="press w-full h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back to log in</button></Link>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-4">
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            <input type="email" required placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)}
              className="w-full h-12 pl-10 pr-4 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
          </div>
          <button type="submit" disabled={loading} className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60">
            {loading ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Send reset link"}
          </button>
        </form>
      )}
    </AuthLayout>
  );
}
