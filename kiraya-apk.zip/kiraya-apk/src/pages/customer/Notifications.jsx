import React from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Bell } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { notifications } from "@/data/mockData";
import { Package, Tag, Sparkles, Gift } from "lucide-react";

const ICONS = { package: Package, tag: Tag, sparkles: Sparkles, gift: Gift };
const TONES = {
  accent: "bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]",
  success: "bg-[hsl(var(--success-soft))] text-[hsl(var(--success))]",
  warning: "bg-[hsl(var(--warning-soft))] text-[hsl(var(--warning))]",
  neutral: "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]",
};

export default function Notifications() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
        <h1 className="text-lg font-semibold">Notifications</h1>
      </div>
      <div className="space-y-2">
        {notifications.map((n) => {
          const Icon = ICONS[n.icon] || Bell;
          return (
            <div key={n.id} className={`card-soft rounded-2xl p-4 flex gap-3 ${n.unread ? "" : "opacity-70"}`}>
              <div className={`w-10 h-10 rounded-xl grid place-items-center shrink-0 ${TONES[n.tone]}`}><Icon className="w-4.5 h-4.5" /></div>
              <div className="flex-1">
                <p className="text-sm font-medium">{n.title}</p>
                <p className="text-xs text-[hsl(var(--text-secondary))] mt-0.5">{n.desc}</p>
                <p className="text-[11px] text-[hsl(var(--text-tertiary))] mt-1">{n.time}</p>
              </div>
              {n.unread && <span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))] mt-1.5" />}
            </div>
          );
        })}
      </div>
    </div>
  );
}