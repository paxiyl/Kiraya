import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Bell, Package, Tag, CheckCheck } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";

export default function Notifications() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifs, setNotifs] = useState([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    const { data } = await supabase.from("notifications").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(50);
    setNotifs(data || []);
    setLoading(false);
  };

  useEffect(() => { load(); }, [user]);

  const markAllRead = async () => {
    await supabase.from("notifications").update({ read: true }).eq("user_id", user.id).eq("read", false);
    load();
  };

  const unreadCount = notifs.filter(n => !n.read).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
        <h1 className="text-lg font-semibold flex-1">Notifications</h1>
        {unreadCount > 0 && (
          <button onClick={markAllRead} className="press flex items-center gap-1 text-xs text-[hsl(var(--accent))] font-medium">
            <CheckCheck className="w-3.5 h-3.5" /> Mark all read
          </button>
        )}
      </div>

      {loading ? (
        <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-16 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}</div>
      ) : notifs.length === 0 ? (
        <div className="py-20 text-center space-y-2">
          <Bell className="w-12 h-12 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No notifications yet</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">Order updates and alerts will appear here</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifs.map(n => (
            <div key={n.id} className={`card-soft rounded-2xl p-4 flex gap-3 ${!n.read ? "border border-[hsl(var(--accent))/30]" : ""}`}>
              <div className="w-10 h-10 rounded-xl bg-[hsl(var(--accent-soft))] grid place-items-center shrink-0">
                {n.type === "order" ? <Package className="w-4.5 h-4.5 text-[hsl(var(--accent))]" /> : <Bell className="w-4.5 h-4.5 text-[hsl(var(--accent))]" />}
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{n.title}</p>
                <p className="text-xs text-[hsl(var(--text-secondary))] mt-0.5">{n.body}</p>
                <p className="text-[11px] text-[hsl(var(--text-tertiary))] mt-1">{new Date(n.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}</p>
              </div>
              {!n.read && <span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))] mt-1.5 shrink-0" />}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
