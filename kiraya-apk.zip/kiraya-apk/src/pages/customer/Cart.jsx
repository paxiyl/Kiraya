import React from "react";
import { Link } from "react-router-dom";
import { Minus, Plus, Trash2, ShoppingCart } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatPrice } from "@/lib/appConfig";

export default function Cart() {
  const { rows, setQty, remove, subtotal, deliveryFee, taxes, platformFee, discount, total, count } = useCart();

  if (count === 0) return (
    <div className="py-20 text-center space-y-3">
      <ShoppingCart className="w-12 h-12 text-[hsl(var(--text-tertiary))] mx-auto" />
      <p className="text-sm text-[hsl(var(--text-secondary))]">Your cart is empty</p>
      <Link to="/explore" className="text-[hsl(var(--accent))] text-sm font-medium">Browse stores</Link>
    </div>
  );

  return (
    <div className="space-y-4 pb-24">
      <h1 className="text-xl font-bold tracking-tight">Cart ({count})</h1>

      <div className="space-y-2">
        {rows.map(({ product, qty }) => (
          <div key={product.id} className="card-soft rounded-2xl p-3 flex gap-3">
            {product.imageUrl
              ? <img src={product.imageUrl} alt={product.name} className="w-16 h-16 rounded-xl object-cover shrink-0" />
              : <div className="w-16 h-16 rounded-xl bg-[hsl(var(--muted))] shrink-0 grid place-items-center text-xl font-bold text-[hsl(var(--text-tertiary))]">{product.name.charAt(0)}</div>
            }
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold">{product.name}</p>
              <p className="text-sm font-bold text-[hsl(var(--accent))] mt-0.5">{formatPrice(product.price)}</p>
              <div className="flex items-center gap-2 mt-2">
                <button onClick={() => setQty(product.id, qty - 1)} className="press w-7 h-7 rounded-lg bg-[hsl(var(--muted))] grid place-items-center"><Minus className="w-3 h-3" /></button>
                <span className="text-sm font-bold w-5 text-center">{qty}</span>
                <button onClick={() => setQty(product.id, qty + 1)} className="press w-7 h-7 rounded-lg bg-[hsl(var(--muted))] grid place-items-center"><Plus className="w-3 h-3" /></button>
                <button onClick={() => remove(product.id)} className="press w-7 h-7 rounded-lg text-red-500 ml-auto grid place-items-center"><Trash2 className="w-3.5 h-3.5" /></button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Bill */}
      <div className="card-soft rounded-2xl p-4 space-y-2">
        <h3 className="text-sm font-semibold mb-2">Bill details</h3>
        {[[`Subtotal`, subtotal],[`Delivery fee`, deliveryFee],[`Taxes & charges`, taxes],[`Platform fee`, platformFee]].map(([l, v]) => (
          <div key={l} className="flex justify-between text-sm text-[hsl(var(--text-secondary))]"><span>{l}</span><span>{formatPrice(v)}</span></div>
        ))}
        {discount > 0 && <div className="flex justify-between text-sm text-green-600"><span>Discount</span><span>-{formatPrice(discount)}</span></div>}
        <div className="border-t border-[hsl(var(--border))] pt-2 flex justify-between font-bold"><span>Total</span><span>{formatPrice(total)}</span></div>
      </div>

      <div className="fixed bottom-16 left-4 right-4 z-40">
        <Link to="/checkout" className="press flex items-center justify-between h-14 px-5 rounded-2xl bg-[hsl(var(--accent))] text-white shadow-lg">
          <span className="font-semibold">Proceed to checkout</span>
          <span className="font-bold">{formatPrice(total)}</span>
        </Link>
      </div>
    </div>
  );
}
