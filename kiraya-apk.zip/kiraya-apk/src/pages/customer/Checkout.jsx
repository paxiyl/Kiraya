import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Check, MapPin, CreditCard, Banknote, Smartphone, Loader2, ChevronRight } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatPrice } from "@/lib/appConfig";
import { createOrder } from "@/lib/db";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import MapPicker from "@/components/MapPicker";

const STEPS = ["Address", "Payment", "Review"];
const PAYMENT_OPTIONS = [
  { id: "upi",  label: "UPI",              icon: Smartphone },
  { id: "card", label: "Card",             icon: CreditCard },
  { id: "cod",  label: "Cash on Delivery", icon: Banknote   },
];

export default function Checkout() {
  const { rows, subtotal, deliveryFee, taxes, platformFee, discount, total, count, clear, storeId } = useCart();
  const { user, profile } = useAuth();
  const { toast }   = useToast();
  const navigate    = useNavigate();
  const [step, setStep]       = useState(0);
  const [mapOpen, setMapOpen] = useState(false);
  const [location, setLocation] = useState(
    profile?.address?.line
      ? { line: profile.address.line, lat: profile.address.lat, lng: profile.address.lng }
      : null
  );
  const [phone, setPhone]     = useState(profile?.phone?.replace("+91","") || "");
  const [phoneError, setPhoneError] = useState("");
  const [pin, setPin]         = useState(profile?.address?.pin || "");
  const [payment, setPayment] = useState("upi");
  const [placing, setPlacing] = useState(false);

  if (count === 0) return (
    <div className="py-20 text-center space-y-3">
      <p className="text-sm text-[hsl(var(--text-secondary))]">Your cart is empty.</p>
      <Link to="/explore" className="text-[hsl(var(--accent))] text-sm font-medium">Browse stores</Link>
    </div>
  );

  if (mapOpen) return (
    <MapPicker
      initial={location}
      onSelect={(loc) => { setLocation(loc); setMapOpen(false); }}
      onClose={() => setMapOpen(false)}
    />
  );

  const validatePhone = (val) => {
    const d = val.replace(/\D/g,"");
    if (d.length !== 10) return "Phone must be 10 digits";
    if (!/^[6-9]/.test(d)) return "Must start with 6, 7, 8 or 9";
    return "";
  };

  const handlePhone = (val) => {
    const d = val.replace(/\D/g,"").slice(0,10);
    setPhone(d);
    setPhoneError(validatePhone(d));
  };

  const placeOrder = async () => {
    setPlacing(true);
    try {
      const order = await createOrder({
        customer_id:         user.id,
        customer_name:       profile?.display_name || user.email,
        store_id:            storeId,
        delivery_partner_id: null,
        items:               rows.map(({ product, qty }) => ({
          product_id: product.id, name: product.name, price: product.price, qty,
        })),
        subtotal, delivery_fee: deliveryFee, taxes, platform_fee: platformFee, discount, total,
        address: {
          line:  location.line,
          city:  "Hindaun City",
          pin,
          lat:   location.lat,
          lng:   location.lng,
          phone: `+91${phone}`,
        },
        payment_method: payment,
        status: "PENDING",
      });
      clear();
      toast({ title: "Order placed 🎉" });
      navigate(`/orders/${order.id}`);
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally { setPlacing(false); }
  };

  const step0Valid = location && phone.length === 10 && !phoneError && pin.length === 6;

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center">
          <ArrowLeft className="w-4.5 h-4.5" />
        </button>
        <h1 className="text-lg font-semibold">Checkout</h1>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-1.5">
        {STEPS.map((s, i) => (
          <React.Fragment key={s}>
            <div className="flex flex-col items-center gap-1">
              <div className={`w-7 h-7 rounded-full grid place-items-center text-xs font-semibold transition-colors
                ${i < step ? "bg-green-500 text-white" : i === step ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-tertiary))]"}`}>
                {i < step ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <span className={`text-[10px] ${i === step ? "font-semibold" : "text-[hsl(var(--text-tertiary))]"}`}>{s}</span>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 rounded mb-3 ${i < step ? "bg-green-500" : "bg-[hsl(var(--muted))]"}`} />}
          </React.Fragment>
        ))}
      </div>

      {/* Step 0 — Address */}
      {step === 0 && (
        <div className="space-y-3">
          <button onClick={() => setMapOpen(true)}
            className={`press w-full p-4 rounded-2xl border-2 text-left ${location ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-dashed border-[hsl(var(--border))]"}`}>
            <div className="flex items-center gap-3">
              <MapPin className={`w-5 h-5 shrink-0 ${location ? "text-[hsl(var(--accent))]" : "text-[hsl(var(--text-tertiary))]"}`} />
              <div className="flex-1 min-w-0">
                {location
                  ? <><p className="text-sm font-semibold text-[hsl(var(--accent))]">Location set ✓</p><p className="text-xs text-[hsl(var(--text-secondary))] mt-0.5 line-clamp-1">{location.line}</p></>
                  : <><p className="text-sm font-semibold">Select delivery location</p><p className="text-xs text-[hsl(var(--text-tertiary))]">Tap to open map</p></>
                }
              </div>
              <ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            </div>
          </button>

          <div>
            <label className="text-xs text-[hsl(var(--text-tertiary))]">PIN code</label>
            <input type="number" inputMode="numeric" placeholder="322230" value={pin}
              onChange={e => setPin(e.target.value.slice(0,6))} maxLength={6}
              className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
          </div>

          <div>
            <label className="text-xs text-[hsl(var(--text-tertiary))]">Phone number</label>
            <div className="relative mt-1">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-medium text-[hsl(var(--text-secondary))]">+91</span>
              <input type="tel" inputMode="numeric" placeholder="9XXXXXXXXX" value={phone}
                onChange={e => handlePhone(e.target.value)} maxLength={10}
                className={`w-full h-11 pl-12 pr-4 rounded-xl border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]
                  ${phoneError ? "border-red-400" : "border-[hsl(var(--border))]"}`} />
            </div>
            {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
          </div>

          <button onClick={() => setStep(1)} disabled={!step0Valid}
            className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-50">
            Continue
          </button>
        </div>
      )}

      {/* Step 1 — Payment */}
      {step === 1 && (
        <div className="card-soft rounded-2xl p-4 space-y-3">
          <h3 className="font-semibold text-sm">Payment method</h3>
          <div className="space-y-2">
            {PAYMENT_OPTIONS.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setPayment(id)}
                className={`press w-full flex items-center gap-3 h-14 px-4 rounded-2xl border-2 transition-colors
                  ${payment === id ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-[hsl(var(--border))]"}`}>
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium flex-1 text-left">{label}</span>
                {payment === id && <Check className="w-4 h-4 text-[hsl(var(--accent))]" />}
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(0)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={() => setStep(2)} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold">Continue</button>
          </div>
        </div>
      )}

      {/* Step 2 — Review */}
      {step === 2 && (
        <div className="space-y-3">
          <div className="card-soft rounded-2xl p-4 space-y-2">
            <h3 className="font-semibold text-sm mb-2">Order summary</h3>
            {rows.map(({ product, qty }) => (
              <div key={product.id} className="flex justify-between text-sm">
                <span className="text-[hsl(var(--text-secondary))]">{product.name} × {qty}</span>
                <span className="font-medium">{formatPrice(product.price * qty)}</span>
              </div>
            ))}
            <div className="border-t border-[hsl(var(--border))] mt-2 pt-2 space-y-1">
              {[["Subtotal",subtotal],["Delivery",deliveryFee],["Taxes",taxes],["Platform fee",platformFee]].map(([l,v]) => (
                <div key={l} className="flex justify-between text-xs text-[hsl(var(--text-tertiary))]"><span>{l}</span><span>{formatPrice(v)}</span></div>
              ))}
              {discount > 0 && <div className="flex justify-between text-xs text-green-600"><span>Discount</span><span>-{formatPrice(discount)}</span></div>}
              <div className="flex justify-between font-bold text-sm pt-1"><span>Total</span><span>{formatPrice(total)}</span></div>
            </div>
          </div>
          <div className="card-soft rounded-2xl p-3 text-xs text-[hsl(var(--text-secondary))] space-y-1">
            <p>📍 {location?.line}, Hindaun City — {pin}</p>
            <p>📞 +91{phone}</p>
            <p>💳 {PAYMENT_OPTIONS.find(p => p.id === payment)?.label}</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(1)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={placeOrder} disabled={placing}
              className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-70 flex items-center justify-center gap-2">
              {placing ? <><Loader2 className="w-4 h-4 animate-spin" />Placing…</> : `Place · ${formatPrice(total)}`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
