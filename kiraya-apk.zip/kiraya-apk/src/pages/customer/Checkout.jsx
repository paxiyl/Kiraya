import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Check, MapPin, Truck, CreditCard, Banknote, Smartphone } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatPrice } from "@/lib/appConfig";
import { createOrder } from "@/lib/firestore";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import { motion } from "framer-motion";

const STEPS = ["Address", "Payment", "Review"];

const PAYMENT_OPTIONS = [
  { id: "upi", label: "UPI", icon: Smartphone },
  { id: "card", label: "Card", icon: CreditCard },
  { id: "cod", label: "Cash on Delivery", icon: Banknote },
];

export default function Checkout() {
  const { rows, subtotal, deliveryFee, taxes, platformFee, discount, total, count, clear, storeId } = useCart();
  const { user, profile } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [address, setAddress] = useState({ line: profile?.address?.line || "", city: profile?.address?.city || "", pin: profile?.address?.pin || "", phone: profile?.phone || "" });
  const [payment, setPayment] = useState("upi");
  const [placing, setPlacing] = useState(false);

  if (count === 0) return (
    <div className="py-20 text-center space-y-3">
      <p className="text-sm text-[hsl(var(--text-secondary))]">Your cart is empty.</p>
      <Link to="/explore" className="text-[hsl(var(--accent))] text-sm font-medium">Browse stores</Link>
    </div>
  );

  const placeOrder = async () => {
    setPlacing(true);
    try {
      const orderData = {
        customerId: user.uid,
        customerName: profile?.displayName || user.email,
        storeId,
        deliveryPartnerId: null,
        items: rows.map(({ product, qty }) => ({ productId: product.id, name: product.name, price: product.price, qty })),
        subtotal, deliveryFee, taxes, platformFee, discount, total,
        address,
        paymentMethod: payment,
        status: "PENDING",
      };
      const ref = await createOrder(orderData);
      clear();
      toast({ title: "Order placed 🎉", description: "Your order is confirmed." });
      navigate(`/orders/${ref.id}`);
    } catch (e) {
      toast({ title: "Failed to place order", description: e.message, variant: "destructive" });
    } finally {
      setPlacing(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
        <h1 className="text-lg font-semibold">Checkout</h1>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-1.5">
        {STEPS.map((s, i) => (
          <React.Fragment key={s}>
            <div className="flex flex-col items-center gap-1">
              <div className={`w-7 h-7 rounded-full grid place-items-center text-xs font-semibold ${i <= step ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-tertiary))]"}`}>
                {i < step ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <span className={`text-[10px] ${i === step ? "font-semibold" : "text-[hsl(var(--text-tertiary))]"}`}>{s}</span>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 rounded ${i < step ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--muted))]"}`} />}
          </React.Fragment>
        ))}
      </div>

      {/* Step 0 — Address */}
      {step === 0 && (
        <div className="card-soft rounded-2xl p-4 space-y-3">
          <div className="flex items-center gap-2 mb-1"><MapPin className="w-4 h-4 text-[hsl(var(--accent))]" /><h3 className="font-semibold text-sm">Delivery address</h3></div>
          {["line", "city", "pin", "phone"].map(field => (
            <div key={field}>
              <label className="text-xs text-[hsl(var(--text-tertiary))] capitalize">{field === "pin" ? "PIN code" : field === "line" ? "Street / flat" : field}</label>
              <input
                className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
                placeholder={field === "line" ? "Flat 302, Street name..." : field === "pin" ? "302001" : field === "phone" ? "+91 9XXXXXXXXX" : "City"}
                value={address[field]}
                onChange={e => setAddress(p => ({ ...p, [field]: e.target.value }))}
              />
            </div>
          ))}
          <button onClick={() => setStep(1)} disabled={!address.line || !address.city || !address.pin || !address.phone}
            className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-50">
            Continue
          </button>
        </div>
      )}

      {/* Step 1 — Payment */}
      {step === 1 && (
        <div className="card-soft rounded-2xl p-4 space-y-3">
          <h3 className="font-semibold text-sm">Payment method</h3>
          <div className="space-y-2">
            {PAYMENT_OPTIONS.map(({ id, label, icon: Icon }) => (
              <button key={id} onClick={() => setPayment(id)}
                className={`press w-full flex items-center gap-3 h-14 px-4 rounded-2xl border-2 transition-colors ${payment === id ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-[hsl(var(--border))]"}`}>
                <Icon className="w-5 h-5" />
                <span className="text-sm font-medium">{label}</span>
                {payment === id && <Check className="w-4 h-4 ml-auto text-[hsl(var(--accent))]" />}
              </button>
            ))}
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(0)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={() => setStep(2)} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold">Continue</button>
          </div>
        </div>
      )}

      {/* Step 2 — Review */}
      {step === 2 && (
        <div className="space-y-3">
          <div className="card-soft rounded-2xl p-4 space-y-2">
            <h3 className="font-semibold text-sm mb-2">Order summary</h3>
            {rows.map(({ product, qty }) => (
              <div key={product.id} className="flex justify-between text-sm">
                <span className="text-[hsl(var(--text-secondary))]">{product.name} × {qty}</span>
                <span className="font-medium">{formatPrice(product.price * qty)}</span>
              </div>
            ))}
            <div className="border-t border-[hsl(var(--border))] mt-2 pt-2 space-y-1">
              {[[`Subtotal`, subtotal],[`Delivery`, deliveryFee],[`Taxes`, taxes],[`Platform fee`, platformFee]].map(([l,v]) => (
                <div key={l} className="flex justify-between text-xs text-[hsl(var(--text-tertiary))]"><span>{l}</span><span>{formatPrice(v)}</span></div>
              ))}
              {discount > 0 && <div className="flex justify-between text-xs text-green-600"><span>Discount</span><span>-{formatPrice(discount)}</span></div>}
              <div className="flex justify-between font-bold text-sm pt-1"><span>Total</span><span>{formatPrice(total)}</span></div>
            </div>
          </div>
          <div className="card-soft rounded-2xl p-3 text-xs text-[hsl(var(--text-tertiary))]">
            <p>📍 {address.line}, {address.city} — {address.pin}</p>
            <p className="mt-1">💳 {PAYMENT_OPTIONS.find(p => p.id === payment)?.label}</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => setStep(1)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm font-medium">Back</button>
            <button onClick={placeOrder} disabled={placing}
              className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-70">
              {placing ? "Placing…" : `Place order · ${formatPrice(total)}`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
