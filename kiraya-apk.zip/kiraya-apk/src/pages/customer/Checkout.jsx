import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { ArrowLeft, Check, MapPin, Truck, Wallet, CreditCard, Banknote, Smartphone, ChevronRight } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { addresses } from "@/data/mockData";
import { formatPrice } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from "framer-motion";

const STEPS = ["Address", "Delivery", "Payment", "Review"];

export default function Checkout() {
  const { rows, subtotal, deliveryFee, taxes, platformFee, discount, total, count, clear } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [step, setStep] = useState(0);
  const [addr, setAddr] = useState(addresses.find((a) => a.default) || addresses[0]);
  const [deliveryType, setDeliveryType] = useState("express");
  const [payment, setPayment] = useState("upi");
  const [placing, setPlacing] = useState(false);

  if (count === 0) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm text-[hsl(var(--text-secondary))]">Your cart is empty.</p>
        <Link to="/explore" className="text-[hsl(var(--accent))] text-sm font-medium">Browse stores</Link>
      </div>
    );
  }

  const placeOrder = () => {
    setPlacing(true);
    // Firebase: replace with createOrder() Cloud Function call
    setTimeout(() => {
      clear();
      toast({ title: "Order placed 🎉", description: "Your order is confirmed." });
      navigate("/orders/ORD-2041");
    }, 900);
  };

  const next = () => setStep((s) => Math.min(s + 1, 3));
  const back = () => setStep((s) => Math.max(s - 1, 0));

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
        <h1 className="text-lg font-semibold">Checkout</h1>
      </div>

      {/* Stepper */}
      <div className="flex items-center gap-1.5">
        {STEPS.map((s, i) => (
          <React.Fragment key={s}>
            <div className="flex flex-col items-center gap-1">
              <div className={`w-7 h-7 rounded-full grid place-items-center text-xs font-semibold ${i <= step ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-tertiary))]"}`}>
                {i < step ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <span className={`text-[10px] ${i === step ? "font-semibold text-[hsl(var(--text-primary))]" : "text-[hsl(var(--text-tertiary))]"}`}>{s}</span>
            </div>
            {i < STEPS.length - 1 && <div className={`flex-1 h-0.5 rounded ${i < step ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--border))]"}`} />}
          </React.Fragment>
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div key={step} initial={{ opacity: 0, x: 16 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -16 }} transition={{ duration: 0.25 }} className="space-y-3">
          {step === 0 && (
            <div className="space-y-3">
              {addresses.map((a) => (
                <button key={a.id} onClick={() => setAddr(a)} className={`press w-full text-left card-soft rounded-2xl p-4 flex items-start gap-3 ${addr?.id === a.id ? "ring-2 ring-[hsl(var(--accent))]" : ""}`}>
                  <MapPin className="w-4 h-4 text-[hsl(var(--accent))] mt-0.5" />
                  <div className="flex-1">
                    <p className="text-sm font-semibold">{a.label} <span className="text-[hsl(var(--text-tertiary))] font-normal">· {a.city}</span></p>
                    <p className="text-xs text-[hsl(var(--text-secondary))] mt-0.5">{a.line}, {a.state} - {a.pin}</p>
                    <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{a.phone}</p>
                  </div>
                  {a.default && <span className="text-[10px] px-2 py-0.5 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] font-medium">Default</span>}
                </button>
              ))}
              <Link to="/profile" className="press text-sm text-[hsl(var(--accent))] font-medium inline-flex items-center gap-1">+ Add new address</Link>
            </div>
          )}

          {step === 1 && (
            <div className="space-y-3">
              {[
                { id: "express", t: "Express", d: "15–30 min · surge may apply", icon: Zap },
                { id: "standard", t: "Standard", d: "30–90 min", icon: Truck },
                { id: "scheduled", t: "Scheduled", d: "Choose a delivery slot", icon: Wallet },
              ].map((o) => {
                const Icon = o.icon;
                return (
                  <button key={o.id} onClick={() => setDeliveryType(o.id)} className={`press w-full text-left card-soft rounded-2xl p-4 flex items-center gap-3 ${deliveryType === o.id ? "ring-2 ring-[hsl(var(--accent))]" : ""}`}>
                    <Icon className="w-4 h-4 text-[hsl(var(--accent))]" />
                    <div className="flex-1"><p className="text-sm font-semibold">{o.t}</p><p className="text-xs text-[hsl(var(--text-secondary))]">{o.d}</p></div>
                    <span className={`w-5 h-5 rounded-full border-2 ${deliveryType === o.id ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent))]" : "border-[hsl(var(--border))]"}`} />
                  </button>
                );
              })}
            </div>
          )}

          {step === 2 && (
            <div className="space-y-3">
              {[
                { id: "upi", t: "UPI", d: "GPay / PhonePe / Paytm", icon: Smartphone },
                { id: "card", t: "Credit / Debit Card", d: "Visa, Mastercard, RuPay", icon: CreditCard },
                { id: "wallet", t: "Wallet", d: "Paytm / Amazon Pay", icon: Wallet },
                { id: "cod", t: "Cash on Delivery", d: "Pay when it arrives", icon: Banknote },
              ].map((o) => {
                const Icon = o.icon;
                return (
                  <button key={o.id} onClick={() => setPayment(o.id)} className={`press w-full text-left card-soft rounded-2xl p-4 flex items-center gap-3 ${payment === o.id ? "ring-2 ring-[hsl(var(--accent))]" : ""}`}>
                    <Icon className="w-4 h-4 text-[hsl(var(--accent))]" />
                    <div className="flex-1"><p className="text-sm font-semibold">{o.t}</p><p className="text-xs text-[hsl(var(--text-secondary))]">{o.d}</p></div>
                    <span className={`w-5 h-5 rounded-full border-2 ${payment === o.id ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent))]" : "border-[hsl(var(--border))]"}`} />
                  </button>
                );
              })}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-3">
              <div className="card-soft rounded-2xl p-4">
                <p className="text-xs text-[hsl(var(--text-tertiary))]">Delivering to</p>
                <p className="text-sm font-semibold mt-0.5">{addr?.label} · {addr?.city}</p>
                <p className="text-xs text-[hsl(var(--text-secondary))]">{addr?.line}</p>
              </div>
              <div className="card-soft rounded-2xl p-4 space-y-2 text-sm">
                {rows.map(({ product, qty }) => (
                  <div key={product.id} className="flex justify-between">
                    <span className="text-[hsl(var(--text-secondary))]">{product.name} × {qty}</span>
                    <span>{formatPrice(product.price * qty)}</span>
                  </div>
                ))}
                <div className="border-t border-[hsl(var(--border))] pt-2 flex justify-between"><span className="text-[hsl(var(--text-secondary))]">Delivery</span><span>{deliveryFee === 0 ? "Free" : formatPrice(deliveryFee)}</span></div>
                {discount > 0 && <div className="flex justify-between text-[hsl(var(--success))]"><span>Discount</span><span>− {formatPrice(discount)}</span></div>}
                <div className="flex justify-between font-bold text-base"><span>Total</span><span>{formatPrice(total)}</span></div>
                <p className="text-xs text-[hsl(var(--text-tertiary))] pt-1">Paying via {payment.toUpperCase()}</p>
              </div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>

      {/* Bottom actions */}
      <div className="fixed bottom-0 inset-x-0 z-40 glass-strong border-t border-[hsl(var(--glass-border))] safe-bottom">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
          {step > 0 && <button onClick={back} className="press h-12 px-4 rounded-2xl card-soft text-sm font-medium">Back</button>}
          {step < 3 ? (
            <button onClick={next} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] font-semibold text-sm flex items-center justify-center gap-2">
              Continue <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button onClick={placeOrder} disabled={placing} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] font-semibold text-sm flex items-center justify-center gap-2 disabled:opacity-70">
              {placing ? <><span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> Placing…</> : <>Place order · {formatPrice(total)}</>}
            </button>
          )}
        </div>
      </div>
      <div className="h-20" />
    </div>
  );
}

function Zap(props) { return <Truck {...props} />; }