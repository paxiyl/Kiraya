import React, { useMemo, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Search, Star, Clock, MapPin, BadgePercent, Info } from "lucide-react";
import { getStore, productsByStore } from "@/data/mockData";
import { StoreMedia } from "@/components/customer/Media";
import ProductCard from "@/components/customer/ProductCard";
import { Pill } from "@/components/customer/StatusBadge";

export default function StoreDetail() {
  const { id } = useParams();
  const store = getStore(id);
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [activeCat, setActiveCat] = useState("All");

  const allProducts = useMemo(() => (store ? productsByStore(store.id) : []), [store]);
  const cats = useMemo(() => ["All", ...new Set(allProducts.map((p) => p.category))], [allProducts]);
  const list = useMemo(() => {
    let l = allProducts;
    if (activeCat !== "All") l = l.filter((p) => p.category === activeCat);
    if (q.trim()) l = l.filter((p) => p.name.toLowerCase().includes(q.toLowerCase()));
    return l;
  }, [allProducts, activeCat, q]);

  if (!store) {
    return <div className="py-20 text-center text-sm text-[hsl(var(--text-secondary))]">Store not found.</div>;
  }

  return (
    <div className="space-y-4 -mx-4">
      <div className="relative">
        <StoreMedia category={store.category} label={store.name} className="w-full h-52 rounded-none" rounded="rounded-none" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/55 to-transparent" />
        <button onClick={() => navigate(-1)} className="press absolute top-4 left-4 w-10 h-10 rounded-full glass grid place-items-center">
          <ArrowLeft className="w-4.5 h-4.5" />
        </button>
        {!store.open && (
          <div className="absolute inset-x-0 bottom-0 p-4">
            <Pill tone="neutral" className="bg-black/60 text-white">Currently closed · Opens 10:00 AM</Pill>
          </div>
        )}
      </div>

      <div className="px-4">
        <h1 className="text-xl font-bold">{store.name}</h1>
        <p className="text-sm text-[hsl(var(--text-secondary))] mt-0.5">{store.tag}</p>
        <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-secondary))]">
          <span className="inline-flex items-center gap-1 font-medium text-[hsl(var(--text-primary))]"><Star className="w-3.5 h-3.5 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {store.rating}</span>
          <span className="inline-flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {store.eta}</span>
          <span className="inline-flex items-center gap-1"><MapPin className="w-3.5 h-3.5" /> {store.distance}</span>
        </div>
        {store.offer && (
          <div className="mt-3 flex items-center gap-2 p-3 rounded-2xl bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]">
            <BadgePercent className="w-4 h-4" />
            <span className="text-sm font-medium">{store.offer}</span>
          </div>
        )}
      </div>

      <div className="px-4">
        <div className="flex items-center gap-2.5 h-11 px-3.5 rounded-2xl glass">
          <Search className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search in this store" className="flex-1 bg-transparent outline-none text-sm" />
        </div>
      </div>

      {/* Sticky category tabs */}
      <div className="sticky top-0 z-10 bg-background/80 backdrop-blur-md px-4 py-2 -mx-4">
        <div className="flex gap-2 overflow-x-auto no-scrollbar">
          {cats.map((c) => (
            <button key={c} onClick={() => setActiveCat(c)} className="press shrink-0">
              <Pill tone={activeCat === c ? "accent" : "neutral"}>{c}</Pill>
            </button>
          ))}
        </div>
      </div>

      <div className="px-4">
        {list.length === 0 ? (
          <p className="text-sm text-[hsl(var(--text-tertiary))] text-center py-10">No items match your search.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">{list.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        )}
      </div>
    </div>
  );
}