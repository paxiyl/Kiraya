import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { ArrowLeft, MapPin, Package, Store as StoreIcon } from "lucide-react";
import { getStoreById, getAvailableProducts } from "@/lib/db";
import { supabase } from "@/lib/supabase";
import { formatPrice } from "@/lib/appConfig";
import { cn } from "@/lib/utils";
import ProductCard from "@/components/customer/ProductCard";
import SmartImage, { categoryLabel } from "@/components/customer/SmartImage";
import EmptyState from "@/components/customer/EmptyState";
import { Bone, ProductSkeleton } from "@/components/customer/Skeletons";

// Menu-style rows read better for prepared food; grids suit packaged goods.
const ROW_LAYOUT = new Set(["food", "bakery"]);

export default function StoreDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [store, setStore] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeCat, setActiveCat] = useState(null);
  const sectionRefs = useRef({});

  const loadProducts = useCallback(async () => {
    const p = await getAvailableProducts(id);
    setProducts(p);
  }, [id]);

  useEffect(() => {
    setLoading(true);
    Promise.all([getStoreById(id), getAvailableProducts(id)]).then(([s, p]) => {
      setStore(s); setProducts(p); setLoading(false);
    });
    // Real-time product updates (unchanged behaviour)
    const channel = supabase.channel(`store-products-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "products", filter: `store_id=eq.${id}` }, loadProducts)
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [id, loadProducts]);

  const groups = useMemo(() => {
    const acc = {};
    for (const p of products) (acc[p.category || "other"] ||= []).push(p);
    return Object.entries(acc);
  }, [products]);
  const catKey = groups.map(([c]) => c).join("|");

  // Highlight the tab for the section currently under the sticky bar.
  useEffect(() => {
    if (groups.length < 2) return;
    setActiveCat(groups[0][0]);
    const obs = new IntersectionObserver((entries) => {
      const hit = entries.filter((e) => e.isIntersecting)
        .sort((a, b) => a.boundingClientRect.top - b.boundingClientRect.top)[0];
      if (hit) setActiveCat(hit.target.dataset.cat);
    }, { rootMargin: "-72px 0px -65% 0px" });
    groups.forEach(([c]) => sectionRefs.current[c] && obs.observe(sectionRefs.current[c]));
    return () => obs.disconnect();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [catKey]);

  const goBack = () => (window.history.state?.idx > 0 ? navigate(-1) : navigate("/home"));
  const jumpTo = (c) => sectionRefs.current[c]?.scrollIntoView({ behavior: "smooth", block: "start" });
  const bleedTop = { marginTop: "calc(-1 * (var(--safe-t) + 12px))" };

  const backButton = (
    <button
      type="button"
      onClick={goBack}
      aria-label="Back"
      className="press absolute left-4 z-10 grid h-11 w-11 place-items-center rounded-full bg-surface text-ink shadow-lift"
      style={{ top: "calc(var(--safe-t) + 12px)" }}
    >
      <ArrowLeft size={20} strokeWidth={2.25} />
    </button>
  );

  if (loading) {
    return (
      <div className="-mx-4" style={bleedTop} aria-busy="true">
        <Bone className="h-56 w-full rounded-none" />
        <div className="space-y-3 px-4 pt-5">
          <Bone className="h-7 w-2/3" /><Bone className="h-4 w-1/2" />
          <div className="grid grid-cols-2 gap-x-3 gap-y-6 pt-4">{[0, 1, 2, 3].map((i) => <ProductSkeleton key={i} />)}</div>
        </div>
      </div>
    );
  }

  if (!store) {
    return (
      <EmptyState
        icon={StoreIcon}
        title="Shop not found"
        description="This shop may have closed its listing or the link is out of date."
        action={{ label: "Browse shops", to: "/explore" }}
      />
    );
  }

  const closed = !store.open;
  const asRows = ROW_LAYOUT.has(store.category);
  const facts = [
    store.eta && { value: store.eta, label: "Delivery time" },
    { value: Number(store.delivery_fee) > 0 ? formatPrice(store.delivery_fee) : "Free", label: "Delivery fee", brand: !(Number(store.delivery_fee) > 0) },
    categoryLabel(store.category) && { value: categoryLabel(store.category), label: "Category" },
  ].filter(Boolean);

  return (
    <div className="-mx-4" style={bleedTop}>
      {/* Hero */}
      <div className="relative">
        <SmartImage
          src={store.image_url}
          alt={store.name}
          category={store.category}
          fallbackSize={44}
          className={cn("h-56 w-full", closed && "grayscale")}
        />
        {backButton}
      </div>

      {/* Identity sheet overlapping the hero */}
      <div className="relative -mt-6 rounded-t-feature bg-canvas px-4 pt-5">
        <span className={cn(
          "inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-meta font-bold",
          closed ? "bg-danger-soft text-danger" : "bg-brand-soft text-brand"
        )}>
          <span className="h-1.5 w-1.5 rounded-full bg-current" />
          {closed ? "Closed now" : "Open now"}
        </span>
        <h1 className="mt-2 text-title font-extrabold text-ink">{store.name}</h1>
        {store.description && <p className="mt-1 text-body text-ink-2">{store.description}</p>}

        <dl className="mt-4 grid divide-x divide-line rounded-card border border-line bg-surface py-3" style={{ gridTemplateColumns: `repeat(${facts.length}, minmax(0, 1fr))` }}>
          {facts.map((f) => (
            <div key={f.label} className="min-w-0 px-3 text-center">
              <dt className="truncate text-meta text-ink-3">{f.label}</dt>
              <dd className={cn("mt-0.5 truncate text-body font-bold tabular", f.brand ? "text-brand" : "text-ink")}>{f.value}</dd>
            </div>
          ))}
        </dl>

        {store.address && (
          <p className="mt-3 flex items-start gap-1.5 text-secondary text-ink-3">
            <MapPin size={14} strokeWidth={2.25} className="mt-0.5 shrink-0" />
            <span>{store.address}</span>
          </p>
        )}

        {closed && (
          <p className="mt-4 rounded-control bg-offer-soft px-3.5 py-3 text-secondary font-medium text-offer-ink">
            This shop is closed right now. You can look around; ordering opens when it's back.
          </p>
        )}
      </div>

      {/* Sticky category tabs */}
      {groups.length > 1 && (
        <div className="sticky z-20 mt-5 border-b border-line bg-canvas" style={{ top: "var(--safe-t)" }}>
          <div className="flex gap-1 overflow-x-auto px-3 no-scrollbar" role="tablist" aria-label="Product categories">
            {groups.map(([c, items]) => {
              const on = activeCat === c;
              return (
                <button
                  key={c}
                  type="button"
                  role="tab"
                  aria-selected={on}
                  onClick={() => jumpTo(c)}
                  className={cn(
                    "relative h-12 shrink-0 px-3 text-secondary transition-colors",
                    on ? "font-bold text-ink" : "font-medium text-ink-3"
                  )}
                >
                  {categoryLabel(c) || c} <span className="tabular text-ink-3">{items.length}</span>
                  {on && <span className="absolute inset-x-3 bottom-0 h-[3px] rounded-t-full bg-brand" />}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Products */}
      <div className="px-4">
        {products.length === 0 ? (
          <EmptyState icon={Package} title="Nothing on the shelves yet" description="This shop hasn't added products. Check back soon." />
        ) : (
          groups.map(([c, items]) => (
            <section
              key={c}
              data-cat={c}
              ref={(el) => { sectionRefs.current[c] = el; }}
              className="scroll-mt-16 pt-6"
            >
              <h2 className="text-section font-bold text-ink">{categoryLabel(c) || c}</h2>
              {asRows ? (
                <div className="divide-y divide-line">
                  {items.map((p) => <ProductCard key={p.id} product={p} store={store} variant="row" />)}
                </div>
              ) : (
                <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-6">
                  {items.map((p) => <ProductCard key={p.id} product={p} store={store} />)}
                </div>
              )}
            </section>
          ))
        )}
      </div>
    </div>
  );
}
