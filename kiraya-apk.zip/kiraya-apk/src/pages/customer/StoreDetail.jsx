import React, { useState, useEffect, useCallback } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Clock, ShoppingCart, Plus, Minus } from "lucide-react";
import { getStoreById, getAvailableProducts } from "@/lib/db";
import { supabase } from "@/lib/supabase";
import { formatPrice } from "@/lib/appConfig";
import { useCart } from "@/context/CartContext";

export default function StoreDetail() {
  const { id } = useParams();
  const { add, setQty, qtyOf, count } = useCart();
  const [store, setStore]       = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(true);

  const loadProducts = useCallback(async () => {
    const p = await getAvailableProducts(id);
    setProducts(p);
  }, [id]);

  useEffect(() => {
    Promise.all([getStoreById(id), getAvailableProducts(id)]).then(([s, p]) => {
      setStore(s); setProducts(p); setLoading(false);
    });
    // Real-time product updates
    const channel = supabase.channel(`store-products-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "products", filter: `store_id=eq.${id}` },
        loadProducts)
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [id, loadProducts]);

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;
  if (!store) return <div className="py-20 text-center"><p className="text-sm">Store not found.</p></div>;

  const byCategory = products.reduce((acc, p) => {
    const cat = p.category || "other";
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(p);
    return acc;
  }, {});

  const toCartProduct = (p) => ({
    id: p.id, name: p.name, price: p.price,
    image_url: p.image_url, storeId: p.store_id,
    storeDeliveryFee: p.store_delivery_fee ?? store.delivery_fee ?? 29,
  });

  return (
    <div className="space-y-0 -mx-4">
      <div className="relative h-52">
        {store.image_url
          ? <img src={store.image_url} alt={store.name} className="w-full h-full object-cover" />
          : <div className="w-full h-full bg-gradient-to-br from-[hsl(152_58%_38%)] to-[hsl(172_60%_30%)] grid place-items-center">
              <p className="text-5xl font-bold text-white/30">{store.name?.charAt(0)}</p>
            </div>
        }
        <Link to="/home" className="absolute top-4 left-4 press w-10 h-10 rounded-full bg-black/40 backdrop-blur grid place-items-center">
          <ArrowLeft className="w-4.5 h-4.5 text-white" />
        </Link>
        {!store.open && (
          <div className="absolute inset-0 bg-black/50 grid place-items-center">
            <span className="text-white font-semibold bg-black/60 px-4 py-2 rounded-full text-sm">Currently closed</span>
          </div>
        )}
      </div>

      <div className="px-4 space-y-4 pb-28">
        <div className="pt-4">
          <h1 className="text-2xl font-bold">{store.name}</h1>
          {store.description && <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">{store.description}</p>}
          <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-secondary))]">
            {store.eta && <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{store.eta}</span>}
            <span>Delivery {store.delivery_fee > 0 ? formatPrice(store.delivery_fee) : "Free"}</span>
          </div>
        </div>

        {products.length === 0 ? (
          <div className="py-16 text-center"><p className="text-sm text-[hsl(var(--text-tertiary))]">No products available yet</p></div>
        ) : (
          Object.entries(byCategory).map(([cat, items]) => (
            <div key={cat}>
              <h2 className="text-xs font-bold uppercase tracking-wider text-[hsl(var(--text-tertiary))] mb-2 capitalize">{cat}</h2>
              <div className="space-y-2">
                {items.map(product => {
                  const qty = qtyOf(product.id);
                  const cp  = toCartProduct(product);
                  return (
                    <div key={product.id} className="card-soft rounded-2xl p-3 flex gap-3">
                      {product.image_url
                        ? <img src={product.image_url} alt={product.name} className="w-20 h-20 rounded-xl object-cover shrink-0" />
                        : <div className="w-20 h-20 rounded-xl bg-[hsl(var(--muted))] shrink-0 grid place-items-center text-2xl font-bold text-[hsl(var(--text-tertiary))]">{product.name?.charAt(0)}</div>
                      }
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold">{product.name}</p>
                        {product.description && <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5 line-clamp-2">{product.description}</p>}
                        <div className="flex items-center justify-between mt-2">
                          <div>
                            <span className="text-sm font-bold">{formatPrice(product.price)}</span>
                            {product.mrp > product.price && <span className="text-xs text-[hsl(var(--text-tertiary))] line-through ml-1">{formatPrice(product.mrp)}</span>}
                          </div>
                          {qty === 0 ? (
                            <button onClick={() => add(cp)} disabled={!store.open}
                              className="press h-8 w-8 rounded-xl bg-[hsl(var(--accent))] text-white grid place-items-center disabled:opacity-40">
                              <Plus className="w-4 h-4" />
                            </button>
                          ) : (
                            <div className="flex items-center gap-2">
                              <button onClick={() => setQty(product.id, qty - 1)} className="press w-8 h-8 rounded-xl bg-[hsl(var(--muted))] grid place-items-center"><Minus className="w-3.5 h-3.5" /></button>
                              <span className="text-sm font-bold w-4 text-center">{qty}</span>
                              <button onClick={() => add(cp)} className="press w-8 h-8 rounded-xl bg-[hsl(var(--accent))] text-white grid place-items-center"><Plus className="w-3.5 h-3.5" /></button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))
        )}
      </div>

      {count > 0 && (
        <div className="fixed bottom-20 left-4 right-4 z-40">
          <Link to="/cart" className="press flex items-center gap-3 h-14 px-5 rounded-2xl bg-[hsl(var(--accent))] text-white shadow-lg">
            <div className="w-7 h-7 rounded-lg bg-white/20 grid place-items-center text-sm font-bold">{count}</div>
            <span className="flex-1 font-semibold">View cart</span>
            <ShoppingCart className="w-5 h-5" />
          </Link>
        </div>
      )}
    </div>
  );
}
