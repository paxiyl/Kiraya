import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, Bell, MapPin } from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";
import { categories } from "@/data/mockData";
import { getStores } from "@/lib/firestore";
import CategoryStrip from "@/components/customer/CategoryStrip";
import SectionHeader from "@/components/customer/SectionHeader";
import StoreCard from "@/components/customer/StoreCard";
import { useAuth } from "@/lib/AuthContext";

const fade = {
  hidden: { opacity: 0, y: 12 },
  show: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.04, duration: 0.4, ease: [0.22, 1, 0.36, 1] } }),
};

export default function Home() {
  const { profile } = useAuth();
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getStores().then(s => { setStores(s); setLoading(false); }).catch(() => setLoading(false));
  }, []);

  const firstName = profile?.displayName?.split(" ")[0] || "there";

  return (
    <div className="space-y-7">
      <motion.div variants={fade} initial="hidden" animate="show" className="flex items-center gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-[11px] text-[hsl(var(--text-tertiary))] flex items-center gap-1">
            <MapPin className="w-3 h-3" /> Delivering to
          </p>
          <p className="text-sm font-semibold text-[hsl(var(--text-primary))]">{APP_CONFIG.city}</p>
        </div>
        <Link to="/notifications" className="press relative w-10 h-10 rounded-full glass grid place-items-center">
          <Bell className="w-4.5 h-4.5 text-[hsl(var(--text-primary))]" />
        </Link>
        <Link to="/profile" className="press w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] grid place-items-center text-[hsl(var(--accent))] font-semibold text-sm">
          {firstName.charAt(0).toUpperCase()}
        </Link>
      </motion.div>

      <Link to="/explore" className="block">
        <motion.div variants={fade} custom={1} initial="hidden" animate="show"
          className="press flex items-center gap-2.5 h-12 px-4 rounded-2xl glass">
          <Search className="w-4.5 h-4.5 text-[hsl(var(--text-tertiary))]" />
          <span className="text-sm text-[hsl(var(--text-tertiary))]">Search stores & products…</span>
        </motion.div>
      </Link>

      <motion.div variants={fade} custom={2} initial="hidden" animate="show"
        className="relative overflow-hidden rounded-3xl p-5 text-white"
        style={{ background: "linear-gradient(135deg, hsl(152 58% 38%), hsl(172 60% 30%))" }}>
        <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/10 blur-xl" />
        <p className="text-xs/5 opacity-90 font-medium">Hi {firstName} 👋</p>
        <h2 className="text-xl font-bold mt-1 leading-tight">{APP_CONFIG.tagline}</h2>
        <p className="text-xs opacity-85 mt-1">Order from local shops near you.</p>
        <Link to="/explore" className="press inline-flex items-center gap-1 mt-3 px-3 py-1.5 rounded-full bg-white text-[hsl(152 58% 30%)] text-xs font-semibold">
          Explore stores
        </Link>
      </motion.div>

      <motion.section variants={fade} custom={3} initial="hidden" animate="show">
        <CategoryStrip categories={categories} />
      </motion.section>

      <motion.section variants={fade} custom={4} initial="hidden" animate="show">
        <SectionHeader title="Stores near you" action={{ label: "See all", to: "/explore" }} />
        {loading ? (
          <div className="space-y-3">
            {[1,2,3].map(i => <div key={i} className="h-28 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}
          </div>
        ) : stores.length === 0 ? (
          <div className="py-12 text-center">
            <p className="text-sm text-[hsl(var(--text-tertiary))]">No stores available yet.</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))] mt-1">Check back soon!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {stores.map(store => <StoreCard key={store.id} store={store} />)}
          </div>
        )}
      </motion.section>
    </div>
  );
}
