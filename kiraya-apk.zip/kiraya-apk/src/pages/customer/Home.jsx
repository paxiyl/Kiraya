import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Link } from "react-router-dom";
import { Search, Bell, MapPin, ChevronDown, ChevronRight, Zap, BadgePercent, Store as StoreIcon } from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";
import { categories } from "@/data/mockData";
import { getStores, getCatalogProducts } from "@/lib/db";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";
import useUnreadNotifications from "@/hooks/useUnreadNotifications";
import { discountPct, etaMinutes } from "@/lib/cartProduct";
import CategoryStrip from "@/components/customer/CategoryStrip";
import SectionHeader from "@/components/customer/SectionHeader";
import StoreCard from "@/components/customer/StoreCard";
import ProductCard from "@/components/customer/ProductCard";
import SmartImage from "@/components/customer/SmartImage";
import EmptyState, { ErrorState } from "@/components/customer/EmptyState";
import { HomeSkeleton } from "@/components/customer/Skeletons";

const FAST_MINUTES = 30;
const BUDGET = 199;

export default function Home() {
  const { profile } = useAuth();
  const unread = useUnreadNotifications();
  const [stores, setStores] = useState([]);
  const [products, setProducts] = useState([]);
  const [status, setStatus] = useState("loading"); // loading | ready | error

  const load = useCallback(async () => {
    try {
      const [s, p] = await Promise.all([getStores(null, { throwOnError: true }), getCatalogProducts(120)]);
      setStores(s);
      setProducts(p);
      setStatus("ready");
    } catch {
      // Keep showing stale data if a realtime refresh fails.
      setStatus((prev) => (prev === "ready" ? "ready" : "error"));
    }
  }, []);

  useEffect(() => {
    load();
    // Real-time: reload when any store or product changes (unchanged behaviour).
    const channel = supabase.channel("home-stores")
      .on("postgres_changes", { event: "*", schema: "public", table: "stores" }, load)
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, load)
      .subscribe();
    return () => supabase.removeChannel(channel);
  }, [load]);

  const retry = () => { setStatus("loading"); load(); };

  // Every section below is derived from real rows; nothing is invented.
  const view = useMemo(() => {
    const byId = Object.fromEntries(stores.map((s) => [s.id, s]));
    const open = stores.filter((s) => s.open);
    const items = products
      .filter((p) => byId[p.store_id]?.open)
      .map((p) => ({ product: p, store: byId[p.store_id] }));
    const pct = ({ product }) => discountPct(product.price, product.mrp);

    const fast = items.filter(({ store }) => {
      const m = etaMinutes(store.eta);
      return m != null && m <= FAST_MINUTES;
    }).slice(0, 12);
    const deals = items.filter((x) => pct(x) >= 5).sort((a, b) => pct(b) - pct(a)).slice(0, 12);
    const budgetAll = items.filter(({ product }) => Number(product.price) <= BUDGET);
    const budget = budgetAll.slice(0, Math.min(9, Math.floor(budgetAll.length / 3) * 3));
    const fresh = items.slice(0, Math.min(8, Math.floor(items.length / 2) * 2));
    const fastestEta = open.map((s) => etaMinutes(s.eta)).filter((m) => m != null).sort((a, b) => a - b)[0] ?? null;
    const sortedStores = [...stores].sort((a, b) =>
      (b.open === true) - (a.open === true) || (etaMinutes(a.eta) ?? 999) - (etaMinutes(b.eta) ?? 999));

    return { open, fast, deals, budget, fresh, fastestEta, sortedStores };
  }, [stores, products]);

  const city = profile?.address?.city || APP_CONFIG.city;
  const addrLine = profile?.address?.line?.split(",")[0]?.trim();
  const initial = (profile?.display_name?.trim()?.charAt(0) || "U").toUpperCase();

  return (
    <div>
      {/* 1 · Location */}
      <header className="flex items-center gap-2.5">
        <Link to="/profile" className="press min-w-0 flex-1 py-1" aria-label="Change delivery address">
          <p className="flex items-center gap-1 text-meta font-bold text-brand">
            <MapPin size={13} strokeWidth={2.5} /> Delivering to
          </p>
          <p className="mt-0.5 flex items-center gap-1 text-card font-bold text-ink">
            <span className="truncate">{addrLine ? `${addrLine} · ${city}` : city}</span>
            <ChevronDown size={16} strokeWidth={2.5} className="shrink-0 text-ink-2" />
          </p>
        </Link>
        <Link
          to="/notifications"
          aria-label={unread > 0 ? `Notifications, ${unread} unread` : "Notifications"}
          className="press relative grid h-11 w-11 place-items-center rounded-full border border-line bg-surface"
        >
          <Bell size={20} strokeWidth={2} className="text-ink" />
          {unread > 0 && <span className="absolute right-[11px] top-[10px] h-2.5 w-2.5 rounded-full bg-danger ring-2 ring-surface" />}
        </Link>
        <Link to="/profile" aria-label="Profile" className="press shrink-0">
          {profile?.avatar_url ? (
            <SmartImage src={profile.avatar_url} alt="" className="h-11 w-11 rounded-full" />
          ) : (
            <span className="grid h-11 w-11 place-items-center rounded-full bg-brand text-card font-bold text-white">{initial}</span>
          )}
        </Link>
      </header>

      {/* 2 · Search (sticks while scrolling) */}
      <div className="sticky z-20 -mx-4 bg-canvas px-4 pb-4 pt-3" style={{ top: "var(--safe-t)" }}>
        <Link
          to="/explore?focus=1"
          className="press flex h-12 items-center gap-3 rounded-control border border-line bg-surface px-4 shadow-lift"
        >
          <Search size={19} strokeWidth={2.25} className="shrink-0 text-brand" />
          <span className="truncate text-body text-ink-3">Search for groceries, food &amp; more</span>
        </Link>
      </div>

      {status === "loading" && <HomeSkeleton />}
      {status === "error" && <ErrorState onRetry={retry} />}
      {status === "ready" && stores.length === 0 && (
        <EmptyState
          icon={StoreIcon}
          tone="brand"
          title="No shops are live yet"
          description={`Shops in ${APP_CONFIG.city} will show up here as soon as they're approved.`}
        />
      )}

      {status === "ready" && stores.length > 0 && (
        <div className="space-y-8">
          {/* 3 · Promotion, built from live data */}
          <Hero openCount={view.open.length} fastestEta={view.fastestEta} openStores={view.open} />

          {/* 4 · Categories */}
          <section>
            <SectionHeader title="Shop by category" />
            <CategoryStrip categories={categories} />
          </section>

          {/* 5 · Fast delivery */}
          {view.fast.length >= 2 && (
            <section>
              <SectionHeader icon={Zap} title="Delivered fast" subtitle={`From shops that deliver in ${FAST_MINUTES} min or less`} to="/explore?filter=fast" />
              <Rail items={view.fast} />
            </section>
          )}

          {/* 6 · Deals: full-bleed amber band for rhythm */}
          {view.deals.length >= 2 && (
            <section className="-mx-4 bg-offer-soft px-4 pb-5 pt-5">
              <SectionHeader icon={BadgePercent} title="Best deals" subtitle="Biggest savings on MRP right now" />
              <Rail items={view.deals} />
            </section>
          )}

          {/* 7 · Budget grid */}
          {view.budget.length >= 3 && (
            <section>
              <SectionHeader title={`Under ₹${BUDGET}`} subtitle="Everyday picks that are easy on the wallet" />
              <div className="grid grid-cols-3 gap-x-3 gap-y-6">
                {view.budget.map(({ product, store }) => (
                  <ProductCard key={product.id} product={product} store={store} />
                ))}
              </div>
            </section>
          )}

          {/* 8 · Shops: white band, dense list */}
          <section className="-mx-4 border-y border-line bg-surface px-4 pb-2 pt-5">
            <SectionHeader
              title="Shops near you"
              subtitle={`${view.open.length} open now in ${APP_CONFIG.city}`}
              to="/explore"
            />
            <div className="divide-y divide-line">
              {view.sortedStores.slice(0, 6).map((s) => <StoreCard key={s.id} store={s} />)}
            </div>
            {view.sortedStores.length > 6 && (
              <Link to="/explore" className="press flex h-12 items-center justify-center gap-1 border-t border-line text-body font-semibold text-brand">
                See all {view.sortedStores.length} shops <ChevronRight size={16} strokeWidth={2.5} />
              </Link>
            )}
          </section>

          {/* 9 · More discovery */}
          {view.fresh.length >= 2 && (
            <section>
              <SectionHeader title="Just added" subtitle="New on the shelves in Hindaun" />
              <div className="grid grid-cols-2 gap-x-3 gap-y-6">
                {view.fresh.map(({ product, store }) => (
                  <ProductCard key={product.id} product={product} store={store} showStore />
                ))}
              </div>
            </section>
          )}
        </div>
      )}
    </div>
  );
}

function Rail({ items }) {
  return (
    <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1 no-scrollbar">
      {items.map(({ product, store }) => (
        <div key={product.id} className="snap-start">
          <ProductCard product={product} store={store} variant="rail" showStore />
        </div>
      ))}
    </div>
  );
}

function Hero({ openCount, fastestEta, openStores }) {
  const faces = openStores.slice(0, 3);
  return (
    <section
      className="relative overflow-hidden rounded-feature p-5 text-white"
      style={{ background: "radial-gradient(120% 100% at 100% 0%, hsl(var(--accent) / 0.9) 0%, transparent 60%), hsl(var(--accent-deep))" }}
    >
      <p className="text-caption font-semibold text-white/75">{APP_CONFIG.city}</p>
      <h1 className="mt-1 max-w-[230px] text-[24px] font-extrabold leading-[28px] tracking-[-0.02em]">
        {openCount > 0
          ? `${openCount} local ${openCount === 1 ? "shop" : "shops"} open right now`
          : "Shops are closed right now"}
      </h1>
      <p className="mt-1.5 max-w-[230px] text-secondary text-white/80">
        {fastestEta ? `Delivery from ${fastestEta} min, straight from the shop` : "Browse the shelves and order when they open"}
      </p>
      <Link
        to="/explore?filter=open"
        className="press mt-4 inline-flex h-10 items-center gap-1 rounded-control bg-white px-4 text-body font-bold text-brand-deep"
      >
        Browse shops <ChevronRight size={16} strokeWidth={2.5} />
      </Link>
      {faces.length > 0 && (
        <div className="absolute bottom-5 right-5 flex" aria-hidden="true">
          {faces.map((s, i) => (
            <SmartImage
              key={s.id}
              src={s.image_url}
              category={s.category}
              className={`h-12 w-12 rounded-full bg-surface ring-[3px] ring-brand-deep ${i > 0 ? "-ml-3" : ""}`}
            />
          ))}
        </div>
      )}
    </section>
  );
}
