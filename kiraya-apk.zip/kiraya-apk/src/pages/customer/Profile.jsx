import React, { useState } from "react";
import { Link } from "react-router-dom";
import {
  ChevronRight, MapPin, CreditCard, ClipboardList, Heart, Bell, Tag,
  HelpCircle, Settings, LogOut, Shield, Moon, Globe,
} from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";
import { addresses, coupons, orders } from "@/data/mockData";
import { Pill } from "@/components/customer/StatusBadge";

const SECTIONS = [
  { title: "Account", items: [
    { icon: MapPin, label: "Saved addresses", value: `${addresses.length}`, to: "#" },
    { icon: CreditCard, label: "Payment methods", value: "UPI · COD", to: "#" },
    { icon: ClipboardList, label: "Your orders", value: `${orders.length}`, to: "/orders" },
    { icon: Heart, label: "Favorites", value: "—", to: "#" },
    { icon: Tag, label: "Coupons", value: `${coupons.length}`, to: "#" },
  ]},
  { title: "Preferences", items: [
    { icon: Bell, label: "Notifications", to: "#" },
    { icon: Moon, label: "Dark mode", toggle: true },
    { icon: Globe, label: "Language", value: "English", to: "#" },
  ]},
  { title: "Support", items: [
    { icon: HelpCircle, label: "Help & support", to: "/support" },
    { icon: Shield, label: "Privacy & security", to: "#" },
    { icon: Settings, label: "Settings", to: "#" },
  ]},
];

export default function Profile() {
  const [dark, setDark] = useState(false);
  const toggleDark = () => {
    setDark((d) => {
      const next = !d;
      document.documentElement.classList.toggle("dark", next);
      return next;
    });
  };

  return (
    <div className="space-y-5">
      {/* Profile header */}
      <div className="card-soft rounded-3xl p-5 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[hsl(var(--accent))] to-[hsl(172_60%_30%)] text-white grid place-items-center text-xl font-bold">A</div>
        <div className="flex-1">
          <h1 className="text-base font-semibold">Aarav Sharma</h1>
          <p className="text-xs text-[hsl(var(--text-secondary))]">+91 90000 00000</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">aarav@example.com</p>
        </div>
        <Pill tone="accent">Member</Pill>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        {[["Orders", orders.length], ["Saved", addresses.length], ["Coupons", coupons.length]].map(([l, v]) => (
          <div key={l} className="card-soft rounded-2xl p-3 text-center">
            <p className="text-xl font-bold">{v}</p>
            <p className="text-[11px] text-[hsl(var(--text-tertiary))]">{l}</p>
          </div>
        ))}
      </div>

      {/* Sections */}
      {SECTIONS.map((sec) => (
        <div key={sec.title}>
          <p className="text-xs font-semibold text-[hsl(var(--text-tertiary))] uppercase tracking-wide mb-2 px-1">{sec.title}</p>
          <div className="card-soft rounded-2xl overflow-hidden divide-y divide-[hsl(var(--border))]">
            {sec.items.map((it) => {
              const Icon = it.icon;
              return (
                <div key={it.label} className="flex items-center gap-3 px-4 py-3.5">
                  <Icon className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
                  <span className="flex-1 text-sm">{it.label}</span>
                  {it.toggle ? (
                    <button onClick={toggleDark} className={`w-11 h-6 rounded-full transition-colors ${dark ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--border))]"}`}>
                      <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${dark ? "translate-x-5" : "translate-x-0.5"} mt-0.5`} />
                    </button>
                  ) : (
                    <>
                      {it.value && <span className="text-xs text-[hsl(var(--text-tertiary))]">{it.value}</span>}
                      <Link to={it.to || "#"} className="press"><ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" /></Link>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ))}

      <button className="press w-full h-12 rounded-2xl card-soft text-sm font-medium text-[hsl(var(--danger))] flex items-center justify-center gap-2">
        <LogOut className="w-4 h-4" /> Log out
      </button>

      <p className="text-center text-[11px] text-[hsl(var(--text-tertiary))]">{APP_CONFIG.name} v1.0 · {APP_CONFIG.tagline}</p>
    </div>
  );
}