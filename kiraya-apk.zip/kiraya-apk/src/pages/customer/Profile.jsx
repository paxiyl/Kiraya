import React, { useState, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ChevronRight, ClipboardList, LogOut, Moon, Camera, Pencil, Loader2, Shield, FileText, MapPin, Phone } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { upsertProfile, signOut, uploadImage } from "@/lib/db";
import { useToast } from "@/components/ui/use-toast";
import { APP_CONFIG } from "@/lib/appConfig";
import MapPicker from "@/components/MapPicker";

export default function Profile() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate  = useNavigate();
  const { toast } = useToast();
  const [editing, setEditing]     = useState(false);
  const [dark, setDark]           = useState(false);
  const [saving, setSaving]       = useState(false);
  const [uploading, setUploading] = useState(false);
  const [mapOpen, setMapOpen]     = useState(false);
  const fileRef = useRef();

  const [form, setForm] = useState({
    display_name: profile?.display_name || "",
    phone:        (profile?.phone || "").replace("+91",""),
    pin:          profile?.address?.pin || "",
  });
  const [location, setLocation] = useState(
    profile?.address?.line ? { line: profile.address.line, lat: profile.address.lat, lng: profile.address.lng } : null
  );
  const [phoneError, setPhoneError] = useState("");

  const validatePhone = (val) => {
    const d = val.replace(/\D/g,"");
    if (d.length > 0 && d.length !== 10) return "Must be exactly 10 digits";
    if (d.length === 10 && !/^[6-9]/.test(d)) return "Must start with 6, 7, 8 or 9";
    return "";
  };

  const handlePhone = (val) => {
    const d = val.replace(/\D/g,"").slice(0,10);
    setForm(f => ({ ...f, phone: d }));
    setPhoneError(validatePhone(d));
  };

  const handleAvatar = async (file) => {
    setUploading(true);
    try {
      const url = await uploadImage(file, "kiraya/avatars");
      await upsertProfile(user.id, { avatar_url: url });
      await refreshProfile();
      toast({ title: "Photo updated ✓" });
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const saveProfile = async () => {
    if (phoneError) return;
    setSaving(true);
    try {
      await upsertProfile(user.id, {
        display_name: form.display_name,
        phone:        form.phone ? `+91${form.phone}` : "",
        address: {
          line: location?.line || profile?.address?.line || "",
          city: "Hindaun City",
          pin:  form.pin,
          lat:  location?.lat || profile?.address?.lat,
          lng:  location?.lng || profile?.address?.lng,
        },
      });
      await refreshProfile();
      setEditing(false);
      toast({ title: "Profile saved ✓" });
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const logout = async () => { await signOut(); navigate("/login"); };
  const toggleDark = () => {
    setDark(d => { document.documentElement.classList.toggle("dark", !d); return !d; });
  };

  const initial = (profile?.display_name || user?.email || "?").charAt(0).toUpperCase();

  if (mapOpen) return (
    <MapPicker
      initial={location}
      onSelect={(loc) => { setLocation(loc); setMapOpen(false); }}
      onClose={() => setMapOpen(false)}
    />
  );

  return (
    <div className="space-y-5 pb-6">
      {/* Avatar */}
      <div className="card-soft rounded-3xl p-5 flex items-center gap-4">
        <div className="relative">
          <input type="file" ref={fileRef} accept="image/*" className="hidden"
            onChange={e => e.target.files[0] && handleAvatar(e.target.files[0])} />
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[hsl(var(--accent))] to-[hsl(172_60%_30%)] text-white grid place-items-center text-xl font-bold overflow-hidden">
            {profile?.avatar_url ? <img src={profile.avatar_url} className="w-full h-full object-cover" alt="" /> : initial}
          </div>
          <button onClick={() => fileRef.current.click()} disabled={uploading}
            className="press absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-[hsl(var(--accent))] text-white grid place-items-center">
            {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Camera className="w-3 h-3" />}
          </button>
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-semibold truncate">{profile?.display_name || "Set your name"}</h1>
          <p className="text-xs text-[hsl(var(--text-secondary))] truncate">{user?.email}</p>
          {profile?.phone && <p className="text-xs text-[hsl(var(--text-tertiary))]">{profile.phone}</p>}
          {profile?.address?.line && <p className="text-xs text-[hsl(var(--text-tertiary))] truncate">📍 {profile.address.line}</p>}
        </div>
        <button onClick={() => setEditing(true)} className="press w-9 h-9 rounded-xl bg-[hsl(var(--muted))] grid place-items-center">
          <Pencil className="w-4 h-4" />
        </button>
      </div>

      <div className="card-soft rounded-2xl overflow-hidden divide-y divide-[hsl(var(--border))]">
        <Link to="/orders" className="flex items-center gap-3 px-4 py-3.5">
          <ClipboardList className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
          <span className="flex-1 text-sm">My orders</span>
          <ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        </Link>
        <div className="flex items-center gap-3 px-4 py-3.5">
          <Moon className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
          <span className="flex-1 text-sm">Dark mode</span>
          <button onClick={toggleDark}
            className={`w-11 h-6 rounded-full transition-colors ${dark ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--border))]"}`}>
            <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform mt-0.5 ${dark ? "translate-x-5" : "translate-x-0.5"}`} />
          </button>
        </div>
      </div>

      <div className="card-soft rounded-2xl overflow-hidden divide-y divide-[hsl(var(--border))]">
        <Link to="/terms" className="flex items-center gap-3 px-4 py-3.5">
          <FileText className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
          <span className="flex-1 text-sm">Terms of Service</span>
          <ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        </Link>
        <Link to="/privacy" className="flex items-center gap-3 px-4 py-3.5">
          <Shield className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
          <span className="flex-1 text-sm">Privacy Policy</span>
          <ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        </Link>
      </div>

      <button onClick={logout}
        className="press w-full h-12 rounded-2xl card-soft text-sm font-medium text-red-500 flex items-center justify-center gap-2">
        <LogOut className="w-4 h-4" /> Log out
      </button>
      <p className="text-center text-[11px] text-[hsl(var(--text-tertiary))]">{APP_CONFIG.name} v{APP_CONFIG.version} · {APP_CONFIG.city}</p>

      {/* Edit modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setEditing(false)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div onClick={e => e.stopPropagation()} className="relative w-full bg-background rounded-t-3xl p-5 max-h-[85vh] overflow-y-auto">
            <h3 className="text-base font-semibold mb-4">Edit profile</h3>
            <div className="space-y-3">
              <div>
                <label className="text-xs text-[hsl(var(--text-tertiary))]">Full name</label>
                <input type="text" value={form.display_name} onChange={e => setForm(f => ({ ...f, display_name: e.target.value }))}
                  className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
              </div>
              <div>
                <label className="text-xs text-[hsl(var(--text-tertiary))]">Phone (10 digits)</label>
                <div className="relative mt-1">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-medium text-[hsl(var(--text-secondary))]">+91</span>
                  <input type="tel" inputMode="numeric" maxLength={10} value={form.phone}
                    onChange={e => handlePhone(e.target.value)}
                    className={`w-full h-11 pl-12 pr-3 rounded-xl border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))] ${phoneError ? "border-red-400" : "border-[hsl(var(--border))]"}`} />
                </div>
                {phoneError && <p className="text-xs text-red-500 mt-1">{phoneError}</p>}
              </div>
              <div>
                <label className="text-xs text-[hsl(var(--text-tertiary))]">PIN code</label>
                <input type="number" inputMode="numeric" maxLength={6} value={form.pin}
                  onChange={e => setForm(f => ({ ...f, pin: e.target.value.slice(0,6) }))}
                  className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
              </div>
              <button onClick={() => setMapOpen(true)}
                className={`press w-full p-3 rounded-xl border-2 text-left flex items-center gap-3
                  ${location ? "border-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]" : "border-dashed border-[hsl(var(--border))]"}`}>
                <MapPin className={`w-4 h-4 shrink-0 ${location ? "text-[hsl(var(--accent))]" : "text-[hsl(var(--text-tertiary))]"}`} />
                <span className="text-sm line-clamp-1">{location?.line || profile?.address?.line || "Change delivery location"}</span>
              </button>
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setEditing(false)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm">Cancel</button>
              <button onClick={saveProfile} disabled={saving || !!phoneError}
                className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
