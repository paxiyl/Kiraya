import React, { useState, useEffect } from "react";
import { Search, X } from "lucide-react";
import { getStores } from "@/lib/db";
import { categories } from "@/data/mockData";
import StoreCard from "@/components/customer/StoreCard";
import CategoryStrip from "@/components/customer/CategoryStrip";

export default function Explore() {
  const [stores, setStores]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState("");
  const [cat, setCat]         = useState(null);

  useEffect(() => {
    setLoading(true);
    getStores(cat || undefined).then(s => { setStores(s); setLoading(false); });
  }, [cat]);

  const filtered = search
    ? stores.filter(s =>
        s.name?.toLowerCase().includes(search.toLowerCase()) ||
        s.category?.toLowerCase().includes(search.toLowerCase()) ||
        s.description?.toLowerCase().includes(search.toLowerCase())
      )
    : stores;

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold tracking-tight">Explore</h1>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        <input
          className="w-full h-11 pl-9 pr-9 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
          placeholder="Search stores…"
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
        {search && (
          <button onClick={() => setSearch("")} className="absolute right-3 top-1/2 -translate-y-1/2">
            <X className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
          </button>
        )}
      </div>

      <CategoryStrip
        categories={categories}
        active={cat}
        onSelect={c => setCat(c === cat ? null : c)}
      />

      {loading ? (
        <div className="space-y-3">
          {[1,2,3].map(i => <div key={i} className="h-44 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="py-20 text-center space-y-2">
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No stores found</p>
          {(cat || search) && (
            <button onClick={() => { setCat(null); setSearch(""); }}
              className="text-[hsl(var(--accent))] text-sm font-medium">
              Clear filters
            </button>
          )}
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(store => <StoreCard key={store.id} store={store} />)}
        </div>
      )}
    </div>
  );
}
