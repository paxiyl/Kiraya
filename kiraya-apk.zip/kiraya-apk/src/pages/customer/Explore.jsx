import React, { useState, useEffect, useMemo, useRef, useCallback } from "react";
import { useSearchParams } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, X, Store as StoreIcon } from "lucide-react";
import { getStores, searchProducts } from "@/lib/db";
import { categories } from "@/data/mockData";
import { etaMinutes } from "@/lib/cartProduct";
import { spring } from "@/lib/motion";
import { cn } from "@/lib/utils";
import StoreCard from "@/components/customer/StoreCard";
import ProductCard from "@/components/customer/ProductCard";
import CategoryStrip from "@/components/customer/CategoryStrip";
import SectionHeader from "@/components/customer/SectionHeader";
import { categoryLabel } from "@/components/customer/SmartImage";
import EmptyState, { ErrorState } from "@/components/customer/EmptyState";
import { StoreSkeleton, ProductSkeleton } from "@/components/customer/Skeletons";

const FAST_MINUTES = 30;
// Only filters backed by real store fields (open, eta, delivery_fee).
const FILTERS = [
  { id: "all", label: "All" },
  { id: "open", label: "Open now" },
  { id: "fast", label: "Delivered fast" },
  { id: "free", label: "Free delivery" },
];

export default function Explore() {
  const [params, setParams] = useSearchParams();
  const cat = params.get("cat");
  const filter = FILTERS.some((f) => f.id === params.get("filter")) ? params.get("filter") : "all";
  const inputRef = useRef(null);

  const [stores, setStores] = useState([]);
  const [status, setStatus] = useState("loading");
  const [search, setSearch] = useState("");
  const [products, setProducts] = useState({ status: "idle", items: [] });

  const setParam = (key, value) => {
    const next = new URLSearchParams(params);
    if (!value || value === "all") next.delete(key); else next.set(key, value);
    next.delete("focus");
    setParams(next, { replace: true });
  };

  const load = useCallback(() => {
    setStatus("loading");
    getStores(null, { throwOnError: true })
      .then((s) => { setStores(s); setStatus("ready"); })
      .catch(() => setStatus("error"));
  }, []);
  useEffect(() => { load(); }, [load]);

  // Arriving from the Home search bar focuses the field.
  useEffect(() => {
    if (params.get("focus")) inputRef.current?.focus();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Debounced product search across all shops.
  useEffect(() => {
    const term = search.trim();
    if (term.length < 2) { setProducts({ status: "idle", items: [] }); return; }
    setProducts((r) => ({ ...r, status: "loading" }));
    let cancelled = false;
    const t = setTimeout(() => {
      searchProducts(term)
        .then((items) => !cancelled && setProducts({ status: "ready", items }))
        .catch(() => !cancelled && setProducts({ status: "error", items: [] }));
    }, 250);
    return () => { cancelled = true; clearTimeout(t); };
  }, [search]);

  const storeById = useMemo(() => Object.fromEntries(stores.map((s) => [s.id, s])), [stores]);

  const visibleStores = useMemo(() => {
    const q = search.trim().toLowerCase();
    return stores
      .filter((s) => {
        if (cat && s.category !== cat) return false;
        if (filter === "open" && !s.open) return false;
        if (filter === "fast") {
          const m = etaMinutes(s.eta);
          if (!s.open || m == null || m > FAST_MINUTES) return false;
        }
        if (filter === "free" && Number(s.delivery_fee) > 0) return false;
        if (q) {
          const hay = [s.name, s.category, s.description, categoryLabel(s.category)].join(" ").toLowerCase();
          if (!hay.includes(q)) return false;
        }
        return true;
      })
      .sort((a, b) => (b.open === true) - (a.open === true));
  }, [stores, cat, filter, search]);

  const productHits = useMemo(() => products.items
    .filter((p) => storeById[p.store_id])
    .filter((p) => !cat || p.category === cat)
    .slice(0, 12), [products.items, storeById, cat]);

  const searching = search.trim().length >= 2;
  const hasFilters = Boolean(cat || filter !== "all" || search);
  const clearAll = () => { setSearch(""); setParams({}, { replace: true }); };

  return (
    <div>
      <h1 className="text-title font-extrabold text-ink">Explore</h1>

      <div className="group relative mt-4">
        <Search
          size={19}
          strokeWidth={2.25}
          className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-ink-3 transition-colors group-focus-within:text-brand"
        />
        <input
          ref={inputRef}
          type="search"
          enterKeyHint="search"
          autoComplete="off"
          className="h-12 w-full rounded-control border border-line bg-surface pl-11 pr-12 text-body text-ink outline-none transition-[border-color,box-shadow] duration-150 placeholder:text-ink-3 focus:border-brand focus:shadow-[0_0_0_4px_hsl(var(--accent)/0.14)] [&::-webkit-search-cancel-button]:hidden"
          placeholder="Search for groceries, food & more"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          aria-label="Search shops and products"
        />
        {search && (
          <button
            type="button"
            onClick={() => { setSearch(""); inputRef.current?.focus(); }}
            className="absolute right-1 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center text-ink-3"
            aria-label="Clear search"
          >
            <X size={18} strokeWidth={2.25} />
          </button>
        )}
      </div>

      <CategoryStrip
        className="mt-5"
        categories={categories}
        active={cat}
        onSelect={(id) => setParam("cat", id === cat ? null : id)}
      />

      <div className="-mx-4 mt-4 flex gap-2 overflow-x-auto px-4 pb-1 no-scrollbar" role="tablist" aria-label="Filters">
        {FILTERS.map((f) => {
          const active = filter === f.id;
          return (
            <button
              key={f.id}
              type="button"
              role="tab"
              aria-selected={active}
              onClick={() => setParam("filter", f.id)}
              className={cn(
                "relative h-9 shrink-0 rounded-full px-4 text-secondary font-semibold transition-colors",
                active ? "text-white" : "border border-line bg-surface text-ink-2"
              )}
            >
              {active && <motion.span layoutId="explore-filter" className="absolute inset-0 rounded-full bg-ink" transition={spring} />}
              <span className="relative">{f.label}</span>
            </button>
          );
        })}
      </div>

      {searching && (
        <section className="mt-7">
          <SectionHeader title="Products" subtitle={products.status === "ready" ? `${productHits.length} found` : undefined} />
          {products.status === "loading" && (
            <div className="grid grid-cols-2 gap-x-3 gap-y-6">{[0, 1].map((i) => <ProductSkeleton key={i} />)}</div>
          )}
          {products.status === "error" && <ErrorState description="We couldn't search products right now." />}
          {products.status === "ready" && productHits.length === 0 && (
            <p className="py-2 text-secondary text-ink-3">No products match “{search.trim()}”.</p>
          )}
          {products.status === "ready" && productHits.length > 0 && (
            <div className="grid grid-cols-2 gap-x-3 gap-y-6">
              {productHits.map((p) => (
                <ProductCard key={p.id} product={p} store={storeById[p.store_id]} showStore />
              ))}
            </div>
          )}
        </section>
      )}

      <section className="mt-7">
        {status === "ready" && visibleStores.length > 0 && (
          <SectionHeader
            title={searching ? "Shops" : cat ? categoryLabel(cat) || "Shops" : "All shops"}
            subtitle={`${visibleStores.length} ${visibleStores.length === 1 ? "shop" : "shops"}`}
          />
        )}
        {status === "loading" && <div className="divide-y divide-line">{[0, 1, 2, 3].map((i) => <StoreSkeleton key={i} />)}</div>}
        {status === "error" && <ErrorState onRetry={load} />}
        {status === "ready" && visibleStores.length === 0 && (!searching || productHits.length === 0) && (
          <EmptyState
            icon={StoreIcon}
            title={hasFilters ? "No shops match" : "No shops yet"}
            description={hasFilters ? "Try another category or clear the filters." : "Shops will appear here once they're approved."}
            action={hasFilters ? { label: "Clear filters", onClick: clearAll } : undefined}
          />
        )}
        {status === "ready" && visibleStores.length > 0 && (
          <div className="-mx-4 divide-y divide-line border-y border-line bg-surface px-4">
            {visibleStores.map((store) => <StoreCard key={store.id} store={store} />)}
          </div>
        )}
      </section>
    </div>
  );
}
