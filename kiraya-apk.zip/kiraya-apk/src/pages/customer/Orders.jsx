import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ShoppingBag, ChevronRight } from "lucide-react";
import { getMyOrders } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import StatusBadge from "@/components/customer/StatusBadge";

export default function Orders() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    getMyOrders(user.id).then(o => { setOrders(o); setLoading(false); });
  }, [user]);

  if (loading) return (
    <div className="py-20 text-center">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" />
    </div>
  );

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-bold tracking-tight">My Orders</h1>

      {orders.length === 0 ? (
        <div className="py-20 text-center space-y-3">
          <ShoppingBag className="w-12 h-12 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No orders yet</p>
          <Link to="/explore" className="text-[hsl(var(--accent))] text-sm font-medium">Browse stores</Link>
        </div>
      ) : (
        <div className="space-y-2">
          {orders.map(order => (
            <Link key={order.id} to={`/orders/${order.id}`} className="press block card-soft rounded-2xl p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] font-mono">#{order.id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm font-semibold mt-0.5">
                    {order.items?.length} item{order.items?.length !== 1 ? "s" : ""}
                  </p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5 line-clamp-1">
                    {order.items?.map(i => i.name).join(", ")}
                  </p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">
                    {new Date(order.created_at).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1.5">
                  <p className="font-bold text-sm">{formatPrice(order.total)}</p>
                  <StatusBadge status={order.status} />
                  <ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
