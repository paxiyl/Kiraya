import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { CheckCircle2, ArrowLeft, Phone } from "lucide-react";
import { listenOrder } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";

const STEPS = [
  { status: "PENDING",          label: "Order placed",       desc: "Your order has been received" },
  { status: "PREPARING",        label: "Preparing",          desc: "The store is preparing your order" },
  { status: "READY",            label: "Ready for pickup",   desc: "Waiting for a delivery partner" },
  { status: "OUT_FOR_DELIVERY", label: "On the way",         desc: "Your order is out for delivery" },
  { status: "DELIVERED",        label: "Delivered",          desc: "Enjoy your order!" },
];

export default function OrderTracking() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = listenOrder(id, o => { setOrder(o); setLoading(false); });
    return unsub;
  }, [id]);

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;
  if (!order) return <div className="py-20 text-center"><p className="text-sm text-[hsl(var(--text-tertiary))]">Order not found.</p><Link to="/orders" className="text-[hsl(var(--accent))] text-sm font-medium">My orders</Link></div>;

  const stepIdx = STEPS.findIndex(s => s.status === order.status);
  const isCancelled = order.status === "CANCELLED";

  return (
    <div className="space-y-5">
      <div className="flex items-center gap-3">
        <Link to="/orders" className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></Link>
        <div>
          <h1 className="text-lg font-semibold">Track Order</h1>
          <p className="text-xs text-[hsl(var(--text-tertiary))] font-mono">#{id.slice(-6).toUpperCase()}</p>
        </div>
      </div>

      {isCancelled ? (
        <div className="card-soft rounded-2xl p-5 text-center space-y-2">
          <p className="text-2xl">❌</p>
          <p className="font-semibold">Order Cancelled</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">This order was cancelled. Refund (if applicable) will be processed within 3–5 days.</p>
        </div>
      ) : (
        <div className="card-soft rounded-2xl p-4">
          <div className="space-y-4">
            {STEPS.map((step, i) => {
              const done = i < stepIdx;
              const active = i === stepIdx;
              return (
                <div key={step.status} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-7 h-7 rounded-full grid place-items-center shrink-0 ${done ? "bg-green-500" : active ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--muted))]"}`}>
                      {done ? <CheckCircle2 className="w-4 h-4 text-white" /> : <span className={`text-[10px] font-bold ${active ? "text-white" : "text-[hsl(var(--text-tertiary))]"}`}>{i + 1}</span>}
                    </div>
                    {i < STEPS.length - 1 && <div className={`w-0.5 flex-1 mt-1 min-h-4 ${done ? "bg-green-500" : "bg-[hsl(var(--muted))]"}`} />}
                  </div>
                  <div className="pb-4">
                    <p className={`text-sm font-semibold ${active ? "text-[hsl(var(--accent))]" : done ? "" : "text-[hsl(var(--text-tertiary))]"}`}>{step.label}</p>
                    {active && <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{step.desc}</p>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Order summary */}
      <div className="card-soft rounded-2xl p-4 space-y-2">
        <h3 className="text-sm font-semibold">Order summary</h3>
        {order.items?.map((item, i) => (
          <div key={i} className="flex justify-between text-sm">
            <span className="text-[hsl(var(--text-secondary))]">{item.name} × {item.qty}</span>
            <span>{formatPrice(item.price * item.qty)}</span>
          </div>
        ))}
        <div className="border-t border-[hsl(var(--border))] pt-2 flex justify-between font-semibold text-sm">
          <span>Total paid</span><span>{formatPrice(order.total)}</span>
        </div>
      </div>

      {/* Delivery address */}
      <div className="card-soft rounded-2xl p-4 space-y-1">
        <h3 className="text-sm font-semibold mb-2">Delivery address</h3>
        <p className="text-sm text-[hsl(var(--text-secondary))]">{order.address?.line}</p>
        <p className="text-sm text-[hsl(var(--text-secondary))]">{order.address?.city} — {order.address?.pin}</p>
        <p className="text-sm font-medium">{order.address?.phone}</p>
      </div>
    </div>
  );
}
