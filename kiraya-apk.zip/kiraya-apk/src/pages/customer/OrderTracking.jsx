import React, { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import { CheckCircle2, ArrowLeft, Star, Loader2 } from "lucide-react";
import { getOrderById, listenOrder } from "@/lib/db";
import { supabase } from "@/lib/supabase";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";

const STEPS = [
  { status:"PENDING",          label:"Order placed",     desc:"Store has received your order" },
  { status:"PREPARING",        label:"Preparing",        desc:"Store is preparing your order" },
  { status:"READY",            label:"Ready for pickup",  desc:"Waiting for delivery partner" },
  { status:"OUT_FOR_DELIVERY", label:"On the way",       desc:"Your order is heading to you!" },
  { status:"DELIVERED",        label:"Delivered ✓",      desc:"Enjoy! 🎉" },
];
export default function OrderTracking() {
  const { id } = useParams();
  const { user } = useAuth();
  const { toast } = useToast();
  const [order, setOrder]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [rating, setRating]   = useState(0);
  const [review, setReview]   = useState("");
  const [rated, setRated]     = useState(false);
  const [submitting, setSubmitting] = useState(false);
  useEffect(() => {
    getOrderById(id).then(o => { setOrder(o); setLoading(false); if (o?.rating) { setRated(true); setRating(o.rating); } });
    const unsub = listenOrder(id, o => { setOrder(o); if (o?.rating) setRated(true); });
    return unsub;
  }, [id]);
  const submitRating = async () => {
    if (!rating) return;
    setSubmitting(true);
    try {
      // Save rating on order
      await supabase.from("orders").update({ rating, review }).eq("id", id);
      // Save as store review
      if (order?.store_id) {
        await supabase.from("reviews").upsert({
          store_id:    order.store_id,
          customer_id: user.id,
          customer_name: order.customer_name,
          order_id:    id,
          rating,
          comment:     review,
        });
      }
      setRated(true);
      toast({ title:"Review submitted! Thanks 🙏" });
    } catch (e) {
      toast({ title:"Error", description:e.message, variant:"destructive" });
    } finally { setSubmitting(false); }
  };
  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;
  if (!order) return <div className="py-20 text-center space-y-3"><p className="text-sm text-[hsl(var(--text-tertiary))]">Order not found.</p><Link to="/orders" className="text-[hsl(var(--accent))] text-sm font-medium">My orders</Link></div>;
  const stepIdx = STEPS.findIndex(s => s.status === order.status);
  const isCancelled = order.status === "CANCELLED";
  const isDelivered = order.status === "DELIVERED";
  return (
    <div className="space-y-5 pb-6">
      <div className="flex items-center gap-3">
        <Link to="/orders" className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></Link>
        <div>
          <h1 className="text-lg font-semibold">Track Order</h1>
          <p className="text-xs text-[hsl(var(--text-tertiary))] font-mono">#{id.slice(-6).toUpperCase()}</p>
        </div>
      </div>
      {isCancelled ? (
        <div className="card-soft rounded-2xl p-6 text-center space-y-2">
          <p className="text-3xl">❌</p>
          <p className="font-semibold">Order Cancelled</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">Refund (if applicable) within 3–5 business days.</p>
      ) : (
        <div className="card-soft rounded-2xl p-4">
          <div className="space-y-4">
            {STEPS.map((step, i) => {
              const done   = i < stepIdx;
              const active = i === stepIdx;
              return (
                <div key={step.status} className="flex gap-3">
                  <div className="flex flex-col items-center">
                    <div className={`w-7 h-7 rounded-full grid place-items-center shrink-0 transition-colors
                      ${done ? "bg-green-500" : active ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--muted))]"}`}>
                      {done ? <CheckCircle2 className="w-4 h-4 text-white" />
                            : <span className={`text-[10px] font-bold ${active ? "text-white" : "text-[hsl(var(--text-tertiary))]"}`}>{i+1}</span>}
                    </div>
                    {i < STEPS.length-1 && <div className={`w-0.5 flex-1 mt-1 min-h-4 ${done ? "bg-green-500" : "bg-[hsl(var(--muted))]"}`} />}
                  </div>
                  <div className="pb-4">
                    <p className={`text-sm font-semibold ${active ? "text-[hsl(var(--accent))]" : done ? "" : "text-[hsl(var(--text-tertiary))]"}`}>{step.label}</p>
                    {active && <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{step.desc}</p>}
                </div>
              );
            })}
          </div>
      )}
      {/* Rating — show after delivery */}
      {isDelivered && (
        <div className="card-soft rounded-2xl p-4 space-y-3">
          <h3 className="text-sm font-semibold">Rate your experience</h3>
          {rated ? (
            <div className="text-center space-y-1">
              <div className="flex justify-center gap-1">{[1,2,3,4,5].map(s => <Star key={s} className={`w-6 h-6 ${s<=rating ? "fill-yellow-400 text-yellow-400" : "text-[hsl(var(--muted))]"}`} />)}</div>
              <p className="text-xs text-green-600 font-medium">Review submitted ✓</p>
            </div>
          ) : (
            <>
              <div className="flex justify-center gap-2">
                {[1,2,3,4,5].map(s => (
                  <button key={s} onClick={() => setRating(s)} className="press">
                    <Star className={`w-8 h-8 transition-colors ${s<=rating ? "fill-yellow-400 text-yellow-400" : "text-[hsl(var(--border))]"}`} />
                  </button>
                ))}
              </div>
              <textarea rows={2} placeholder="Tell us what you thought (optional)…" value={review}
                onChange={e => setReview(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-[hsl(var(--border))] bg-background text-sm resize-none focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
              <button onClick={submitRating} disabled={!rating || submitting}
                className="press w-full h-11 rounded-xl bg-[hsl(var(--accent))] text-white font-semibold text-sm disabled:opacity-50 flex items-center justify-center gap-2">
                {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Submit review"}
              </button>
            </>
          )}
      <div className="card-soft rounded-2xl p-4 space-y-2">
        <h3 className="text-sm font-semibold">Order summary</h3>
        {(order.items||[]).map((item,i) => (
          <div key={i} className="flex justify-between text-sm">
            <span className="text-[hsl(var(--text-secondary))]">{item.name} × {item.qty}</span>
            <span>{formatPrice(item.price*item.qty)}</span>
        ))}
        <div className="border-t border-[hsl(var(--border))] pt-2 space-y-1">
          {[["Delivery fee",order.delivery_fee],["Taxes",order.taxes],["Platform fee",order.platform_fee]].map(([l,v])=>(
            <div key={l} className="flex justify-between text-xs text-[hsl(var(--text-tertiary))]"><span>{l}</span><span>{formatPrice(v)}</span></div>
          ))}
          <div className="flex justify-between font-bold text-sm pt-1"><span>Total paid</span><span>{formatPrice(order.total)}</span></div>
      <div className="card-soft rounded-2xl p-4 space-y-1">
        <h3 className="text-sm font-semibold mb-1">Delivery address</h3>
        <p className="text-sm text-[hsl(var(--text-secondary))]">{order.address?.line}</p>
        <p className="text-sm text-[hsl(var(--text-secondary))]">Hindaun City — {order.address?.pin}</p>
        <p className="text-sm font-medium">{order.address?.phone}</p>
    </div>
  );
}
