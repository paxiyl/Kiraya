import React, { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Phone, MessageCircle, Star, MapPin, Navigation, Check } from "lucide-react";
import { orders } from "@/data/mockData";
import StatusBadge from "@/components/customer/StatusBadge";
import { formatPrice } from "@/lib/appConfig";
import { motion } from "framer-motion";

const STEPS = [
  { id: "PENDING", label: "Order confirmed" },
  { id: "ACCEPTED", label: "Store preparing" },
  { id: "PICKED_UP", label: "Picked up" },
  { id: "OUT_FOR_DELIVERY", label: "On the way" },
  { id: "DELIVERED", label: "Delivered" },
];
const ORDER = ["PENDING", "ACCEPTED", "PICKED_UP", "OUT_FOR_DELIVERY", "DELIVERED"];

export default function OrderTracking() {
  const { id } = useParams();
  const navigate = useNavigate();
  const order = orders.find((o) => o.id === id);
  const [showMap] = useState(true);

  if (!order) return <div className="py-20 text-center text-sm">Order not found. <Link to="/orders" className="text-[hsl(var(--accent))]">Back to orders</Link></div>;

  const currentIdx = ORDER.indexOf(order.status);
  const done = order.status === "DELIVERED";

  return (
    <div className="space-y-4 -mx-4">
      <div className="px-4 flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
        <h1 className="text-lg font-semibold">Track order</h1>
      </div>

      {/* Map placeholder */}
      <div className="px-4">
        <div className="relative w-full h-52 rounded-3xl overflow-hidden bg-[hsl(var(--surface-2))]">
          <div className="absolute inset-0 opacity-60"
            style={{ backgroundImage: "linear-gradient(hsl(var(--border)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)", backgroundSize: "28px 28px" }} />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/10" />
          <div className="absolute top-1/2 left-6 w-3 h-3 rounded-full bg-[hsl(var(--accent))] ring-4 ring-[hsl(var(--accent)/0.25)]" />
          <div className="absolute top-1/2 right-8 w-3 h-3 rounded-full bg-[hsl(var(--warning))] ring-4 ring-[hsl(var(--warning)/0.25)]" />
          <motion.div className="absolute top-1/2 left-1/3 w-8 h-8 rounded-full bg-[hsl(var(--accent))] text-white grid place-items-center shadow-lg"
            animate={{ x: [0, 40, 0], y: [0, -6, 0] }} transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}>
            <Navigation className="w-4 h-4" />
          </motion.div>
          <div className="absolute bottom-3 left-3 right-3 glass rounded-2xl px-3 py-2 flex items-center justify-between">
            <span className="text-xs font-medium">{order.eta}</span>
            <StatusBadge status={order.status} />
          </div>
        </div>
      </div>

      {/* ETA + partner */}
      <div className="px-4 card-soft rounded-2xl p-4 flex items-center gap-3">
        <div className="w-11 h-11 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center font-semibold">{order.partner?.name?.charAt(0) || "—"}</div>
        <div className="flex-1">
          <p className="text-sm font-semibold">{order.partner?.name || "Assigning partner…"}</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))] inline-flex items-center gap-1"><Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {order.partner?.rating || "—"} · Delivery partner</p>
        </div>
        <button className="press w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center"><Phone className="w-4 h-4" /></button>
        <button className="press w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center"><MessageCircle className="w-4 h-4" /></button>
      </div>

      {/* Progress */}
      <div className="px-4 card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Order status</h3>
        <div className="space-y-0">
          {STEPS.map((s, i) => {
            const reached = i <= currentIdx;
            const active = i === currentIdx && !done;
            return (
              <div key={s.id} className="flex gap-3">
                <div className="flex flex-col items-center">
                  <div className={`w-6 h-6 rounded-full grid place-items-center ${reached ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-tertiary))]"}`}>
                    {reached ? <Check className="w-3.5 h-3.5" /> : <span className="w-1.5 h-1.5 rounded-full bg-current" />}
                  </div>
                  {i < STEPS.length - 1 && <div className={`w-0.5 flex-1 min-h-6 ${i < currentIdx ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--border))]"}`} />}
                </div>
                <div className="pb-4">
                  <p className={`text-sm ${active ? "font-semibold text-[hsl(var(--accent))]" : reached ? "font-medium" : "text-[hsl(var(--text-tertiary))]"}`}>{s.label}</p>
                  {active && <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{order.eta}</p>}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Order details */}
      <div className="px-4 card-soft rounded-2xl p-4 space-y-2">
        <div className="flex justify-between"><span className="text-xs text-[hsl(var(--text-tertiary))]">Order ID</span><span className="text-sm font-medium">{order.id}</span></div>
        <div className="flex justify-between"><span className="text-xs text-[hsl(var(--text-tertiary))]">Store</span><span className="text-sm font-medium">{order.store}</span></div>
        <div className="flex justify-between"><span className="text-xs text-[hsl(var(--text-tertiary))]">Items</span><span className="text-sm font-medium text-right">{order.items.join(", ")}</span></div>
        <div className="flex justify-between border-t border-[hsl(var(--border))] pt-2"><span className="text-sm font-semibold">Total</span><span className="text-sm font-bold">{formatPrice(order.total)}</span></div>
      </div>

      <div className="px-4">
        <Link to="/support" className="press w-full h-11 rounded-2xl card-soft text-sm font-medium flex items-center justify-center gap-2">
          <MessageCircle className="w-4 h-4" /> Need help with this order?
        </Link>
      </div>
    </div>
  );
}