import React, { useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Star, Zap, Heart, Share2, Plus, Minus, ShieldCheck } from "lucide-react";
import { getProduct, getStore, productsByStore } from "@/data/mockData";
import { formatPrice } from "@/lib/appConfig";
import Media from "@/components/customer/Media";
import ProductCard from "@/components/customer/ProductCard";
import { useCart } from "@/context/CartContext";
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function ProductDetail() {
  const { id } = useParams();
  const product = getProduct(id);
  const { add, setQty, qtyOf } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [fav, setFav] = useState(false);

  if (!product) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm text-[hsl(var(--text-secondary))]">Product not found.</p>
        <Link to="/" className="text-[hsl(var(--accent))] text-sm font-medium">Back home</Link>
      </div>
    );
  }
  const store = getStore(product.storeId);
  const related = productsByStore(product.storeId).filter((p) => p.id !== product.id).slice(0, 4);
  const qty = qtyOf(product.id);
  const off = product.mrp > product.price ? Math.round(((product.mrp - product.price) / product.mrp) * 100) : 0;

  const onAdd = () => {
    add(product.id);
    toast({ title: "Added to cart", description: product.name });
  };

  return (
    <div className="space-y-5 -mx-4">
      <div className="px-4 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center">
          <ArrowLeft className="w-4.5 h-4.5" />
        </button>
        <div className="flex gap-2">
          <button className="press w-10 h-10 rounded-full glass grid place-items-center"><Share2 className="w-4 h-4" /></button>
          <button onClick={() => setFav(!fav)} className="press w-10 h-10 rounded-full glass grid place-items-center">
            <Heart className={`w-4 h-4 ${fav ? "fill-[hsl(var(--danger))] text-[hsl(var(--danger))]" : ""}`} />
          </button>
        </div>
      </div>

      <div className="px-4">
        <Media category={product.category} label={product.name} className="w-full h-72 rounded-3xl" />
      </div>

      <div className="px-4 space-y-4">
        <div>
          <div className="flex items-center gap-2 flex-wrap">
            {product.badge && <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]">{product.badge}</span>}
            {off > 0 && <span className="px-2 py-0.5 rounded-full text-[11px] font-semibold bg-[hsl(var(--success-soft))] text-[hsl(var(--success))]">{off}% OFF</span>}
          </div>
          <h1 className="text-xl font-bold mt-2 text-[hsl(var(--text-primary))]">{product.name}</h1>
          <Link to={`/store/${store?.id}`} className="text-sm text-[hsl(var(--text-secondary))] mt-1 inline-block hover:text-[hsl(var(--accent))]">
            by {product.storeName} →
          </Link>
        </div>

        <div className="flex items-center gap-4 text-sm">
          <span className="inline-flex items-center gap-1 font-medium"><Star className="w-4 h-4 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {product.rating}</span>
          <span className="inline-flex items-center gap-1 text-[hsl(var(--accent))]"><Zap className="w-4 h-4" /> {product.eta}</span>
          <span className="inline-flex items-center gap-1 text-[hsl(var(--text-secondary))]"><ShieldCheck className="w-4 h-4" /> In stock</span>
        </div>

        <div className="flex items-baseline gap-2">
          <span className="text-2xl font-bold">{formatPrice(product.price)}</span>
          {product.mrp > product.price && <span className="text-sm text-[hsl(var(--text-tertiary))] line-through">{formatPrice(product.mrp)}</span>}
        </div>

        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-1">About this product</h3>
          <p className="text-sm text-[hsl(var(--text-secondary))] leading-relaxed">
            Freshly prepared / sourced from {product.storeName}. Carefully packed and delivered to your door in {product.eta}. Quality checked before dispatch.
          </p>
        </div>

        <div className="card-soft rounded-2xl p-4 grid grid-cols-2 gap-y-3 text-sm">
          <div><p className="text-xs text-[hsl(var(--text-tertiary))]">Store</p><p className="font-medium">{product.storeName}</p></div>
          <div><p className="text-xs text-[hsl(var(--text-tertiary))]">Delivery</p><p className="font-medium">{product.eta}</p></div>
          <div><p className="text-xs text-[hsl(var(--text-tertiary))]">Delivery fee</p><p className="font-medium">{store?.fee === 0 ? "Free" : formatPrice(store?.fee)}</p></div>
          <div><p className="text-xs text-[hsl(var(--text-tertiary))]">Availability</p><p className="font-medium text-[hsl(var(--success))]">In stock</p></div>
        </div>

        {related.length > 0 && (
          <section>
            <h3 className="text-sm font-semibold mb-2">More from {product.storeName}</h3>
            <div className="grid grid-cols-2 gap-3">{related.map((p) => <ProductCard key={p.id} product={p} />)}</div>
          </section>
        )}
      </div>

      {/* Sticky bottom CTA */}
      <div className="fixed bottom-0 inset-x-0 z-40 glass-strong border-t border-[hsl(var(--glass-border))] safe-bottom">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
          <AnimatePresence mode="popLayout" initial={false}>
            {qty === 0 ? (
              <motion.button key="c" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                onClick={onAdd}
                className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] font-semibold flex items-center justify-center gap-2">
                <Plus className="w-4 h-4" /> Add to cart · {formatPrice(product.price)}
              </motion.button>
            ) : (
              <motion.div key="q" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
                className="flex-1 flex items-center justify-between h-12 rounded-2xl bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] px-2">
                <button onClick={() => setQty(product.id, qty - 1)} className="press w-10 h-10 grid place-items-center"><Minus className="w-4 h-4" /></button>
                <span className="font-bold tabular-nums">{qty} in cart · {formatPrice(product.price * qty)}</span>
                <button onClick={() => setQty(product.id, qty + 1)} className="press w-10 h-10 grid place-items-center"><Plus className="w-4 h-4" /></button>
              </motion.div>
            )}
          </AnimatePresence>
          <button onClick={() => { if (!qty) add(product.id); navigate("/cart"); }}
            className="press h-12 px-5 rounded-2xl card-soft font-semibold text-sm">Buy now</button>
        </div>
      </div>
      <div className="h-24" />
    </div>
  );
}