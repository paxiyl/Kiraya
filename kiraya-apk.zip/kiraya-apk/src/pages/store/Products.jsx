import React, { useState } from "react";
import { storeProducts } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";
import { Plus, Pencil, Trash2, X } from "lucide-react";

export default function StoreProducts() {
  const { toast } = useToast();
  const [items, setItems] = useState(storeProducts);
  const [editing, setEditing] = useState(null);

  const remove = (id) => {
    setItems((p) => p.filter((i) => i.id !== id));
    toast({ title: "Product removed" });
  };
  const save = (data) => {
    if (data.id) setItems((p) => p.map((i) => (i.id === data.id ? data : i)));
    else setItems((p) => [...p, { ...data, id: "p" + (Date.now() % 100000) }]);
    setEditing(null);
    toast({ title: "Product saved" });
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Products</h1>
          <p className="text-sm text-[hsl(var(--text-tertiary))]">{items.length} products</p>
        </div>
        <button onClick={() => setEditing({ id: null, name: "", price: "", mrp: "", stock: "", available: true, category: "food" })}
          className="press h-10 px-4 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold inline-flex items-center gap-1.5">
          <Plus className="w-4 h-4" /> Add product
        </button>
      </div>

      <div className="space-y-2">
        {items.map((p) => (
          <div key={p.id} className="card-soft rounded-2xl p-3 flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[hsl(var(--muted))] grid place-items-center font-semibold text-[hsl(var(--text-tertiary))]">{p.name.charAt(0)}</div>
            <div className="flex-1">
              <p className="text-sm font-medium">{p.name}</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">{formatPrice(p.price)} · stock {p.stock} · {p.available ? "Available" : "Hidden"}</p>
            </div>
            <button onClick={() => setEditing(p)} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))]"><Pencil className="w-4 h-4" /></button>
            <button onClick={() => remove(p.id)} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))] text-[hsl(var(--danger))]"><Trash2 className="w-4 h-4" /></button>
          </div>
        ))}
      </div>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setEditing(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm card-soft rounded-3xl p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">{editing.id ? "Edit product" : "New product"}</h3>
              <button onClick={() => setEditing(null)} className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-3">
              <Input label="Name" value={editing.name} onChange={(v) => setEditing({ ...editing, name: v })} />
              <div className="grid grid-cols-3 gap-2">
                <Input label="Price ₹" type="number" value={editing.price} onChange={(v) => setEditing({ ...editing, price: Number(v) })} />
                <Input label="MRP ₹" type="number" value={editing.mrp} onChange={(v) => setEditing({ ...editing, mrp: Number(v) })} />
                <Input label="Stock" type="number" value={editing.stock} onChange={(v) => setEditing({ ...editing, stock: Number(v) })} />
              </div>
              <button onClick={() => save(editing)} className="press w-full h-11 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold">Save product</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Input({ label, value, onChange, type = "text" }) {
  return (
    <div>
      <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full h-11 px-3 rounded-xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--warning))]" />
    </div>
  );
}