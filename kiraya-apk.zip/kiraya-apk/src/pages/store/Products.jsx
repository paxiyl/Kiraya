import React, { useState, useEffect, useRef } from "react";
import { Plus, Pencil, Trash2, X, Image, ToggleLeft, ToggleRight, Loader2 } from "lucide-react";
import { getProductsByStore, createProduct, updateProduct, deleteProduct, getMyStore, uploadImage } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { categories } from "@/data/mockData";

const BLANK = { name:"", price:"", mrp:"", stock:"", category:"food", available:true, description:"", image_url:"" };

export default function StoreProducts() {
  const { user }  = useAuth();
  const { toast } = useToast();
  const [store, setStore]       = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [editing, setEditing]   = useState(null);
  const [saving, setSaving]     = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  useEffect(() => {
    if (!user) return;
    getMyStore(user.id).then(async s => {
      setStore(s);
      if (!s) { setLoading(false); return; }
      setProducts(await getProductsByStore(s.id));
      setLoading(false);
    });
  }, [user]);

  const reload = async () => store && setProducts(await getProductsByStore(store.id));

  const handleImage = async (file) => {
    setUploading(true);
    try {
      const url = await uploadImage(file, "kiraya/products");
      setEditing(e => ({ ...e, image_url: url }));
      toast({ title: "Image uploaded ✓" });
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const save = async () => {
    if (!editing.name || !editing.price) return;
    setSaving(true);
    try {
      const data = {
        ...editing,
        price:              Number(editing.price),
        mrp:                Number(editing.mrp) || Number(editing.price),
        stock:              Number(editing.stock) || 0,
        store_id:           store.id,
        store_name:         store.name,
        store_delivery_fee: store.delivery_fee || 29,
      };
      if (editing.id) await updateProduct(editing.id, data);
      else            await createProduct(data);
      toast({ title: editing.id ? "Product updated" : "Product added" });
      setEditing(null);
      await reload();
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const remove = async (id) => {
    if (!confirm("Delete this product?")) return;
    try { await deleteProduct(id); toast({ title: "Deleted" }); await reload(); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const toggle = async (p) => {
    try { await updateProduct(p.id, { available: !p.available }); await reload(); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  if (!store) return (
    <div className="py-20 text-center space-y-2">
      <p className="text-sm text-[hsl(var(--text-tertiary))]">Set up your store first in Settings.</p>
    </div>
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Products</h1>
          <p className="text-sm text-[hsl(var(--text-tertiary))]">{products.length} item{products.length !== 1 ? "s" : ""}</p>
        </div>
        <button onClick={() => setEditing(BLANK)}
          className="press h-10 px-4 rounded-2xl bg-[hsl(var(--accent))] text-white text-sm font-semibold inline-flex items-center gap-1.5">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>

      {products.length === 0 ? (
        <div className="py-20 text-center space-y-3">
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No products yet.</p>
          <button onClick={() => setEditing(BLANK)} className="text-[hsl(var(--accent))] text-sm font-medium">Add your first product</button>
        </div>
      ) : (
        <div className="space-y-2">
          {products.map(p => (
            <div key={p.id} className="card-soft rounded-2xl p-3 flex items-center gap-3">
              {p.image_url
                ? <img src={p.image_url} alt={p.name} className="w-14 h-14 rounded-xl object-cover shrink-0" />
                : <div className="w-14 h-14 rounded-xl bg-[hsl(var(--muted))] grid place-items-center text-xl font-bold text-[hsl(var(--text-tertiary))] shrink-0">{p.name?.charAt(0)}</div>
              }
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold truncate">{p.name}</p>
                <p className="text-xs text-[hsl(var(--text-tertiary))]">{formatPrice(p.price)} · stock {p.stock}</p>
                <p className="text-xs mt-0.5">{p.available ? <span className="text-green-600">● Available</span> : <span className="text-red-500">● Hidden</span>}</p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => toggle(p)} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))]">
                  {p.available ? <ToggleRight className="w-4 h-4 text-green-600" /> : <ToggleLeft className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />}
                </button>
                <button onClick={() => setEditing(p)} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))]"><Pencil className="w-4 h-4" /></button>
                <button onClick={() => remove(p.id)} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))] text-red-500"><Trash2 className="w-4 h-4" /></button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setEditing(null)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div onClick={e => e.stopPropagation()} className="relative w-full bg-background rounded-t-3xl p-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">{editing.id ? "Edit product" : "Add product"}</h3>
              <button onClick={() => setEditing(null)} className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>

            <input type="file" ref={fileRef} accept="image/*" className="hidden" onChange={e => e.target.files[0] && handleImage(e.target.files[0])} />
            <button onClick={() => fileRef.current.click()} disabled={uploading}
              className="press w-full h-28 rounded-2xl border-2 border-dashed border-[hsl(var(--border))] flex flex-col items-center justify-center gap-2 text-[hsl(var(--text-tertiary))] mb-4 overflow-hidden">
              {editing.image_url
                ? <img src={editing.image_url} alt="" className="w-full h-full object-cover" />
                : uploading
                  ? <><Loader2 className="w-5 h-5 animate-spin" /><span className="text-xs">Uploading…</span></>
                  : <><Image className="w-6 h-6" /><span className="text-xs">Tap to add photo</span></>
              }
            </button>

            <div className="space-y-3">
              {[
                ["name",        "Product name *",          "text",   ""],
                ["description", "Description (optional)",  "text",   ""],
                ["price",       "Selling price (₹) *",     "number", ""],
                ["mrp",         "MRP / original price (₹)","number", ""],
                ["stock",       "Stock quantity",          "number", ""],
              ].map(([field, label, type]) => (
                <div key={field}>
                  <label className="text-xs text-[hsl(var(--text-tertiary))]">{label}</label>
                  <input type={type} value={editing[field] ?? ""} onChange={e => setEditing(x => ({ ...x, [field]: e.target.value }))}
                    className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
                </div>
              ))}
              <div>
                <label className="text-xs text-[hsl(var(--text-tertiary))]">Category</label>
                <select value={editing.category} onChange={e => setEditing(x => ({ ...x, category: e.target.value }))}
                  className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm">
                  {categories.filter(c => c.id !== "more").map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" className="w-4 h-4" checked={editing.available ?? true}
                  onChange={e => setEditing(x => ({ ...x, available: e.target.checked }))} />
                <span className="text-sm">Available for customers to order</span>
              </label>
            </div>

            <div className="flex gap-3 mt-5">
              <button onClick={() => setEditing(null)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm">Cancel</button>
              <button onClick={save} disabled={saving || !editing.name || !editing.price}
                className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-50">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
