import React, { useState, useEffect } from "react";
import { ClipboardList } from "lucide-react";
import { getMyStore, listenStoreOrders, updateOrderStatus } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import StatusBadge from "@/components/customer/StatusBadge";

const TABS = ["All","Pending","Preparing","Ready","Delivered","Cancelled"];
const STATUS_NEXT  = { PENDING: "PREPARING", PREPARING: "READY" };
const STATUS_LABEL = { PENDING: "Accept", PREPARING: "Mark Ready" };

export default function StoreOrders() {
  const { user }  = useAuth();
  const { toast } = useToast();
  const [store, setStore]   = useState(null);
  const [orders, setOrders] = useState([]);
  const [tab, setTab]       = useState("All");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    getMyStore(user.id).then(s => {
      setStore(s);
      if (!s) { setLoading(false); return; }
      const unsub = listenStoreOrders(s.id, o => { setOrders(o); setLoading(false); });
      return unsub;
    });
  }, [user]);

  const advance = async (order) => {
    const next = STATUS_NEXT[order.status];
    if (!next) return;
    try { await updateOrderStatus(order.id, next); toast({ title: `Order → ${next}` }); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const cancel = async (order) => {
    if (!confirm("Cancel this order?")) return;
    try { await updateOrderStatus(order.id, "CANCELLED"); toast({ title: "Order cancelled" }); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const filtered = tab === "All" ? orders : orders.filter(o => o.status === tab.toUpperCase().replace(" ", "_"));

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Orders</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{orders.length} total</p>
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`press shrink-0 px-3 h-8 rounded-full text-xs font-medium transition-colors
              ${tab === t ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {t}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="py-20 text-center space-y-2">
          <ClipboardList className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No {tab.toLowerCase()} orders</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(order => (
            <div key={order.id} className="card-soft rounded-2xl p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] font-mono">#{order.id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm font-semibold">{order.customer_name || "Customer"}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{order.address?.line}, {order.address?.city}</p>
                </div>
                <div className="text-right space-y-1">
                  <p className="font-bold text-sm">{formatPrice(order.total)}</p>
                  <StatusBadge status={order.status} />
                </div>
              </div>
              <p className="text-xs text-[hsl(var(--text-tertiary))] border-t border-[hsl(var(--border))] pt-2">
                {order.items?.map(i => `${i.name} ×${i.qty}`).join(" · ")}
              </p>
              {STATUS_NEXT[order.status] && (
                <div className="flex gap-2">
                  <button onClick={() => cancel(order)}
                    className="press flex-1 h-10 rounded-xl border border-red-200 text-red-500 text-sm font-medium">Cancel</button>
                  <button onClick={() => advance(order)}
                    className="press flex-1 h-10 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold">
                    {STATUS_LABEL[order.status]}
                  </button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
