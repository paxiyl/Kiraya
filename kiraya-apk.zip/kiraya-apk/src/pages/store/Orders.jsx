import React, { useState } from "react";
import { storeOrders } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

const TABS = [
  { id: "NEW", label: "New" },
  { id: "PREPARING", label: "Preparing" },
  { id: "READY", label: "Ready" },
  { id: "COMPLETED", label: "Completed" },
  { id: "CANCELLED", label: "Cancelled" },
];

export default function StoreOrders() {
  const { toast } = useToast();
  const [orders, setOrders] = useState(storeOrders);
  const [tab, setTab] = useState("NEW");
  const list = orders.filter((o) => o.status === tab);

  const advance = (id) => {
    const flow = { NEW: "PREPARING", PREPARING: "READY", READY: "COMPLETED" };
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status: flow[o.status] || o.status } : o)));
    toast({ title: "Order updated", description: `${id} → ${flow[orders.find((o) => o.id === id).status]}` });
  };
  const cancel = (id) => {
    setOrders((prev) => prev.map((o) => (o.id === id ? { ...o, status: "CANCELLED" } : o)));
    toast({ title: "Order cancelled", description: id, variant: "destructive" });
  };

  const nextAction = { NEW: "Accept & start preparing", PREPARING: "Mark as ready", READY: "Mark picked up" };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Orders</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Accept, prepare & complete</p>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {TABS.map((t) => {
          const count = orders.filter((o) => o.status === t.id).length;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`press shrink-0 px-3.5 h-9 rounded-full text-sm font-medium inline-flex items-center gap-1.5 ${tab === t.id ? "bg-[hsl(var(--warning))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
              {t.label} <span className="text-xs opacity-70">{count}</span>
            </button>
          );
        })}
      </div>

      {list.length === 0 ? (
        <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-12">No {tab.toLowerCase()} orders.</p>
      ) : (
        <div className="space-y-3">
          {list.map((o) => (
            <motion.div key={o.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card-soft rounded-2xl p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-semibold">{o.id} · {o.customer}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{o.items} items · {o.payment} · {o.time}</p>
                </div>
                <p className="text-sm font-bold">{formatPrice(o.amount)}</p>
              </div>
              {nextAction[o.status] ? (
                <div className="flex gap-2 mt-3">
                  <button onClick={() => advance(o.id)} className="press flex-1 h-11 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold">{nextAction[o.status]}</button>
                  {o.status === "NEW" && <button onClick={() => cancel(o.id)} className="press h-11 px-4 rounded-2xl card-soft text-sm font-medium text-[hsl(var(--danger))]">Decline</button>}
                </div>
              ) : (
                <p className="text-xs text-[hsl(var(--text-tertiary))] mt-3">No action needed.</p>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}