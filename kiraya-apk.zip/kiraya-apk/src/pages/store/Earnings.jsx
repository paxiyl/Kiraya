import React from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart } from "@/components/admin/Charts";
import { weeklyRevenue, payoutHistory } from "@/data/panelData";
import { Wallet, TrendingUp, Star, Calendar } from "lucide-react";
import { formatPrice } from "@/lib/appConfig";
import { Pill } from "@/components/customer/StatusBadge";

export default function StoreEarnings() {
  const weekRev = weeklyRevenue.reduce((s, d) => s + d.revenue, 0);
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Earnings</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Revenue & payouts</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="This Week" value={weekRev} prefix="₹" icon={Wallet} delta="+12%" up tone="accent" />
        <StatCard label="Net (after 12%)" value={Math.round(weekRev * 0.88)} prefix="₹" icon={TrendingUp} tone="success" />
        <StatCard label="Avg Order Value" value={412} prefix="₹" icon={Star} tone="warning" />
        <StatCard label="Orders" value={weeklyRevenue.reduce((s, d) => s + d.orders, 0)} icon={Calendar} tone="neutral" />
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Weekly revenue</h3>
        <RevenueChart data={weeklyRevenue} />
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Payout history</h3>
        <div className="space-y-2">
          {payoutHistory.map((p) => (
            <div key={p.id} className="flex items-center justify-between text-sm">
              <div><p className="font-medium">{p.week}</p><p className="text-xs text-[hsl(var(--text-tertiary))]">Payout</p></div>
              <div className="flex items-center gap-3">
                <span className="font-bold">{formatPrice(p.amount)}</span>
                <Pill tone={p.status === "Paid" ? "success" : "warning"}>{p.status}</Pill>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}