import React, { useState } from "react";
import { useToast } from "@/components/ui/use-toast";

export default function StoreSettings() {
  const { toast } = useToast();
  const [name, setName] = useState("Spice Route Kitchen");
  const [open, setOpen] = useState(true);
  const [radius, setRadius] = useState(5);
  const [fee, setFee] = useState(29);

  return (
    <div className="space-y-5 max-w-xl">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Store profile & operations</p>
      </div>
      <div className="card-soft rounded-2xl p-4 space-y-3">
        <Field label="Store name" value={name} onChange={setName} />
        <Field label="Delivery radius (km)" type="number" value={radius} onChange={(v) => setRadius(Number(v))} />
        <Field label="Delivery fee (₹)" type="number" value={fee} onChange={(v) => setFee(Number(v))} />
        <div className="flex items-center justify-between pt-1">
          <div><p className="text-sm font-medium">Store open</p><p className="text-xs text-[hsl(var(--text-tertiary))]">Accept new orders</p></div>
          <button onClick={() => setOpen(!open)} className={`press w-11 h-6 rounded-full transition-colors ${open ? "bg-[hsl(var(--success))]" : "bg-[hsl(var(--border))]"}`}>
            <span className={`block w-5 h-5 rounded-full bg-white transition-transform ${open ? "translate-x-5" : "translate-x-0.5"} mt-0.5`} />
          </button>
        </div>
      </div>
      <button onClick={() => toast({ title: "Settings saved" })} className="press h-11 px-5 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold">Save changes</button>
    </div>
  );
}

function Field({ label, value, onChange, type = "text" }) {
  return (
    <div>
      <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full h-11 px-4 rounded-2xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--warning))]" />
    </div>
  );
}