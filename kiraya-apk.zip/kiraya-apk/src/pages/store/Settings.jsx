import React, { useState, useEffect, useRef } from "react";
import { Camera, Store, Loader2 } from "lucide-react";
import { getMyStore, createStore, updateStore, uploadImage } from "@/lib/db";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { categories } from "@/data/mockData";

const BLANK = { name:"", description:"", category:"food", address:"", phone:"", image_url:"", eta:"30-45 min", delivery_fee:"", open:false };

export default function StoreSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [store, setStore]   = useState(null);
  const [form, setForm]     = useState(BLANK);
  const [loading, setLoading]   = useState(true);
  const [saving, setSaving]     = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  useEffect(() => {
    if (!user) return;
    getMyStore(user.id).then(s => {
      setStore(s);
      if (s) setForm({ name: s.name||"", description: s.description||"", category: s.category||"food", address: s.address||"", phone: s.phone||"", image_url: s.image_url||"", eta: s.eta||"30-45 min", delivery_fee: s.delivery_fee||"", open: s.open??false });
      setLoading(false);
    });
  }, [user]);

  const handleImage = async (file) => {
    setUploading(true);
    try {
      const url = await uploadImage(file, "kiraya/stores");
      setForm(f => ({ ...f, image_url: url }));
      toast({ title: "Photo updated ✓" });
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const save = async () => {
    if (!form.name) { toast({ title: "Store name is required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      const data = { ...form, delivery_fee: Number(form.delivery_fee) || 0, owner_id: user.id };
      if (store) {
        await updateStore(store.id, data);
        toast({ title: "Store updated ✓" });
      } else {
        await createStore({ ...data, approved: false });
        const s = await getMyStore(user.id);
        setStore(s);
        toast({ title: "Store created! Awaiting admin approval." });
      }
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">{store ? "Store Settings" : "Create your store"}</h1>
        {store && !store.approved && <p className="text-xs text-orange-500 mt-1">⏳ Pending admin approval</p>}
        {!store && <p className="text-sm text-[hsl(var(--text-secondary))] mt-1">Fill in your store details to get started.</p>}
      </div>

      <input type="file" ref={fileRef} accept="image/*" className="hidden" onChange={e => e.target.files[0] && handleImage(e.target.files[0])} />
      <div className="relative w-full h-40 rounded-2xl bg-[hsl(var(--muted))] overflow-hidden">
        {form.image_url && <img src={form.image_url} alt="" className="w-full h-full object-cover" />}
        {!form.image_url && <div className="w-full h-full flex items-center justify-center"><Store className="w-10 h-10 text-[hsl(var(--text-tertiary))]" /></div>}
        <button onClick={() => fileRef.current.click()} disabled={uploading}
          className="press absolute bottom-2 right-2 h-9 px-3 rounded-xl bg-black/60 text-white text-xs font-medium flex items-center gap-1.5">
          {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />}
          {uploading ? "Uploading…" : "Add photo"}
        </button>
      </div>

      <div className="space-y-3">
        {[
          ["name",         "Store name *",                    "text",   "My Store"],
          ["description",  "Description",                     "text",   "What you sell"],
          ["address",      "Full address",                    "text",   "Street, Area, City"],
          ["phone",        "Contact number",                  "tel",    "+91 9XXXXXXXXX"],
          ["eta",          "Avg delivery time",               "text",   "30-45 min"],
          ["delivery_fee", "Delivery fee (₹, 0 = free)",      "number", "29"],
        ].map(([field, label, type, placeholder]) => (
          <div key={field}>
            <label className="text-xs text-[hsl(var(--text-tertiary))]">{label}</label>
            <input type={type} placeholder={placeholder} value={form[field] ?? ""}
              onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))}
              className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
          </div>
        ))}

        <div>
          <label className="text-xs text-[hsl(var(--text-tertiary))]">Category</label>
          <select value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}
            className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm">
            {categories.filter(c => c.id !== "more").map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        {store && (
          <label className="flex items-center gap-3 cursor-pointer card-soft rounded-xl p-3">
            <input type="checkbox" className="w-4 h-4" checked={form.open}
              onChange={e => setForm(f => ({ ...f, open: e.target.checked }))} />
            <div>
              <p className="text-sm font-medium">Store is open</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">Customers can order when open</p>
            </div>
            <span className={`ml-auto text-xs font-bold ${form.open ? "text-green-600" : "text-red-500"}`}>
              {form.open ? "OPEN" : "CLOSED"}
            </span>
          </label>
        )}
      </div>

      <button onClick={save} disabled={saving}
        className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
        {saving ? <><Loader2 className="w-4 h-4 animate-spin" />Saving…</> : store ? "Save changes" : "Create store"}
      </button>
    </div>
  );
}
