import React, { useState, useEffect, useRef } from "react";
import { Camera, Store, Loader2 } from "lucide-react";
import { getStoreByOwner, updateStore } from "@/lib/firestore";
import { uploadImage, isCloudinaryReady } from "@/lib/cloudinary";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { categories } from "@/data/mockData";

export default function StoreSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [store, setStore] = useState(null);
  const [form, setForm] = useState({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef();

  useEffect(() => {
    if (!user) return;
    getStoreByOwner(user.uid).then(s => {
      setStore(s);
      if (s) setForm({
        name: s.name || "", category: s.category || "food",
        address: s.address || "", eta: s.eta || "",
        deliveryFee: s.deliveryFee || "", phone: s.phone || "",
        description: s.description || "", imageUrl: s.imageUrl || "",
        open: s.open ?? false,
      });
      setLoading(false);
    });
  }, [user]);

  const handleImagePick = async (file) => {
    if (!isCloudinaryReady()) {
      toast({ title: "Cloudinary not configured", description: "Add your Cloud name and upload preset in src/lib/cloudinary.js", variant: "destructive" });
      return;
    }
    setUploading(true);
    try {
      const url = await uploadImage(file, "kiraya/stores");
      setForm(f => ({ ...f, imageUrl: url }));
      toast({ title: "Photo updated ✓" });
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const save = async () => {
    setSaving(true);
    try {
      await updateStore(store.id, { ...form, deliveryFee: Number(form.deliveryFee) || 0 });
      toast({ title: "Store updated ✓" });
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  if (!store) return (
    <div className="py-20 text-center space-y-2">
      <Store className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
      <p className="text-sm text-[hsl(var(--text-tertiary))]">No store linked to your account.<br />Contact admin.</p>
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Store Settings</h1>
        {!store.approved && <p className="text-xs text-orange-500 mt-1">⏳ Pending admin approval</p>}
      </div>

      {/* Cover image */}
      <input type="file" ref={fileRef} accept="image/*" className="hidden" onChange={e => e.target.files[0] && handleImagePick(e.target.files[0])} />
      <div className="relative w-full h-40 rounded-2xl bg-[hsl(var(--muted))] overflow-hidden">
        {form.imageUrl && <img src={form.imageUrl} alt="" className="w-full h-full object-cover" />}
        <button onClick={() => fileRef.current.click()} disabled={uploading}
          className="press absolute bottom-2 right-2 h-9 px-3 rounded-xl bg-black/60 text-white text-xs font-medium flex items-center gap-1.5">
          {uploading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Camera className="w-3.5 h-3.5" />}
          {uploading ? "Uploading…" : "Change photo"}
        </button>
      </div>

      <div className="space-y-3">
        {[["name","Store name","text"],["description","Description","text"],["address","Full address","text"],["phone","Contact number","tel"],["eta","Delivery time (e.g. 25–35 min)","text"],["deliveryFee","Delivery fee (₹)","number"]].map(([field, label, type]) => (
          <div key={field}>
            <label className="text-xs text-[hsl(var(--text-tertiary))]">{label}</label>
            <input type={type} className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
              value={form[field] || ""} onChange={e => setForm(f => ({ ...f, [field]: e.target.value }))} />
          </div>
        ))}

        <div>
          <label className="text-xs text-[hsl(var(--text-tertiary))]">Category</label>
          <select className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm"
            value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
            {categories.filter(c => c.id !== "more").map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
          </select>
        </div>

        <label className="flex items-center gap-3 cursor-pointer card-soft rounded-xl p-3">
          <input type="checkbox" className="w-4 h-4" checked={form.open}
            onChange={e => setForm(f => ({ ...f, open: e.target.checked }))} />
          <div>
            <p className="text-sm font-medium">Store is open</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))]">Customers can place orders when open</p>
          </div>
          <span className={`ml-auto text-xs font-bold ${form.open ? "text-green-600" : "text-red-500"}`}>{form.open ? "OPEN" : "CLOSED"}</span>
        </label>
      </div>

      <button onClick={save} disabled={saving}
        className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-50 flex items-center justify-center gap-2">
        {saving ? <><Loader2 className="w-4 h-4 animate-spin" />Saving…</> : "Save changes"}
      </button>
    </div>
  );
}
