import React from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart } from "@/components/admin/Charts";
import { storeStats, storeOrders, storeInventory, weeklyRevenue } from "@/data/panelData";
import { Wallet, ClipboardList, CheckCircle2, Clock } from "lucide-react";
import StatusBadge from "@/components/customer/StatusBadge";
import { formatPrice } from "@/lib/appConfig";

const ICONS = { sales: Wallet, pending: ClipboardList, completed: CheckCircle2, prepTime: Clock };
const STOCK_TONE = { ok: "success", low: "warning", out: "danger" };
const STOCK_LABEL = { ok: "In stock", low: "Low stock", out: "Out of stock" };

export default function StoreDashboard() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Store Dashboard</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Spice Route Kitchen · today</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {storeStats.map(({ key, ...rest }) => <StatCard key={key} {...rest} icon={ICONS[key]} tone={key === "pending" ? "warning" : "accent"} />)}
      </div>

      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Sales (last 7 days)</h3>
        <RevenueChart data={weeklyRevenue} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Order queue</h3>
          <div className="space-y-2">
            {storeOrders.slice(0, 4).map((o) => (
              <div key={o.id} className="flex items-center justify-between text-sm">
                <div>
                  <p className="font-medium">{o.id}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{o.customer} · {o.items} items</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{formatPrice(o.amount)}</p>
                  <StatusBadge status={o.status === "NEW" ? "PENDING" : o.status === "COMPLETED" ? "DELIVERED" : o.status === "CANCELLED" ? "CANCELLED" : "PREPARING"} />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Low stock alerts</h3>
          <div className="space-y-2">
            {storeInventory.filter((i) => i.status !== "ok").map((i) => (
              <div key={i.id} className="flex items-center justify-between text-sm">
                <span className="font-medium">{i.name}</span>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full bg-[hsl(var(--${STOCK_TONE[i.status]}-soft))] text-[hsl(var(--${STOCK_TONE[i.status]}))]`}>
                  {STOCK_LABEL[i.status]} · {i.stock} left
                </span>
              </div>
            ))}
            {storeInventory.filter((i) => i.status !== "ok").length === 0 && <p className="text-sm text-[hsl(var(--text-tertiary))]">All items well stocked.</p>}
          </div>
        </div>
      </div>
    </div>
  );
}