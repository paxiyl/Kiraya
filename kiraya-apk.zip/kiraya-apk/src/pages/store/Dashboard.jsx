import React, { useState, useEffect } from "react";
import { Wallet, ClipboardList, CheckCircle2, Clock, Package } from "lucide-react";
import { listenStoreOrders, getStoreByOwner, updateOrderStatus } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import StatusBadge from "@/components/customer/StatusBadge";
import { useToast } from "@/components/ui/use-toast";

const STATUS_NEXT = { PENDING: "PREPARING", PREPARING: "READY", READY: null };
const STATUS_LABEL = { PENDING: "Accept", PREPARING: "Mark Ready", READY: "Dispatched" };

export default function StoreDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [store, setStore] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    getStoreByOwner(user.uid).then(s => {
      setStore(s);
      if (!s) { setLoading(false); return; }
      const unsub = listenStoreOrders(s.id, o => { setOrders(o); setLoading(false); });
      return unsub;
    });
  }, [user]);

  const advance = async (order) => {
    const next = STATUS_NEXT[order.status];
    if (!next) return;
    try {
      await updateOrderStatus(order.id, next);
      toast({ title: `Order ${order.id.slice(-6).toUpperCase()} → ${next}` });
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const pending = orders.filter(o => o.status === "PENDING");
  const active  = orders.filter(o => ["PREPARING","READY"].includes(o.status));
  const done    = orders.filter(o => ["DELIVERED","CANCELLED"].includes(o.status));

  const todayRevenue = done.filter(o => o.status === "DELIVERED")
    .reduce((s, o) => s + (o.total || 0), 0);

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  if (!store) return (
    <div className="py-20 text-center space-y-3">
      <Package className="w-12 h-12 text-[hsl(var(--text-tertiary))] mx-auto" />
      <p className="text-sm font-medium">No store linked to your account</p>
      <p className="text-xs text-[hsl(var(--text-tertiary))]">Contact admin to set up your store.</p>
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{store.name}</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Today's revenue", value: formatPrice(todayRevenue), icon: Wallet },
          { label: "Pending orders", value: pending.length, icon: ClipboardList },
          { label: "In progress", value: active.length, icon: Clock },
          { label: "Completed today", value: done.filter(o => o.status === "DELIVERED").length, icon: CheckCircle2 },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      {/* Incoming orders */}
      {pending.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold mb-2 text-orange-500">⚡ New orders ({pending.length})</h2>
          <div className="space-y-2">
            {pending.map(o => <OrderCard key={o.id} order={o} onAdvance={advance} />)}
          </div>
        </div>
      )}

      {/* Active orders */}
      {active.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold mb-2">In progress</h2>
          <div className="space-y-2">
            {active.map(o => <OrderCard key={o.id} order={o} onAdvance={advance} />)}
          </div>
        </div>
      )}

      {/* Recent completed */}
      {done.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold mb-2">Completed today</h2>
          <div className="space-y-2">
            {done.slice(0, 5).map(o => <OrderCard key={o.id} order={o} onAdvance={advance} />)}
          </div>
        </div>
      )}

      {orders.length === 0 && (
        <div className="py-16 text-center space-y-2">
          <ClipboardList className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No orders yet today</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">New orders will appear here in real time</p>
        </div>
      )}
    </div>
  );
}

function OrderCard({ order, onAdvance }) {
  const next = STATUS_NEXT[order.status];
  return (
    <div className="card-soft rounded-2xl p-4 space-y-2">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">#{order.id.slice(-6).toUpperCase()}</p>
          <p className="text-sm font-semibold">{order.customerName || "Customer"}</p>
        </div>
        <div className="text-right">
          <p className="font-bold text-sm">{formatPrice(order.total)}</p>
          <StatusBadge status={order.status} />
        </div>
      </div>
      <div className="text-xs text-[hsl(var(--text-tertiary))]">
        {order.items?.map(i => `${i.name} ×${i.qty}`).join(", ")}
      </div>
      <div className="text-xs text-[hsl(var(--text-tertiary))]">📍 {order.address?.line}, {order.address?.city}</div>
      {next && (
        <button onClick={() => onAdvance(order)}
          className="press w-full h-10 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold">
          {STATUS_LABEL[order.status]}
        </button>
      )}
    </div>
  );
}
