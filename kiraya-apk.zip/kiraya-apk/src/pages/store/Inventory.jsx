import React from "react";
import { storeInventory } from "@/data/panelData";
import { Boxes, AlertTriangle, PackageX } from "lucide-react";

const TONE = { ok: "success", low: "warning", out: "danger" };
const LABEL = { ok: "In stock", low: "Low stock", out: "Out of stock" };
const ICON = { ok: Boxes, low: AlertTriangle, out: PackageX };

export default function StoreInventory() {
  const low = storeInventory.filter((i) => i.status !== "ok");
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Inventory</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Stock levels & status</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {["ok", "low", "out"].map((st) => {
          const Icon = ICON[st];
          const count = storeInventory.filter((i) => i.status === st).length;
          return (
            <div key={st} className="card-soft rounded-2xl p-3 text-center">
              <div className={`w-9 h-9 rounded-xl grid place-items-center mx-auto bg-[hsl(var(--${TONE[st]}-soft))] text-[hsl(var(--${TONE[st]}))]`}>
                <Icon className="w-4.5 h-4.5" />
              </div>
              <p className="text-xl font-bold mt-2">{count}</p>
              <p className="text-[11px] text-[hsl(var(--text-tertiary))]">{LABEL[st]}</p>
            </div>
          );
        })}
      </div>

      {low.length > 0 && (
        <div className="rounded-2xl p-4 bg-[hsl(var(--warning-soft))] text-[hsl(var(--warning))] flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          <p className="text-sm font-medium">{low.length} items need restocking soon.</p>
        </div>
      )}

      <div className="card-soft rounded-2xl divide-y divide-[hsl(var(--border))]">
        {storeInventory.map((i) => {
          const Icon = ICON[i.status];
          return (
            <div key={i.id} className="flex items-center gap-3 p-4">
              <div className={`w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--${TONE[i.status]}-soft))] text-[hsl(var(--${TONE[i.status]}))]`}>
                <Icon className="w-4.5 h-4.5" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{i.name}</p>
                <p className="text-xs text-[hsl(var(--text-tertiary))]">{i.stock} units</p>
              </div>
              <span className={`text-xs font-medium px-2.5 py-1 rounded-full bg-[hsl(var(--${TONE[i.status]}-soft))] text-[hsl(var(--${TONE[i.status]}))]`}>{LABEL[i.status]}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}