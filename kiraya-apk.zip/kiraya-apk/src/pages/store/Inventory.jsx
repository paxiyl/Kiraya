import React, { useState, useEffect } from "react";
import { Boxes, AlertTriangle, PackageX, Pencil, Loader2 } from "lucide-react";
import { getMyStore, getProductsByStore, updateProduct } from "@/lib/db";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { formatPrice } from "@/lib/appConfig";

export default function StoreInventory() {
  const { user }  = useAuth();
  const { toast } = useToast();
  const [products, setProducts] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [editing, setEditing]   = useState(null); // { id, stock }
  const [saving, setSaving]     = useState(false);

  const reload = async (storeId) => {
    setProducts(await getProductsByStore(storeId));
  };

  useEffect(() => {
    if (!user) return;
    getMyStore(user.id).then(async s => {
      if (!s) { setLoading(false); return; }
      await reload(s.id);
      setLoading(false);
    });
  }, [user]);

  const saveStock = async () => {
    if (!editing) return;
    setSaving(true);
    try {
      await updateProduct(editing.id, { stock: Number(editing.stock) });
      toast({ title: "Stock updated ✓" });
      setEditing(null);
      const storeId = products[0]?.store_id;
      if (storeId) await reload(storeId);
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const outOfStock = products.filter(p => p.stock === 0);
  const lowStock   = products.filter(p => p.stock > 0 && p.stock <= 5);
  const inStock    = products.filter(p => p.stock > 5);

  if (loading) return (
    <div className="py-20 text-center">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Inventory</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{products.length} products total</p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-3 gap-2">
        {[
          { label: "In stock",    count: inStock.length,    color: "text-green-600", bg: "bg-green-50", icon: Boxes },
          { label: "Low stock",   count: lowStock.length,   color: "text-orange-500", bg: "bg-orange-50", icon: AlertTriangle },
          { label: "Out of stock",count: outOfStock.length, color: "text-red-500", bg: "bg-red-50", icon: PackageX },
        ].map(({ label, count, color, bg, icon: Icon }) => (
          <div key={label} className={`rounded-2xl p-3 ${bg}`}>
            <Icon className={`w-4 h-4 ${color} mb-1`} />
            <p className={`text-lg font-bold ${color}`}>{count}</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))] leading-tight">{label}</p>
          </div>
        ))}
      </div>

      {products.length === 0 ? (
        <div className="py-20 text-center space-y-2">
          <Boxes className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No products yet. Add them in Products.</p>
        </div>
      ) : (
        <div className="space-y-2">
          {[...outOfStock, ...lowStock, ...inStock].map(p => {
            const stockColor = p.stock === 0 ? "text-red-500" : p.stock <= 5 ? "text-orange-500" : "text-green-600";
            return (
              <div key={p.id} className="card-soft rounded-2xl p-3 flex items-center gap-3">
                {p.image_url
                  ? <img src={p.image_url} alt={p.name} className="w-12 h-12 rounded-xl object-cover shrink-0" />
                  : <div className="w-12 h-12 rounded-xl bg-[hsl(var(--muted))] grid place-items-center text-lg font-bold text-[hsl(var(--text-tertiary))] shrink-0">
                      {p.name?.charAt(0)}
                    </div>
                }
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold truncate">{p.name}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{formatPrice(p.price)}</p>
                  <p className={`text-xs font-semibold ${stockColor}`}>
                    {p.stock === 0 ? "Out of stock" : p.stock <= 5 ? `Low — ${p.stock} left` : `${p.stock} in stock`}
                  </p>
                </div>
                <button
                  onClick={() => setEditing({ id: p.id, stock: String(p.stock) })}
                  className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))] shrink-0">
                  <Pencil className="w-4 h-4" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {/* Edit stock modal */}
      {editing && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setEditing(null)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div onClick={e => e.stopPropagation()} className="relative w-full bg-background rounded-t-3xl p-5">
            <h3 className="text-base font-semibold mb-4">Update stock</h3>
            <div>
              <label className="text-xs text-[hsl(var(--text-tertiary))]">New stock quantity</label>
              <input
                type="number"
                min="0"
                className="w-full mt-1 h-12 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
                value={editing.stock}
                onChange={e => setEditing(x => ({ ...x, stock: e.target.value }))}
                autoFocus
              />
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setEditing(null)}
                className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm">
                Cancel
              </button>
              <button onClick={saveStock} disabled={saving}
                className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-50">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
