import React from "react";
import { Star } from "lucide-react";

const reviews = [
  { name: "Aarav S.", rating: 5, text: "Best biryani in the area, delivered hot!", date: "2 days ago" },
  { name: "Priya M.", rating: 4, text: "Food was great, delivery a bit late.", date: "5 days ago" },
  { name: "Rohit G.", rating: 5, text: "Paneer butter masala is a must-try.", date: "1 week ago" },
  { name: "Sneha J.", rating: 3, text: "Naan was slightly dry, but overall good.", date: "2 weeks ago" },
];

const breakdown = [
  { star: 5, pct: 68 }, { star: 4, pct: 20 }, { star: 3, pct: 8 }, { star: 2, pct: 3 }, { star: 1, pct: 1 },
];

export default function StoreReviews() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Reviews</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Customer feedback</p>
      </div>
      <div className="card-soft rounded-2xl p-4 flex items-center gap-4">
        <div className="text-center">
          <p className="text-4xl font-bold">4.6</p>
          <div className="flex justify-center mt-1">{[1,2,3,4,5].map((i) => <Star key={i} className="w-3.5 h-3.5 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" />)}</div>
          <p className="text-xs text-[hsl(var(--text-tertiary))] mt-1">128 reviews</p>
        </div>
        <div className="flex-1 space-y-1.5">
          {breakdown.map((b) => (
            <div key={b.star} className="flex items-center gap-2 text-xs">
              <span className="w-3 text-[hsl(var(--text-tertiary))]">{b.star}</span>
              <div className="flex-1 h-1.5 rounded-full bg-[hsl(var(--muted))] overflow-hidden">
                <div className="h-full rounded-full bg-[hsl(var(--warning))]" style={{ width: `${b.pct}%` }} />
              </div>
              <span className="w-8 text-right text-[hsl(var(--text-tertiary))]">{b.pct}%</span>
            </div>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        {reviews.map((r, i) => (
          <div key={i} className="card-soft rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">{r.name}</p>
              <div className="flex items-center gap-0.5">{[1,2,3,4,5].map((s) => <Star key={s} className={`w-3.5 h-3.5 ${s <= r.rating ? "fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" : "text-[hsl(var(--border))]"}`} />)}</div>
            </div>
            <p className="text-sm text-[hsl(var(--text-secondary))] mt-1.5">{r.text}</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))] mt-2">{r.date}</p>
          </div>
        ))}
      </div>
    </div>
  );
}