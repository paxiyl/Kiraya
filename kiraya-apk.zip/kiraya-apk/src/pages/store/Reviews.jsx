import React, { useState, useEffect } from "react";
import { Star, MessageSquare } from "lucide-react";
import { getMyStore } from "@/lib/db";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";

export default function StoreReviews() {
  const { user }  = useAuth();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [avg, setAvg]         = useState(0);
  useEffect(() => {
    if (!user) return;
    getMyStore(user.id).then(async s => {
      if (!s) { setLoading(false); return; }
      const { data } = await supabase
        .from("reviews")
        .select("*")
        .eq("store_id", s.id)
        .order("created_at", { ascending: false });
      const r = data || [];
      setReviews(r);
      if (r.length) setAvg(r.reduce((a, x) => a + x.rating, 0) / r.length);
      setLoading(false);
    });
  }, [user]);
  const stars = (n) => "★".repeat(Math.round(n)) + "☆".repeat(5 - Math.round(n));
  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;
  return (
    <div className="space-y-5">
      <h1 className="text-xl font-bold tracking-tight">Reviews</h1>
      {reviews.length > 0 && (
        <div className="card-soft rounded-2xl p-5 flex items-center gap-5">
          <div className="text-center">
            <p className="text-4xl font-bold">{avg.toFixed(1)}</p>
            <p className="text-yellow-400 text-lg tracking-widest">{stars(avg)}</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))] mt-1">{reviews.length} review{reviews.length !== 1 ? "s" : ""}</p>
          </div>
          <div className="flex-1 space-y-1.5">
            {[5,4,3,2,1].map(s => {
              const count = reviews.filter(r => r.rating === s).length;
              const pct   = reviews.length ? (count / reviews.length) * 100 : 0;
              return (
                <div key={s} className="flex items-center gap-2 text-xs">
                  <span className="w-3 text-[hsl(var(--text-tertiary))]">{s}</span>
                  <Star className="w-3 h-3 fill-yellow-400 text-yellow-400 shrink-0" />
                  <div className="flex-1 h-1.5 rounded-full bg-[hsl(var(--muted))] overflow-hidden">
                    <div className="h-full bg-yellow-400 rounded-full" style={{ width:`${pct}%` }} />
                  </div>
                  <span className="w-4 text-right text-[hsl(var(--text-tertiary))]">{count}</span>
                </div>
              );
            })}
        </div>
      )}
      {reviews.length === 0 ? (
        <div className="py-20 text-center space-y-2">
          <MessageSquare className="w-12 h-12 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No reviews yet</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">Reviews appear here after customers rate their orders</p>
      ) : (
        <div className="space-y-3">
          {reviews.map(r => (
            <div key={r.id} className="card-soft rounded-2xl p-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-[hsl(var(--accent-soft))] grid place-items-center text-[hsl(var(--accent))] font-bold text-xs">
                    {(r.customer_name || "?").charAt(0).toUpperCase()}
                  <p className="text-sm font-medium">{r.customer_name || "Customer"}</p>
                <div className="flex">
                  {[1,2,3,4,5].map(s => (
                    <Star key={s} className={`w-3.5 h-3.5 ${s <= r.rating ? "fill-yellow-400 text-yellow-400" : "text-[hsl(var(--muted))]"}`} />
                  ))}
              </div>
              {r.comment && <p className="text-sm text-[hsl(var(--text-secondary))]">{r.comment}</p>}
              <p className="text-xs text-[hsl(var(--text-tertiary))]">
                {new Date(r.created_at).toLocaleDateString("en-IN", { day:"numeric", month:"short", year:"numeric" })}
              </p>
            </div>
          ))}
    </div>
  );
}
