import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { CheckCircle2, MapPin, Package, Loader2 } from "lucide-react";
import { listenMyDelivery, completeDelivery, updateOrderStatus } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";

const STEPS = [
  { status: "PENDING",          label: "Order received" },
  { status: "PREPARING",        label: "Store preparing" },
  { status: "READY",            label: "Ready for pickup" },
  { status: "OUT_FOR_DELIVERY", label: "On the way" },
  { status: "DELIVERED",        label: "Delivered" },
];

export default function ActiveDelivery() {
  const { user }  = useAuth();
  const navigate  = useNavigate();
  const { toast } = useToast();
  const [order, setOrder]       = useState(null);
  const [loading, setLoading]   = useState(true);
  const [completing, setCompleting] = useState(false);

  useEffect(() => {
    if (!user) return;
    const unsub = listenMyDelivery(user.id, o => { setOrder(o); setLoading(false); });
    return unsub;
  }, [user]);

  const markPickedUp = async () => {
    try { await updateOrderStatus(order.id, "OUT_FOR_DELIVERY"); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const markDelivered = async () => {
    setCompleting(true);
    try {
      await completeDelivery(order.id);
      toast({ title: "Delivery complete! 🎉", description: "Great job!" });
      navigate("/delivery");
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setCompleting(false); }
  };

  if (loading) return (
    <div className="py-20 text-center">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" />
    </div>
  );

  if (!order) return (
    <div className="py-20 text-center space-y-3">
      <Package className="w-12 h-12 text-[hsl(var(--text-tertiary))] mx-auto" />
      <p className="text-sm text-[hsl(var(--text-tertiary))]">No active delivery</p>
      <button onClick={() => navigate("/delivery")} className="press text-[hsl(var(--accent))] text-sm font-medium">
        Go back
      </button>
    </div>
  );

  const stepIdx = STEPS.findIndex(s => s.status === order.status);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-semibold">Active Delivery</h1>
        <span className="text-xs font-mono text-[hsl(var(--text-tertiary))]">
          #{order.id.slice(-6).toUpperCase()}
        </span>
      </div>

      {/* Progress */}
      <div className="card-soft rounded-2xl p-4 space-y-3">
        {STEPS.map((step, i) => {
          const done   = i < stepIdx;
          const active = i === stepIdx;
          return (
            <div key={step.status} className={`flex items-center gap-3 text-sm
              ${active ? "text-[hsl(var(--text-primary))]" : done ? "text-[hsl(var(--text-secondary))]" : "text-[hsl(var(--text-tertiary))]"}`}>
              <div className={`w-6 h-6 rounded-full grid place-items-center shrink-0 transition-colors
                ${done ? "bg-green-500" : active ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--muted))]"}`}>
                {done
                  ? <CheckCircle2 className="w-4 h-4 text-white" />
                  : <span className="text-[10px] text-white font-bold">{i + 1}</span>
                }
              </div>
              <span className={active ? "font-semibold" : ""}>{step.label}</span>
            </div>
          );
        })}
      </div>

      {/* Order items */}
      <div className="card-soft rounded-2xl p-4 space-y-2">
        <h3 className="text-sm font-semibold">Order items</h3>
        {(order.items || []).map((item, i) => (
          <div key={i} className="flex justify-between text-sm">
            <span className="text-[hsl(var(--text-secondary))]">{item.name} × {item.qty}</span>
            <span>{formatPrice(item.price * item.qty)}</span>
          </div>
        ))}
        <div className="border-t border-[hsl(var(--border))] pt-2 flex justify-between font-semibold text-sm">
          <span>Total</span><span>{formatPrice(order.total)}</span>
        </div>
      </div>

      {/* Drop address */}
      <div className="card-soft rounded-2xl p-4 space-y-1.5">
        <div className="flex items-center gap-2 mb-1">
          <MapPin className="w-4 h-4 text-[hsl(var(--accent))]" />
          <h3 className="text-sm font-semibold">Drop address</h3>
        </div>
        <p className="text-sm text-[hsl(var(--text-secondary))]">{order.address?.line}</p>
        <p className="text-sm text-[hsl(var(--text-secondary))]">{order.address?.city} — {order.address?.pin}</p>
        <p className="text-sm font-medium">{order.address?.phone}</p>
      </div>

      {/* Action buttons */}
      <div className="space-y-2 pb-4">
        {order.status === "READY" && (
          <button onClick={markPickedUp}
            className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold">
            I've picked up the order
          </button>
        )}
        {order.status === "OUT_FOR_DELIVERY" && (
          <button onClick={markDelivered} disabled={completing}
            className="press w-full h-12 rounded-2xl bg-green-500 text-white font-semibold disabled:opacity-60 flex items-center justify-center gap-2">
            {completing ? <><Loader2 className="w-4 h-4 animate-spin" />Marking…</> : "Mark as delivered ✓"}
          </button>
        )}
        <p className="text-center text-xs text-[hsl(var(--text-tertiary))]">
          Payment: {order.payment_method?.toUpperCase()} · {formatPrice(order.total)}
        </p>
      </div>
    </div>
  );
}
