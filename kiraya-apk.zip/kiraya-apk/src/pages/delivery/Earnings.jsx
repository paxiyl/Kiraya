import React, { useState, useEffect } from "react";
import { Wallet, Bike, TrendingUp } from "lucide-react";
import { getOrdersByCustomer } from "@/lib/firestore";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";

export default function DeliveryEarnings() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    const q = query(collection(db, "orders"), where("deliveryPartnerId", "==", user.uid), where("status", "==", "DELIVERED"));
    getDocs(q).then(snap => { setOrders(snap.docs.map(d => ({ id: d.id, ...d.data() }))); setLoading(false); });
  }, [user]);

  const total = orders.reduce((s, o) => s + (o.deliveryFee || 0), 0);
  const today = orders.filter(o => {
    const d = o.deliveredAt?.toDate?.();
    return d && new Date().toDateString() === d.toDateString();
  }).reduce((s, o) => s + (o.deliveryFee || 0), 0);

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-5">
      <h1 className="text-xl font-bold tracking-tight">Earnings</h1>

      <div className="grid grid-cols-2 gap-3">
        {[{ label: "Total earned", value: formatPrice(total), icon: Wallet },
          { label: "Today", value: formatPrice(today), icon: TrendingUp },
          { label: "Total deliveries", value: orders.length, icon: Bike }].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      <div>
        <h2 className="text-sm font-semibold mb-3">Delivery history</h2>
        {orders.length === 0 ? (
          <div className="py-12 text-center"><p className="text-sm text-[hsl(var(--text-tertiary))]">No completed deliveries yet</p></div>
        ) : (
          <div className="space-y-2">
            {orders.map(o => (
              <div key={o.id} className="card-soft rounded-2xl p-3 flex items-center justify-between">
                <div>
                  <p className="text-xs font-mono text-[hsl(var(--text-tertiary))]">#{o.id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm font-medium">{o.address?.city}</p>
                </div>
                <p className="font-semibold text-green-600">{formatPrice(o.deliveryFee || 0)}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
