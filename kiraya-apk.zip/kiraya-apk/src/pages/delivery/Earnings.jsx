import React from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart } from "@/components/admin/Charts";
import { deliveryStats, weeklyRevenue, payoutHistory } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { Wallet, Navigation, CheckCircle2, Star } from "lucide-react";
import { Pill } from "@/components/customer/StatusBadge";

const ICONS = { today: Wallet, week: Navigation, completed: CheckCircle2, rating: Star };

export default function DeliveryEarnings() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-lg font-semibold">Earnings</h1>
        <p className="text-xs text-[hsl(var(--text-tertiary))]">Your delivery income</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {deliveryStats.map(({ key, ...rest }) => <StatCard key={key} {...rest} icon={ICONS[key]} tone="accent" />)}
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Weekly earnings</h3>
        <RevenueChart data={weeklyRevenue.map((d) => ({ day: d.day, revenue: Math.round(d.revenue * 0.12) }))} />
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Payouts</h3>
        <div className="space-y-2">
          {payoutHistory.map((p) => (
            <div key={p.id} className="flex items-center justify-between text-sm">
              <div><p className="font-medium">{p.week}</p><p className="text-xs text-[hsl(var(--text-tertiary))]">Weekly payout</p></div>
              <div className="flex items-center gap-3">
                <span className="font-bold">{formatPrice(p.amount)}</span>
                <Pill tone={p.status === "Paid" ? "success" : "warning"}>{p.status}</Pill>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}