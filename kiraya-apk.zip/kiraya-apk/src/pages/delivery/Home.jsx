import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { deliveryRequests, deliveryStats } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import StatCard from "@/components/admin/StatCard";
import { Bike, Navigation, CheckCircle2, Star } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

const ICONS = { today: Bike, week: Navigation, completed: CheckCircle2, rating: Star };

export default function DeliveryHome() {
  const navigate = useNavigate();
  const { toast } = useToast();
  const [online, setOnline] = useState(true);
  const [requests, setRequests] = useState(deliveryRequests);

  const accept = (id) => {
    setRequests((r) => r.filter((x) => x.id !== id));
    toast({ title: "Delivery accepted", description: id });
    navigate("/delivery/active");
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold">Hi, Vikram 👋</h1>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">You're ready to deliver</p>
        </div>
        <button onClick={() => setOnline(!online)} className="press flex items-center gap-2 px-3 h-10 rounded-full glass">
          <span className={`w-2.5 h-2.5 rounded-full ${online ? "bg-[hsl(var(--success))]" : "bg-[hsl(var(--text-tertiary))]"}`} />
          <span className="text-sm font-medium">{online ? "Online" : "Offline"}</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {deliveryStats.map(({ key, ...rest }) => <StatCard key={key} {...rest} icon={ICONS[key]} tone="accent" />)}
      </div>

      <div>
        <h2 className="text-sm font-semibold mb-2">Available deliveries</h2>
        {!online ? (
          <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-10">You're offline. Go online to receive requests.</p>
        ) : requests.length === 0 ? (
          <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-10">No deliveries nearby right now.</p>
        ) : (
          <div className="space-y-3">
            {requests.map((r) => (
              <motion.div key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card-soft rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold">{r.store}</p>
                  <span className="text-sm font-bold text-[hsl(var(--accent))]">{formatPrice(r.earnings)}</span>
                </div>
                <div className="mt-2 space-y-1.5 text-sm">
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))]" /><span className="text-[hsl(var(--text-secondary))]">{r.pickup}</span></div>
                  <div className="flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-[hsl(var(--warning))]" /><span className="text-[hsl(var(--text-secondary))]">{r.drop}</span></div>
                </div>
                <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-tertiary))]">
                  <span>{r.distance}</span> · <span>{r.eta}</span> · <span>{r.size}</span>
                </div>
                <button onClick={() => accept(r.id)} className="press w-full h-11 mt-3 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold">Accept · {formatPrice(r.earnings)}</button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}