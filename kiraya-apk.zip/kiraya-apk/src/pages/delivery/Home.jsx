import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Bike, Package, TrendingUp, Navigation } from "lucide-react";
import { listenAvailableOrders, acceptDelivery, getDeliveryHistory } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

export default function DeliveryHome() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [online,    setOnline]    = useState(false);
  const [available, setAvailable] = useState([]);
  const [todayEarnings, setTodayEarnings] = useState(0);
  const [todayCount,    setTodayCount]    = useState(0);
  const [accepting, setAccepting] = useState(null);

  const firstName = profile?.display_name?.split(" ")[0] || "Partner";

  useEffect(() => {
    if (!user) return;
    // Load today's stats
    getDeliveryHistory(user.id).then(orders => {
      const today = orders.filter(o => {
        const d = o.delivered_at ? new Date(o.delivered_at) : null;
        return d && new Date().toDateString() === d.toDateString();
      });
      setTodayCount(today.length);
      setTodayEarnings(today.reduce((s, o) => s + (o.delivery_fee || 0), 0));
    });
  }, [user]);

  useEffect(() => {
    if (!online) { setAvailable([]); return; }
    const unsub = listenAvailableOrders(setAvailable);
    return unsub;
  }, [online]);

  const accept = async (order) => {
    setAccepting(order.id);
    try {
      await acceptDelivery(order.id, user.id);
      toast({ title: "Delivery accepted!", description: `Order #${order.id.slice(-6).toUpperCase()}` });
      navigate("/delivery/active");
    } catch (e) {
      toast({ title: "Failed", description: "Order may have been taken.", variant: "destructive" });
    } finally { setAccepting(null); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold">Hi, {firstName} 👋</h1>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">
            {online ? "You're online — ready to deliver" : "Go online to receive orders"}
          </p>
        </div>
        <button onClick={() => setOnline(o => !o)}
          className={`press flex items-center gap-2 px-4 h-10 rounded-full font-medium text-sm transition-colors
            ${online ? "bg-green-500 text-white" : "glass"}`}>
          <span className={`w-2 h-2 rounded-full ${online ? "bg-white animate-pulse" : "bg-[hsl(var(--text-tertiary))]"}`} />
          {online ? "Online" : "Offline"}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Today's earnings",   value: formatPrice(todayEarnings), icon: TrendingUp },
          { label: "Today's deliveries", value: todayCount,                 icon: Bike },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      <div>
        <h2 className="text-sm font-semibold mb-3">
          {online ? `Available orders (${available.length})` : "Available orders"}
        </h2>
        {!online ? (
          <div className="py-16 text-center space-y-2">
            <Bike className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
            <p className="text-sm text-[hsl(var(--text-tertiary))]">Go online to start receiving orders</p>
          </div>
        ) : available.length === 0 ? (
          <div className="py-16 text-center space-y-2">
            <Package className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
            <p className="text-sm text-[hsl(var(--text-tertiary))]">No orders available right now</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))]">New orders appear here instantly</p>
          </div>
        ) : (
          <div className="space-y-3">
            {available.map(order => (
              <motion.div key={order.id} initial={{ opacity:0, y:8 }} animate={{ opacity:1, y:0 }}
                className="card-soft rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-[hsl(var(--text-tertiary))]">#{order.id.slice(-6).toUpperCase()}</p>
                    <p className="text-sm font-semibold mt-0.5">
                      {order.items?.length} item{order.items?.length !== 1 ? "s" : ""}
                    </p>
                  </div>
                  <span className="text-base font-bold text-green-600">{formatPrice(order.delivery_fee || 0)}</span>
                </div>
                <div className="space-y-1.5 text-sm">
                  <div className="flex items-start gap-2">
                    <span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))] mt-1.5 shrink-0" />
                    <span className="text-[hsl(var(--text-secondary))]">Pickup: Store location</span>
                  </div>
                  <div className="flex items-start gap-2">
                    <span className="w-2 h-2 rounded-full bg-orange-400 mt-1.5 shrink-0" />
                    <span className="text-[hsl(var(--text-secondary))]">Drop: {order.address?.line}, {order.address?.city}</span>
                  </div>
                </div>
                <button onClick={() => accept(order)} disabled={accepting === order.id}
                  className="press w-full h-11 rounded-xl bg-[hsl(var(--accent))] text-white font-semibold text-sm disabled:opacity-60">
                  {accepting === order.id ? "Accepting…" : "Accept delivery"}
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
