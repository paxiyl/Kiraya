import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Bike, Navigation, CheckCircle2, Star, MapPin, Package } from "lucide-react";
import { listenAvailableOrders, acceptDelivery, getOrdersByStore } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";
import { useToast } from "@/components/ui/use-toast";
import { motion } from "framer-motion";

export default function DeliveryHome() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [online, setOnline] = useState(false);
  const [available, setAvailable] = useState([]);
  const [accepting, setAccepting] = useState(null);

  const firstName = profile?.displayName?.split(" ")[0] || "Partner";

  useEffect(() => {
    if (!online) return;
    const unsub = listenAvailableOrders(setAvailable);
    return unsub;
  }, [online]);

  const accept = async (order) => {
    setAccepting(order.id);
    try {
      await acceptDelivery(order.id, user.uid);
      toast({ title: "Delivery accepted!", description: `Order ${order.id.slice(-6).toUpperCase()}` });
      navigate("/delivery/active");
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally {
      setAccepting(null);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold">Hi, {firstName} 👋</h1>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">{online ? "You're online — ready to deliver" : "Go online to receive orders"}</p>
        </div>
        <button onClick={() => setOnline(o => !o)}
          className={`press flex items-center gap-2 px-4 h-10 rounded-full font-medium text-sm transition-colors ${online ? "bg-green-500 text-white" : "glass"}`}>
          <span className={`w-2 h-2 rounded-full ${online ? "bg-white" : "bg-[hsl(var(--text-tertiary))]"}`} />
          {online ? "Online" : "Offline"}
        </button>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 gap-3">
        {[{ label: "Today's deliveries", value: "—", icon: Bike }, { label: "Today's earnings", value: "—", icon: Navigation }].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      {/* Available orders */}
      <div>
        <h2 className="text-sm font-semibold mb-3">Available orders</h2>
        {!online ? (
          <div className="py-16 text-center space-y-2">
            <Bike className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
            <p className="text-sm text-[hsl(var(--text-tertiary))]">Go online to start receiving orders</p>
          </div>
        ) : available.length === 0 ? (
          <div className="py-16 text-center space-y-2">
            <Package className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
            <p className="text-sm text-[hsl(var(--text-tertiary))]">No orders available right now</p>
            <p className="text-xs text-[hsl(var(--text-tertiary))]">New orders will appear here instantly</p>
          </div>
        ) : (
          <div className="space-y-3">
            {available.map(order => (
              <motion.div key={order.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card-soft rounded-2xl p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-xs text-[hsl(var(--text-tertiary))]">Order #{order.id.slice(-6).toUpperCase()}</p>
                    <p className="text-sm font-semibold mt-0.5">{order.items?.length} item{order.items?.length !== 1 ? "s" : ""}</p>
                  </div>
                  <span className="text-base font-bold text-[hsl(var(--accent))]">{formatPrice(order.deliveryFee || 0)}</span>
                </div>
                <div className="space-y-1.5">
                  <div className="flex items-start gap-2 text-sm">
                    <span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))] mt-1.5 shrink-0" />
                    <span className="text-[hsl(var(--text-secondary))]">Pickup: {order.address?.city || "Store"}</span>
                  </div>
                  <div className="flex items-start gap-2 text-sm">
                    <span className="w-2 h-2 rounded-full bg-orange-400 mt-1.5 shrink-0" />
                    <span className="text-[hsl(var(--text-secondary))]">Drop: {order.address?.line}, {order.address?.city}</span>
                  </div>
                </div>
                <button onClick={() => accept(order)} disabled={accepting === order.id}
                  className="press w-full h-11 rounded-xl bg-[hsl(var(--accent))] text-white font-semibold text-sm disabled:opacity-60">
                  {accepting === order.id ? "Accepting…" : "Accept delivery"}
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
