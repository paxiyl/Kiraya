import React, { useState, useRef } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Bike, LogOut, Pencil, Camera, Loader2, Shield, FileText, ChevronRight, Moon } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";
import { upsertProfile, signOut, uploadImage } from "@/lib/db";
import { useToast } from "@/components/ui/use-toast";
import { APP_CONFIG } from "@/lib/appConfig";

export default function DeliveryProfile() {
  const { user, profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [dark, setDark] = useState(false);
  const fileRef = useRef();
  const [form, setForm] = useState({
    display_name: profile?.display_name || "",
    phone: profile?.phone || "",
    vehicle_type: profile?.vehicle_type || "",
    vehicle_number: profile?.vehicle_number || "",
  });

  const handleAvatar = async (file) => {
    setUploading(true);
    try {
      const url = await uploadImage(file, "kiraya/avatars");
      await upsertProfile(user.id, { avatar_url: url });
      await refreshProfile();
      toast({ title: "Photo updated ✓" });
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally { setUploading(false); }
  };

  const save = async () => {
    setSaving(true);
    try {
      await upsertProfile(user.id, form);
      await refreshProfile();
      setEditing(false);
      toast({ title: "Profile saved ✓" });
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const logout = async () => { await signOut(); navigate("/login"); };
  const toggleDark = () => { setDark(d => { document.documentElement.classList.toggle("dark", !d); return !d; }); };
  const initial = (profile?.display_name || "?").charAt(0).toUpperCase();

  return (
    <div className="space-y-5 pb-6">
      <div className="card-soft rounded-3xl p-5 flex items-center gap-4">
        <div className="relative">
          <input type="file" ref={fileRef} accept="image/*" className="hidden" onChange={e => e.target.files[0] && handleAvatar(e.target.files[0])} />
          <div className="w-16 h-16 rounded-full bg-gradient-to-br from-orange-400 to-orange-600 text-white grid place-items-center text-xl font-bold overflow-hidden">
            {profile?.avatar_url ? <img src={profile.avatar_url} className="w-full h-full object-cover" alt="" /> : initial}
          </div>
          <button onClick={() => fileRef.current.click()} disabled={uploading}
            className="press absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-orange-500 text-white grid place-items-center">
            {uploading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Camera className="w-3 h-3" />}
          </button>
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-base font-semibold">{profile?.display_name || "Delivery Partner"}</h1>
          <p className="text-xs text-[hsl(var(--text-secondary))]">{user?.email}</p>
          {profile?.vehicle_type && <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5 flex items-center gap-1"><Bike className="w-3 h-3" />{profile.vehicle_type} · {profile.vehicle_number}</p>}
        </div>
        <button onClick={() => setEditing(true)} className="press w-9 h-9 rounded-xl bg-[hsl(var(--muted))] grid place-items-center">
          <Pencil className="w-4 h-4" />
        </button>
      </div>

      <div className="card-soft rounded-2xl overflow-hidden divide-y divide-[hsl(var(--border))]">
        <div className="flex items-center gap-3 px-4 py-3.5">
          <Moon className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
          <span className="flex-1 text-sm">Dark mode</span>
          <button onClick={toggleDark} className={`w-11 h-6 rounded-full transition-colors ${dark ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--border))]"}`}>
            <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform mt-0.5 ${dark ? "translate-x-5" : "translate-x-0.5"}`} />
          </button>
        </div>
      </div>

      <div className="card-soft rounded-2xl overflow-hidden divide-y divide-[hsl(var(--border))]">
        <Link to="/terms" className="flex items-center gap-3 px-4 py-3.5"><FileText className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" /><span className="flex-1 text-sm">Terms of Service</span><ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" /></Link>
        <Link to="/privacy" className="flex items-center gap-3 px-4 py-3.5"><Shield className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" /><span className="flex-1 text-sm">Privacy Policy</span><ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" /></Link>
      </div>

      <button onClick={logout} className="press w-full h-12 rounded-2xl card-soft text-sm font-medium text-red-500 flex items-center justify-center gap-2">
        <LogOut className="w-4 h-4" /> Log out
      </button>
      <p className="text-center text-[11px] text-[hsl(var(--text-tertiary))]">{APP_CONFIG.name} v{APP_CONFIG.version}</p>

      {editing && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setEditing(false)}>
          <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
          <div onClick={e => e.stopPropagation()} className="relative w-full bg-background rounded-t-3xl p-5">
            <h3 className="text-base font-semibold mb-4">Edit profile</h3>
            <div className="space-y-3">
              {[["display_name","Full name","text"],["phone","Phone","tel"],["vehicle_type","Vehicle type","text"],["vehicle_number","Vehicle number","text"]].map(([f,l,t]) => (
                <div key={f}>
                  <label className="text-xs text-[hsl(var(--text-tertiary))]">{l}</label>
                  <input type={t} value={form[f]} onChange={e => setForm(x => ({ ...x, [f]: e.target.value }))}
                    className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-5">
              <button onClick={() => setEditing(false)} className="press flex-1 h-12 rounded-2xl border border-[hsl(var(--border))] text-sm">Cancel</button>
              <button onClick={save} disabled={saving} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold disabled:opacity-60">
                {saving ? <Loader2 className="w-4 h-4 animate-spin mx-auto" /> : "Save"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
