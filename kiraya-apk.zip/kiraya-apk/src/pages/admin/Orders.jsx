import React, { useState } from "react";
import DataTable from "@/components/admin/DataTable";
import StatusBadge from "@/components/customer/StatusBadge";
import { adminOrders } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { X } from "lucide-react";

const FILTERS = [
  { id: "all", label: "All" },
  { id: "PENDING", label: "Pending" },
  { id: "PREPARING", label: "Preparing" },
  { id: "OUT_FOR_DELIVERY", label: "On the way" },
  { id: "DELIVERED", label: "Delivered" },
  { id: "CANCELLED", label: "Cancelled" },
];

export default function AdminOrders() {
  const [filter, setFilter] = useState("all");
  const [detail, setDetail] = useState(null);
  const rows = filter === "all" ? adminOrders : adminOrders.filter((o) => o.status === filter);

  const columns = [
    { key: "id", label: "Order", render: (r) => <span className="font-medium">{r.id}</span>, sortable: true },
    { key: "customer", label: "Customer", sortable: true },
    { key: "store", label: "Store" },
    { key: "amount", label: "Amount", render: (r) => <span className="font-medium">{formatPrice(r.amount)}</span>, sortable: true },
    { key: "payment", label: "Payment" },
    { key: "partner", label: "Partner" },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
    { key: "time", label: "Time" },
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Orders</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Manage all platform orders</p>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {FILTERS.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`press shrink-0 px-3.5 h-9 rounded-full text-sm font-medium ${filter === f.id ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {f.label}
          </button>
        ))}
      </div>

      <DataTable columns={columns} rows={rows} searchKeys={["id", "customer", "store"]} onRowClick={setDetail} />

      {detail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-md card-soft rounded-3xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold">{detail.id}</h3>
              <button onClick={() => setDetail(null)} className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>
            <StatusBadge status={detail.status} />
            <div className="mt-4 space-y-2 text-sm">
              <Row k="Customer" v={detail.customer} />
              <Row k="Store" v={detail.store} />
              <Row k="Partner" v={detail.partner} />
              <Row k="Payment" v={detail.payment} />
              <Row k="Time" v={detail.time} />
              <Row k="Amount" v={formatPrice(detail.amount)} bold />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ k, v, bold }) {
  return (
    <div className="flex justify-between border-b border-[hsl(var(--border))] pb-2">
      <span className="text-[hsl(var(--text-tertiary))]">{k}</span>
      <span className={bold ? "font-bold" : "font-medium"}>{v}</span>
    </div>
  );
}