import React, { useState, useEffect } from "react";
import { ShoppingBag, Search } from "lucide-react";
import { listenAllOrders, updateOrderStatus } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import StatusBadge from "@/components/customer/StatusBadge";
import { useToast } from "@/components/ui/use-toast";

const TABS = ["All","Pending","Preparing","Ready","Out for Delivery","Delivered","Cancelled"];

export default function AdminOrders() {
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [tab, setTab]       = useState("All");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = listenAllOrders(o => { setOrders(o); setLoading(false); });
    return unsub;
  }, []);

  const cancel = async (id) => {
    if (!confirm("Cancel this order?")) return;
    try { await updateOrderStatus(id, "CANCELLED"); toast({ title: "Cancelled" }); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const tabStatus = tab === "All" ? null : tab.toUpperCase().replace(/ /g, "_");
  const filtered  = orders.filter(o => {
    const matchTab    = !tabStatus || o.status === tabStatus;
    const matchSearch = !search || o.customer_name?.toLowerCase().includes(search.toLowerCase()) || o.id.includes(search);
    return matchTab && matchSearch;
  });

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">All Orders</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{orders.length} total</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        <input className="w-full h-11 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
          placeholder="Search by name or order ID…" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
        {TABS.map(t => (
          <button key={t} onClick={() => setTab(t)}
            className={`press shrink-0 px-3 h-8 rounded-full text-xs font-medium transition-colors
              ${tab === t ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {t}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-16 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center"><ShoppingBag className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto mb-2" /><p className="text-sm text-[hsl(var(--text-tertiary))]">No orders found</p></div>
      ) : (
        <div className="space-y-2">
          {filtered.map(order => (
            <div key={order.id} className="card-soft rounded-2xl p-4 space-y-2">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] font-mono">#{order.id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm font-semibold">{order.customer_name || "Customer"}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{order.address?.city}</p>
                </div>
                <div className="text-right space-y-1">
                  <p className="font-bold text-sm">{formatPrice(order.total)}</p>
                  <StatusBadge status={order.status} />
                </div>
              </div>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">
                {order.items?.map(i => `${i.name} ×${i.qty}`).join(" · ")}
              </p>
              {!["DELIVERED","CANCELLED"].includes(order.status) && (
                <button onClick={() => cancel(order.id)}
                  className="press w-full h-9 rounded-xl border border-red-200 text-red-500 text-xs font-medium">
                  Cancel order
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
