import React, { useState } from "react";
import { Loader2, Bell, Store, Bike, Users, Shield } from "lucide-react";
import { supabase } from "@/lib/supabase";
import { useToast } from "@/components/ui/use-toast";
import { APP_CONFIG } from "@/lib/appConfig";

export default function AdminSettings() {
  const { toast } = useToast();
  const [sending, setSending] = useState(false);
  const [notifTitle, setNotifTitle] = useState("");
  const [notifBody, setNotifBody]   = useState("");
  const [targetRole, setTargetRole] = useState("customer");

  const sendNotification = async () => {
    if (!notifTitle.trim()) return;
    setSending(true);
    try {
      // Get all users with that role
      const { data: users } = await supabase.from("profiles").select("id").eq("role", targetRole);
      if (!users?.length) { toast({ title:"No users with that role" }); return; }
      const rows = users.map(u => ({
        user_id: u.id, title: notifTitle, body: notifBody, type:"announcement",
      }));
      await supabase.from("notifications").insert(rows);
      toast({ title:`Sent to ${rows.length} ${targetRole.replace("_"," ")}(s) ✓` });
      setNotifTitle(""); setNotifBody("");
    } catch (e) {
      toast({ title:"Error", description:e.message, variant:"destructive" });
    } finally { setSending(false); }
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Admin Settings</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{APP_CONFIG.name} · {APP_CONFIG.city}</p>
      </div>

      {/* App info */}
      <div className="card-soft rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold">App Info</h3>
        {[
          ["App name",     APP_CONFIG.name],
          ["City",         APP_CONFIG.city],
          ["Version",      APP_CONFIG.version],
          ["Support",      APP_CONFIG.supportEmail],
        ].map(([l,v]) => (
          <div key={l} className="flex justify-between text-sm">
            <span className="text-[hsl(var(--text-tertiary))]">{l}</span>
            <span className="font-medium">{v}</span>
          </div>
        ))}
      </div>

      {/* Send notification */}
      <div className="card-soft rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Bell className="w-4 h-4 text-[hsl(var(--accent))]" /> Send Notification
        </h3>
        <div>
          <label className="text-xs text-[hsl(var(--text-tertiary))]">Send to</label>
          <select value={targetRole} onChange={e => setTargetRole(e.target.value)}
            className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm">
            <option value="customer">All Customers</option>
            <option value="store_owner">All Store Owners</option>
            <option value="delivery_partner">All Delivery Partners</option>
          </select>
        </div>
        <div>
          <label className="text-xs text-[hsl(var(--text-tertiary))]">Title</label>
          <input type="text" placeholder="Notification title" value={notifTitle}
            onChange={e => setNotifTitle(e.target.value)}
            className="w-full mt-1 h-11 px-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
        </div>
        <div>
          <label className="text-xs text-[hsl(var(--text-tertiary))]">Message</label>
          <textarea rows={2} placeholder="Notification message…" value={notifBody}
            onChange={e => setNotifBody(e.target.value)}
            className="w-full mt-1 px-3 py-2 rounded-xl border border-[hsl(var(--border))] bg-background text-sm resize-none focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]" />
        </div>
        <button onClick={sendNotification} disabled={sending || !notifTitle.trim()}
          className="press w-full h-11 rounded-xl bg-[hsl(var(--accent))] text-white font-semibold text-sm disabled:opacity-50 flex items-center justify-center gap-2">
          {sending ? <><Loader2 className="w-4 h-4 animate-spin" />Sending…</> : "Send notification"}
        </button>
      </div>

      {/* Role guide */}
      <div className="card-soft rounded-2xl p-4 space-y-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Shield className="w-4 h-4 text-[hsl(var(--accent))]" /> Role Guide
        </h3>
        {[
          { icon:Users,  role:"customer",         desc:"Can browse stores and place orders" },
          { icon:Store,  role:"store_owner",       desc:"Can manage their store, products and orders" },
          { icon:Bike,   role:"delivery_partner",  desc:"Can accept and deliver orders" },
          { icon:Shield, role:"admin",             desc:"Full access to everything" },
        ].map(({ icon:Icon, role, desc }) => (
          <div key={role} className="flex items-start gap-3">
            <Icon className="w-4 h-4 text-[hsl(var(--text-secondary))] mt-0.5 shrink-0" />
            <div>
              <p className="text-sm font-medium capitalize">{role.replace("_"," ")}</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">{desc}</p>
            </div>
          </div>
        ))}
        <p className="text-xs text-[hsl(var(--text-tertiary))] pt-1">Change user roles in the Users tab.</p>
      </div>
    </div>
  );
}
