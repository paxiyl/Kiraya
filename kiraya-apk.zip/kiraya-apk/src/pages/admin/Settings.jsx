import React, { useState } from "react";
import { APP_CONFIG } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";

export default function AdminSettings() {
  const { toast } = useToast();
  const [city, setCity] = useState(APP_CONFIG.city);
  const [commission, setCommission] = useState(12);
  const [platformFee, setPlatformFee] = useState(5);
  const [maintenance, setMaintenance] = useState(false);

  const save = () => toast({ title: "Settings saved", description: "Platform settings updated." });

  return (
    <div className="space-y-5 max-w-xl">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Platform configuration</p>
      </div>
      <Field label="Platform name" value={APP_CONFIG.name} readOnly />
      <Field label="Default city" value={city} onChange={setCity} />
      <Field label="Default commission (%)" value={commission} onChange={(v) => setCommission(Number(v))} type="number" />
      <Field label="Platform fee (₹)" value={platformFee} onChange={(v) => setPlatformFee(Number(v))} type="number" />
      <div className="card-soft rounded-2xl p-4 flex items-center justify-between">
        <div>
          <p className="text-sm font-medium">Maintenance mode</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">Temporarily disable new orders</p>
        </div>
        <button onClick={() => setMaintenance(!maintenance)} className={`press w-11 h-6 rounded-full transition-colors ${maintenance ? "bg-[hsl(var(--danger))]" : "bg-[hsl(var(--border))]"}`}>
          <span className={`block w-5 h-5 rounded-full bg-white transition-transform ${maintenance ? "translate-x-5" : "translate-x-0.5"} mt-0.5`} />
        </button>
      </div>
      <button onClick={save} className="press h-11 px-5 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold">Save changes</button>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", readOnly }) {
  return (
    <div>
      <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">{label}</label>
      <input
        type={type}
        value={value}
        readOnly={readOnly}
        onChange={(e) => onChange?.(e.target.value)}
        className="mt-1 w-full h-11 px-4 rounded-2xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--accent))]"
      />
    </div>
  );
}