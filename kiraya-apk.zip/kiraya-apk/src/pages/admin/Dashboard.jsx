import React from "react";
import { Wallet, ShoppingCart, Bike, Users, Store, Package, Clock, Ban } from "lucide-react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart, OrdersChart, CategoryPie } from "@/components/admin/Charts";
import DataTable from "@/components/admin/DataTable";
import { adminStats, weeklyRevenue, categoryShare, adminOrders } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import StatusBadge from "@/components/customer/StatusBadge";

const ICONS = { revenue: Wallet, orders: ShoppingCart, activeDeliveries: Bike, customers: Users, stores: Store, partners: Package, pending: Clock, cancelled: Ban };

export default function AdminDashboard() {
  const stats = adminStats;
  const recentCols = [
    { key: "id", label: "Order", render: (r) => <span className="font-medium">{r.id}</span> },
    { key: "customer", label: "Customer" },
    { key: "store", label: "Store" },
    { key: "amount", label: "Amount", render: (r) => formatPrice(r.amount), sortable: true },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Overview of platform performance</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.slice(0, 4).map(({ key, ...rest }) => {
          const Icon = ICONS[key];
          const tone = key === "cancelled" ? "danger" : key === "pending" ? "warning" : "accent";
          return <StatCard key={key} {...rest} icon={Icon} tone={tone} />;
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Revenue (last 7 days)</h3>
          <RevenueChart data={weeklyRevenue} />
        </div>
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Orders by category</h3>
          <CategoryPie data={categoryShare} />
          <div className="mt-3 grid grid-cols-2 gap-1.5">
            {categoryShare.map((c) => (
              <div key={c.name} className="flex items-center gap-1.5 text-xs">
                <span className="w-2.5 h-2.5 rounded-full" style={{ background: c.color }} />
                <span className="text-[hsl(var(--text-secondary))]">{c.name}</span>
                <span className="ml-auto font-medium">{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.slice(4).map(({ key, ...rest }) => {
          const Icon = ICONS[key];
          const tone = key === "cancelled" ? "danger" : "accent";
          return <StatCard key={key} {...rest} icon={Icon} tone={tone} />;
        })}
      </div>

      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-1">Orders (last 7 days)</h3>
        <OrdersChart data={weeklyRevenue} />
      </div>

      <div>
        <h3 className="text-sm font-semibold mb-3">Recent orders</h3>
        <DataTable columns={recentCols} rows={adminOrders} searchKeys={["id", "customer", "store"]} title="" />
      </div>
    </div>
  );
}