import React, { useState, useEffect } from "react";
import { ShoppingBag, Store, Users, Wallet } from "lucide-react";
import { listenAllOrders, getAllStoresAdmin, getAllUsers, approveStore, updateOrderStatus } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";
import StatusBadge from "@/components/customer/StatusBadge";

export default function AdminDashboard() {
  const { toast } = useToast();
  const [orders, setOrders]   = useState([]);
  const [stores, setStores]   = useState([]);
  const [users, setUsers]     = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsub = listenAllOrders(o => { setOrders(o); setLoading(false); });
    getAllStoresAdmin().then(setStores);
    getAllUsers().then(setUsers);
    return unsub;
  }, []);

  const approve = async (id) => {
    try {
      await approveStore(id);
      setStores(s => s.map(x => x.id === id ? { ...x, approved: true } : x));
      toast({ title: "Store approved ✓" });
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const revenue        = orders.filter(o => o.status === "DELIVERED").reduce((s, o) => s + (o.total || 0), 0);
  const pendingStores  = stores.filter(s => !s.approved);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Admin Dashboard</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Live overview</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Total revenue", value: formatPrice(revenue), icon: Wallet },
          { label: "Total orders",  value: orders.length,        icon: ShoppingBag },
          { label: "Stores",        value: stores.length,        icon: Store },
          { label: "Users",         value: users.length,         icon: Users },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      {pendingStores.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold mb-2 text-orange-500">⏳ Pending approvals ({pendingStores.length})</h2>
          <div className="space-y-2">
            {pendingStores.map(store => (
              <div key={store.id} className="card-soft rounded-2xl p-4 flex items-center gap-3">
                {store.image_url
                  ? <img src={store.image_url} className="w-12 h-12 rounded-xl object-cover" alt="" />
                  : <div className="w-12 h-12 rounded-xl bg-[hsl(var(--muted))] grid place-items-center font-bold text-[hsl(var(--text-tertiary))]">{store.name?.charAt(0)}</div>
                }
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{store.name}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{store.category} · {store.address}</p>
                </div>
                <button onClick={() => approve(store.id)}
                  className="press h-9 px-3 rounded-xl bg-green-500 text-white text-xs font-semibold shrink-0">
                  Approve
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      <div>
        <h2 className="text-sm font-semibold mb-2">Recent orders</h2>
        {loading ? (
          <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-14 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}</div>
        ) : orders.length === 0 ? (
          <div className="py-12 text-center"><p className="text-sm text-[hsl(var(--text-tertiary))]">No orders yet</p></div>
        ) : (
          <div className="space-y-2">
            {orders.slice(0, 20).map(order => (
              <div key={order.id} className="card-soft rounded-2xl p-3 flex items-center gap-3">
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-[hsl(var(--text-tertiary))] font-mono">#{order.id.slice(-6).toUpperCase()}</p>
                  <p className="text-sm font-medium truncate">{order.customer_name || "Customer"}</p>
                </div>
                <div className="text-right space-y-1">
                  <p className="text-sm font-bold">{formatPrice(order.total)}</p>
                  <StatusBadge status={order.status} />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
