import React, { useState, useEffect } from "react";
import { Bike, Search } from "lucide-react";
import { getAllUsers, getAllOrders } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";

export default function AdminDelivery() {
  const [partners, setPartners] = useState([]);
  const [orders, setOrders]     = useState([]);
  const [loading, setLoading]   = useState(true);
  const [search, setSearch]     = useState("");

  useEffect(() => {
    Promise.all([getAllUsers(), getAllOrders()]).then(([users, ords]) => {
      setPartners(users.filter(u => u.role === "delivery_partner"));
      setOrders(ords.filter(o => o.status === "DELIVERED"));
      setLoading(false);
    });
  }, []);

  const statsFor = (uid) => {
    const delivered = orders.filter(o => o.delivery_partner_id === uid);
    const earnings  = delivered.reduce((s, o) => s + (o.delivery_fee || 0), 0);
    return { count: delivered.length, earnings };
  };

  const filtered = partners.filter(p =>
    p.display_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.email?.toLowerCase().includes(search.toLowerCase())
  );

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Delivery Partners</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{partners.length} partners registered</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        <input className="w-full h-11 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
          placeholder="Search partners…" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {filtered.length === 0 ? (
        <div className="py-16 text-center space-y-2">
          <Bike className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No delivery partners yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {filtered.map(p => {
            const { count, earnings } = statsFor(p.id);
            return (
              <div key={p.id} className="card-soft rounded-2xl p-4 flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-orange-100 grid place-items-center font-bold text-orange-600 shrink-0 overflow-hidden">
                  {p.avatar_url ? <img src={p.avatar_url} className="w-full h-full object-cover" alt="" /> : (p.display_name?.charAt(0) || "?").toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{p.display_name || "—"}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] truncate">{p.phone || p.email}</p>
                  {p.vehicle_type && <p className="text-xs text-[hsl(var(--text-tertiary))]">🚴 {p.vehicle_type} · {p.vehicle_number}</p>}
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-bold text-green-600">{formatPrice(earnings)}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{count} deliveries</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
