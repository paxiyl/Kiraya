import React from "react";
import StatCard from "@/components/admin/StatCard";
import DataTable from "@/components/admin/DataTable";
import { adminPartners } from "@/data/panelData";
import { Bike, Star, Navigation } from "lucide-react";
import { formatPrice } from "@/lib/appConfig";
import { Pill } from "@/components/customer/StatusBadge";

const TONE = { Available: "success", "On delivery": "accent", Offline: "neutral" };

export default function AdminDelivery() {
  const cols = [
    { key: "name", label: "Partner", render: (r) => (
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center text-xs font-bold">{r.name.charAt(0)}</div>
        <span className="font-medium">{r.name}</span>
      </div>
    ), sortable: true },
    { key: "vehicle", label: "Vehicle" },
    { key: "active", label: "Active", sortable: true },
    { key: "completed", label: "Completed", sortable: true },
    { key: "earnings", label: "Earnings", render: (r) => formatPrice(r.earnings), sortable: true },
    { key: "rating", label: "Rating", render: (r) => <span className="inline-flex items-center gap-0.5"><Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {r.rating}</span>, sortable: true },
    { key: "status", label: "Status", render: (r) => <Pill tone={TONE[r.status]}><span className={`w-1.5 h-1.5 rounded-full ${r.online ? "bg-current" : "bg-current opacity-40"}`} /> {r.status}</Pill> },
  ];
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Delivery Partners</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{adminPartners.length} partners · real-time status</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Online Now" value={adminPartners.filter(p => p.online).length} icon={Bike} tone="accent" />
        <StatCard label="On Delivery" value={adminPartners.filter(p => p.status === "On delivery").length} icon={Navigation} tone="warning" />
        <StatCard label="Total Earnings" value={adminPartners.reduce((s, p) => s + p.earnings, 0)} prefix="₹" icon={Bike} tone="success" />
        <StatCard label="Avg Rating" value={(adminPartners.reduce((s, p) => s + p.rating, 0) / adminPartners.length).toFixed(1)} icon={Star} tone="neutral" />
      </div>
      <DataTable columns={cols} rows={adminPartners} searchKeys={["name", "vehicle"]} />
    </div>
  );
}