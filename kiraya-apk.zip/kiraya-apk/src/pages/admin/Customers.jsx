import React, { useState, useEffect } from "react";
import { Users, Search, ShieldCheck } from "lucide-react";
import { getAllUsers, upsertProfile } from "@/lib/db";
import { useToast } from "@/components/ui/use-toast";

const ROLES = ["customer","store_owner","delivery_partner","admin"];

export default function AdminCustomers() {
  const { toast } = useToast();
  const [users, setUsers]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const reload = () => getAllUsers().then(u => { setUsers(u); setLoading(false); });
  useEffect(() => { reload(); }, []);

  const changeRole = async (id, role) => {
    try {
      await upsertProfile(id, { role });
      toast({ title: `Role → ${role}` });
      reload();
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    }
  };

  const filtered = users.filter(u =>
    u.display_name?.toLowerCase().includes(search.toLowerCase()) ||
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Users</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{users.length} registered</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        <input className="w-full h-11 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
          placeholder="Search users…" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {loading ? (
        <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="h-16 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center"><Users className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto mb-2" /><p className="text-sm text-[hsl(var(--text-tertiary))]">No users found</p></div>
      ) : (
        <div className="space-y-2">
          {filtered.map(u => (
            <div key={u.id} className="card-soft rounded-2xl p-4 space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] grid place-items-center text-[hsl(var(--accent))] font-bold text-sm overflow-hidden">
                  {u.avatar_url ? <img src={u.avatar_url} className="w-full h-full object-cover" alt="" /> : (u.display_name?.charAt(0) || "?").toUpperCase()}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{u.display_name || "—"}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] truncate">{u.email}</p>
                  {u.phone && <p className="text-xs text-[hsl(var(--text-tertiary))]">{u.phone}</p>}
                </div>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full capitalize
                  ${u.role === "admin" ? "bg-purple-100 text-purple-700"
                  : u.role === "store_owner" ? "bg-blue-100 text-blue-700"
                  : u.role === "delivery_partner" ? "bg-orange-100 text-orange-700"
                  : "bg-slate-100 text-slate-600"}`}>
                  {u.role?.replace("_"," ")}
                </span>
              </div>
              <div>
                <p className="text-xs text-[hsl(var(--text-tertiary))] mb-1.5 flex items-center gap-1">
                  <ShieldCheck className="w-3 h-3" /> Change role
                </p>
                <div className="flex gap-1.5 flex-wrap">
                  {ROLES.map(r => (
                    <button key={r} onClick={() => changeRole(u.id, r)}
                      className={`press px-2.5 py-1 rounded-lg text-xs font-medium capitalize transition-colors
                        ${u.role === r ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))]"}`}>
                      {r.replace("_"," ")}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
