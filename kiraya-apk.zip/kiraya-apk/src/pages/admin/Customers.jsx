import React, { useState } from "react";
import DataTable from "@/components/admin/DataTable";
import { adminCustomers } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { Pill } from "@/components/customer/StatusBadge";
import { X } from "lucide-react";

const TONE = { Active: "accent", VIP: "warning", New: "neutral" };

export default function AdminCustomers() {
  const [detail, setDetail] = useState(null);
  const columns = [
    { key: "name", label: "Customer", render: (r) => <span className="font-medium">{r.name}</span>, sortable: true },
    { key: "phone", label: "Phone" },
    { key: "email", label: "Email" },
    { key: "orders", label: "Orders", sortable: true },
    { key: "spend", label: "Total Spend", render: (r) => formatPrice(r.spend), sortable: true },
    { key: "joined", label: "Joined", sortable: true },
    { key: "status", label: "Status", render: (r) => <Pill tone={TONE[r.status]}>{r.status}</Pill> },
  ];
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Customers</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{adminCustomers.length} customers</p>
      </div>
      <DataTable columns={columns} rows={adminCustomers} searchKeys={["name", "phone", "email"]} onRowClick={setDetail} />
      {detail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm card-soft rounded-3xl p-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center font-bold">{detail.name.charAt(0)}</div>
              <div>
                <h3 className="text-base font-semibold">{detail.name}</h3>
                <Pill tone={TONE[detail.status]}>{detail.status}</Pill>
              </div>
              <button onClick={() => setDetail(null)} className="press ml-auto w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Phone</span><span className="font-medium">{detail.phone}</span></div>
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Email</span><span className="font-medium">{detail.email}</span></div>
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Orders</span><span className="font-medium">{detail.orders}</span></div>
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Total spend</span><span className="font-bold">{formatPrice(detail.spend)}</span></div>
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Joined</span><span className="font-medium">{detail.joined}</span></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}