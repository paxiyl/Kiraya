import React, { useState, useEffect } from "react";
import { TrendingUp, ShoppingBag, Store, Users } from "lucide-react";
import { getAllOrders, getAllStoresAdminAdmin, getAllUsers } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";

export default function AdminAnalytics() {
  const [orders, setOrders] = useState([]);
  const [stores, setStores] = useState([]);
  const [users, setUsers]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([getAllOrders(), getAllStoresAdminAdmin(), getAllUsers()]).then(([o, s, u]) => {
      setOrders(o); setStores(s); setUsers(u); setLoading(false);
    });
  }, []);

  const delivered = orders.filter(o => o.status === "DELIVERED");
  const revenue   = delivered.reduce((s, o) => s + (o.total || 0), 0);

  // Group revenue by date (last 7 days)
  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const key = d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
    const rev = delivered.filter(o => new Date(o.created_at).toDateString() === d.toDateString()).reduce((s, o) => s + (o.total || 0), 0);
    return { label: key, rev };
  });
  const maxRev = Math.max(...last7.map(d => d.rev), 1);

  // Status breakdown
  const statuses = ["PENDING","PREPARING","READY","OUT_FOR_DELIVERY","DELIVERED","CANCELLED"];
  const breakdown = statuses.map(s => ({ s, count: orders.filter(o => o.status === s).length })).filter(x => x.count > 0);

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Analytics</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Real data from your platform</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[{ label: "Total revenue", value: formatPrice(revenue), icon: TrendingUp },
          { label: "Total orders", value: orders.length, icon: ShoppingBag },
          { label: "Active stores", value: stores.filter(s => s.approved).length, icon: Store },
          { label: "Registered users", value: users.length, icon: Users },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      {/* Revenue bar chart — last 7 days */}
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-4">Revenue — last 7 days</h3>
        <div className="flex items-end gap-2 h-28">
          {last7.map(({ label, rev }) => (
            <div key={label} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full rounded-t-lg bg-[hsl(var(--accent))] transition-all" style={{ height: `${(rev / maxRev) * 100}%`, minHeight: rev > 0 ? 4 : 0 }} />
              <p className="text-[9px] text-[hsl(var(--text-tertiary))] text-center leading-tight">{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Order status breakdown */}
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Order status breakdown</h3>
        {breakdown.length === 0 ? (
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No orders yet</p>
        ) : (
          <div className="space-y-2">
            {breakdown.map(({ s, count }) => (
              <div key={s} className="flex items-center gap-3">
                <span className="text-xs w-32 text-[hsl(var(--text-secondary))] capitalize">{s.replace(/_/g," ").toLowerCase()}</span>
                <div className="flex-1 h-2 bg-[hsl(var(--muted))] rounded-full overflow-hidden">
                  <div className="h-full bg-[hsl(var(--accent))] rounded-full" style={{ width: `${(count / orders.length) * 100}%` }} />
                </div>
                <span className="text-xs font-semibold w-6 text-right">{count}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
