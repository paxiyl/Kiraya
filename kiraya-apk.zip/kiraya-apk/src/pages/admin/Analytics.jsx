import React, { useState, useEffect } from "react";
import { TrendingUp, ShoppingBag, Store, Users, Star, Bike } from "lucide-react";
import { getAllOrders, getAllStoresAdmin, getAllUsers } from "@/lib/db";
import { supabase } from "@/lib/supabase";
import { formatPrice } from "@/lib/appConfig";

export default function AdminAnalytics() {
  const [orders, setOrders]   = useState([]);
  const [stores, setStores]   = useState([]);
  const [users, setUsers]     = useState([]);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      getAllOrders(),
      getAllStoresAdmin(),
      getAllUsers(),
      supabase.from("reviews").select("*").then(r => r.data || []),
    ]).then(([o, s, u, r]) => {
      setOrders(o); setStores(s); setUsers(u); setReviews(r); setLoading(false);
    });
  }, []);

  const delivered  = orders.filter(o => o.status === "DELIVERED");
  const cancelled  = orders.filter(o => o.status === "CANCELLED");
  const revenue    = delivered.reduce((s, o) => s + (o.total || 0), 0);
  const avgRating  = reviews.length
    ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1)
    : "—";
  const delivPartners = users.filter(u => u.role === "delivery_partner").length;

  const last7 = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const label = d.toLocaleDateString("en-IN", { day: "numeric", month: "short" });
    const rev = delivered
      .filter(o => new Date(o.created_at).toDateString() === d.toDateString())
      .reduce((s, o) => s + (o.total || 0), 0);
    return { label, rev };
  });
  const maxRev = Math.max(...last7.map(d => d.rev), 1);

  const storeRevenue = stores.map(s => ({
    ...s,
    revenue: delivered.filter(o => o.store_id === s.id).reduce((a, o) => a + (o.total || 0), 0),
    orderCount: delivered.filter(o => o.store_id === s.id).length,
  })).sort((a, b) => b.revenue - a.revenue).slice(0, 5);

  if (loading) return (
    <div className="py-20 text-center">
      <div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Analytics</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Real data · Hindaun City</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Total revenue",     value: formatPrice(revenue),  icon: TrendingUp, color: "text-green-600" },
          { label: "Total orders",      value: orders.length,         icon: ShoppingBag },
          { label: "Active stores",     value: stores.filter(s => s.approved).length, icon: Store },
          { label: "Customers",         value: users.filter(u => u.role === "customer").length, icon: Users },
          { label: "Delivery partners", value: delivPartners,         icon: Bike },
          { label: "Avg rating",        value: avgRating,             icon: Star, color: "text-yellow-500" },
        ].map(({ label, value, icon: Icon, color }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className={`w-5 h-5 mb-2 ${color || "text-[hsl(var(--accent))]"}`} />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-4">Revenue — last 7 days</h3>
        <div className="flex items-end gap-1.5 h-32">
          {last7.map(({ label, rev }) => (
            <div key={label} className="flex-1 flex flex-col items-center gap-1">
              {rev > 0 && <p className="text-[9px] text-[hsl(var(--text-tertiary))] font-medium">{formatPrice(rev)}</p>}
              <div
                className="w-full rounded-t-lg bg-[hsl(var(--accent))] transition-all"
                style={{ height: `${Math.max((rev / maxRev) * 90, rev > 0 ? 8 : 2)}%`, minHeight: 2 }}
              />
              <p className="text-[9px] text-[hsl(var(--text-tertiary))] text-center leading-tight">{label}</p>
            </div>
          ))}
        </div>
        {delivered.length === 0 && (
          <p className="text-center text-xs text-[hsl(var(--text-tertiary))] mt-2">No revenue data yet</p>
        )}
      </div>

      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Order breakdown</h3>
        <div className="space-y-2">
          {[
            { label: "Delivered",      count: delivered.length, color: "bg-green-500" },
            { label: "Pending",        count: orders.filter(o => o.status === "PENDING").length, color: "bg-orange-400" },
            { label: "Preparing",      count: orders.filter(o => o.status === "PREPARING").length, color: "bg-blue-400" },
            { label: "Out for del.",   count: orders.filter(o => o.status === "OUT_FOR_DELIVERY").length, color: "bg-purple-400" },
            { label: "Cancelled",      count: cancelled.length, color: "bg-red-400" },
          ].map(({ label, count, color }) => (
            <div key={label} className="flex items-center gap-3">
              <span className="text-xs w-24 text-[hsl(var(--text-secondary))]">{label}</span>
              <div className="flex-1 h-2 bg-[hsl(var(--muted))] rounded-full overflow-hidden">
                <div
                  className={`h-full ${color} rounded-full`}
                  style={{ width: orders.length ? `${(count / orders.length) * 100}%` : "0%" }}
                />
              </div>
              <span className="text-xs font-semibold w-6 text-right">{count}</span>
            </div>
          ))}
        </div>
      </div>

      {storeRevenue.length > 0 && (
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Top stores by revenue</h3>
          <div className="space-y-2">
            {storeRevenue.map((s, i) => (
              <div key={s.id} className="flex items-center gap-3">
                <span className="text-lg font-bold text-[hsl(var(--text-tertiary))] w-5">{i + 1}</span>
                {s.image_url
                  ? <img src={s.image_url} className="w-9 h-9 rounded-xl object-cover" alt="" />
                  : <div className="w-9 h-9 rounded-xl bg-[hsl(var(--muted))] grid place-items-center font-bold text-sm">{s.name?.charAt(0)}</div>
                }
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{s.name}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{s.orderCount} orders</p>
                </div>
                <p className="font-bold text-sm text-green-600">{formatPrice(s.revenue)}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
