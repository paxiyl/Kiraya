import React from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart, OrdersChart, CategoryPie } from "@/components/admin/Charts";
import { weeklyRevenue, categoryShare } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { TrendingUp, Percent, Bike, Ban } from "lucide-react";

export default function AdminAnalytics() {
  const totalRev = weeklyRevenue.reduce((s, d) => s + d.revenue, 0);
  const totalOrders = weeklyRevenue.reduce((s, d) => s + d.orders, 0);
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Analytics</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Performance insights</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Weekly Revenue" value={totalRev} prefix="₹" icon={TrendingUp} delta="+12.4%" up tone="accent" />
        <StatCard label="Weekly Orders" value={totalOrders} icon={Percent} delta="+6.1%" up tone="success" />
        <StatCard label="Avg Delivery Time" value={24} suffix=" min" icon={Bike} delta="-2 min" up tone="warning" />
        <StatCard label="Cancellation Rate" value={1.4} suffix="%" icon={Ban} delta="-0.3%" up tone="danger" />
      </div>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Revenue trend</h3>
          <RevenueChart data={weeklyRevenue} />
        </div>
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Category mix</h3>
          <CategoryPie data={categoryShare} />
        </div>
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Orders volume</h3>
        <OrdersChart data={weeklyRevenue} />
      </div>
    </div>
  );
}