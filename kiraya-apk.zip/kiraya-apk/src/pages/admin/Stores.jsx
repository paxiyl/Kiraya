import React, { useState } from "react";
import { stores } from "@/data/mockData";
import { Star, Clock, MapPin, MoreVertical, BadgePercent } from "lucide-react";
import { Pill } from "@/components/customer/StatusBadge";
import { formatPrice } from "@/lib/appConfig";

const STATUS = { active: "success", paused: "warning", pending: "neutral", suspended: "danger" };

export default function AdminStores() {
  const [status, setStatus] = useState("active");
  // attach mock admin status
  const list = stores.map((s, i) => ({ ...s, adminStatus: ["active", "paused", "pending", "suspended"][i % 4] }));
  const filtered = status === "all" ? list : list.filter((s) => s.adminStatus === status);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Stores</h1>
          <p className="text-sm text-[hsl(var(--text-tertiary))]">{list.length} total · manage status & commissions</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {[["all", "All"], ["active", "Active"], ["paused", "Paused"], ["pending", "Pending"], ["suspended", "Suspended"]].map(([id, l]) => (
          <button key={id} onClick={() => setStatus(id)}
            className={`press shrink-0 px-3.5 h-9 rounded-full text-sm font-medium ${status === id ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {l}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((s) => (
          <div key={s.id} className="card-soft rounded-2xl p-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-sm font-semibold">{s.name}</h3>
                <p className="text-xs text-[hsl(var(--text-tertiary))]">{s.tag}</p>
              </div>
              <button className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><MoreVertical className="w-4 h-4" /></button>
            </div>
            <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-secondary))]">
              <span className="inline-flex items-center gap-0.5 font-medium"><Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {s.rating}</span>
              <span className="inline-flex items-center gap-0.5"><Clock className="w-3 h-3" /> {s.eta}</span>
              <span className="inline-flex items-center gap-0.5"><MapPin className="w-3 h-3" /> {s.distance}</span>
            </div>
            <div className="flex items-center justify-between mt-3">
              <Pill tone={STATUS[s.adminStatus]}>{s.adminStatus}</Pill>
              <span className="text-xs text-[hsl(var(--text-tertiary))]">Commission 12%</span>
            </div>
            {s.offer && <div className="mt-3 flex items-center gap-1.5 text-xs text-[hsl(var(--accent))]"><BadgePercent className="w-3.5 h-3.5" /> {s.offer}</div>}
          </div>
        ))}
      </div>
    </div>
  );
}