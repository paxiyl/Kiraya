import React, { useState, useEffect } from "react";
import { Store, CheckCircle2, XCircle, Search } from "lucide-react";
import { getAllStores, approveStore, updateStore } from "@/lib/firestore";
import { useToast } from "@/components/ui/use-toast";

export default function AdminStores() {
  const { toast } = useToast();
  const [stores, setStores] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");

  const reload = () => getAllStores().then(s => { setStores(s); setLoading(false); });
  useEffect(() => { reload(); }, []);

  const approve = async (id) => {
    try { await approveStore(id); toast({ title: "Store approved" }); reload(); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const toggleOpen = async (store) => {
    try { await updateStore(store.id, { open: !store.open }); reload(); }
    catch (e) { toast({ title: "Error", description: e.message, variant: "destructive" }); }
  };

  const filtered = stores.filter(s => s.name?.toLowerCase().includes(search.toLowerCase()) || s.category?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Stores</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{stores.length} registered</p>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        <input className="w-full h-11 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
          placeholder="Search stores…" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {loading ? (
        <div className="space-y-2">{[1,2,3,4].map(i => <div key={i} className="h-20 rounded-2xl bg-[hsl(var(--muted))] animate-pulse" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="py-16 text-center"><Store className="w-10 h-10 text-[hsl(var(--text-tertiary))] mx-auto mb-2" /><p className="text-sm text-[hsl(var(--text-tertiary))]">No stores found</p></div>
      ) : (
        <div className="space-y-2">
          {filtered.map(store => (
            <div key={store.id} className="card-soft rounded-2xl p-4">
              <div className="flex items-center gap-3">
                {store.imageUrl
                  ? <img src={store.imageUrl} className="w-12 h-12 rounded-xl object-cover" alt="" />
                  : <div className="w-12 h-12 rounded-xl bg-[hsl(var(--muted))] grid place-items-center font-bold text-lg text-[hsl(var(--text-tertiary))]">{store.name?.charAt(0)}</div>
                }
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold">{store.name}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] capitalize">{store.category} · {store.address}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${store.approved ? "bg-green-100 text-green-700" : "bg-orange-100 text-orange-700"}`}>
                      {store.approved ? "Approved" : "Pending"}
                    </span>
                    <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${store.open ? "bg-blue-100 text-blue-700" : "bg-slate-100 text-slate-500"}`}>
                      {store.open ? "Open" : "Closed"}
                    </span>
                  </div>
                </div>
                <div className="flex flex-col gap-1">
                  {!store.approved && (
                    <button onClick={() => approve(store.id)} className="press h-8 px-3 rounded-lg bg-green-500 text-white text-xs font-semibold">Approve</button>
                  )}
                  <button onClick={() => toggleOpen(store)} className="press h-8 px-3 rounded-lg bg-[hsl(var(--muted))] text-xs font-medium">
                    {store.open ? "Close" : "Open"}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
