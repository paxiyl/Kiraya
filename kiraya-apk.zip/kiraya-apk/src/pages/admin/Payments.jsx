import React from "react";
import StatCard from "@/components/admin/StatCard";
import DataTable from "@/components/admin/DataTable";
import { adminOrders } from "@/data/panelData";
import { formatPrice } from "@/lib/appConfig";
import { Wallet, TrendingUp, RefreshCw, CreditCard } from "lucide-react";
import { Pill } from "@/components/customer/StatusBadge";

export default function AdminPayments() {
  const txns = adminOrders.map((o) => ({ ...o, txnId: "TXN" + o.id.replace("ORD-", ""), amount: o.amount, method: o.payment, status: o.status === "CANCELLED" ? "Refunded" : o.payment === "COD" ? "COD" : "Paid" }));
  const cols = [
    { key: "txnId", label: "Txn ID", render: (r) => <span className="font-medium">{r.txnId}</span> },
    { key: "customer", label: "Customer" },
    { key: "store", label: "Store" },
    { key: "method", label: "Method" },
    { key: "amount", label: "Amount", render: (r) => formatPrice(r.amount), sortable: true },
    { key: "status", label: "Status", render: (r) => <Pill tone={r.status === "Paid" ? "success" : r.status === "Refunded" ? "danger" : "neutral"}>{r.status}</Pill> },
  ];
  const total = txns.reduce((s, t) => s + t.amount, 0);
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Payments</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Transactions & settlement</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Gross Volume" value={total} prefix="₹" icon={Wallet} tone="accent" />
        <StatCard label="Net Revenue" value={Math.round(total * 0.12)} prefix="₹" icon={TrendingUp} tone="success" />
        <StatCard label="Refunds" value={2} icon={RefreshCw} tone="danger" />
        <StatCard label="COD Orders" value={txns.filter(t => t.method === "COD").length} icon={CreditCard} tone="warning" />
      </div>
      <DataTable columns={cols} rows={txns} searchKeys={["txnId", "customer", "store"]} />
    </div>
  );
}