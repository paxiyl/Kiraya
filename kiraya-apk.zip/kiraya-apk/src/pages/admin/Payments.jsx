import React, { useState, useEffect } from "react";
import { Wallet, TrendingUp, Search } from "lucide-react";
import { getAllOrders } from "@/lib/db";
import { formatPrice } from "@/lib/appConfig";

export default function AdminPayments() {
  const [orders, setOrders]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch]   = useState("");

  useEffect(() => {
    getAllOrders().then(o => { setOrders(o.filter(x => x.status === "DELIVERED")); setLoading(false); });
  }, []);

  const total = orders.reduce((s, o) => s + (o.total || 0), 0);
  const today = orders.filter(o => {
    const d = o.delivered_at ? new Date(o.delivered_at) : null;
    return d && new Date().toDateString() === d.toDateString();
  }).reduce((s, o) => s + (o.total || 0), 0);

  const filtered = search
    ? orders.filter(o => o.customer_name?.toLowerCase().includes(search.toLowerCase()) || o.id.includes(search))
    : orders;

  if (loading) return <div className="py-20 text-center"><div className="w-8 h-8 border-4 border-slate-200 border-t-[hsl(var(--accent))] rounded-full animate-spin mx-auto" /></div>;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Payments</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Completed transactions</p>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {[
          { label: "Total collected", value: formatPrice(total), icon: Wallet },
          { label: "Today",           value: formatPrice(today), icon: TrendingUp },
          { label: "Transactions",    value: orders.length,      icon: Wallet },
        ].map(({ label, value, icon: Icon }) => (
          <div key={label} className="card-soft rounded-2xl p-4">
            <Icon className="w-5 h-5 text-[hsl(var(--accent))] mb-2" />
            <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
            <p className="text-lg font-bold mt-0.5">{value}</p>
          </div>
        ))}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
        <input className="w-full h-11 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
          placeholder="Search transactions…" value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="py-12 text-center"><p className="text-sm text-[hsl(var(--text-tertiary))]">No transactions yet</p></div>
        ) : filtered.slice(0, 50).map(o => (
          <div key={o.id} className="card-soft rounded-2xl p-3 flex items-center justify-between">
            <div>
              <p className="text-xs font-mono text-[hsl(var(--text-tertiary))]">#{o.id.slice(-6).toUpperCase()}</p>
              <p className="text-sm font-medium">{o.customer_name || "Customer"}</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))] capitalize">{o.payment_method}</p>
            </div>
            <p className="font-semibold text-green-600">{formatPrice(o.total)}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
