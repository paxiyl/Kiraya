import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/lib/AuthContext";

/** Unread notification count with realtime updates (moved here from the old 6-tab BottomNav). */
export default function useUnreadNotifications() {
  const { user } = useAuth();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    const load = () => supabase.from("notifications").select("id", { count: "exact" })
      .eq("user_id", user.id).eq("read", false)
      .then(({ count }) => setUnread(count || 0));
    load();
    const ch = supabase.channel(`notif-badge-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications", filter: `user_id=eq.${user.id}` }, load)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [user]);

  return unread;
}
