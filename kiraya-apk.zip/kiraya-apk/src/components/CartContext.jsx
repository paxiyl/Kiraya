import React, { createContext, useContext, useMemo, useState, useCallback } from "react";
import { products as allProducts } from "@/data/mockData";

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

const PLATFORM_FEE = 5;
const TAX_RATE = 0.05;

export function CartProvider({ children }) {
  // items: { [productId]: qty }
  const [items, setItems] = useState({});
  // grouped by store: { [storeId]: { [productId]: qty } }
  const [coupon, setCoupon] = useState(null);

  const add = useCallback((productId, qty = 1) => {
    setItems((prev) => ({ ...prev, [productId]: (prev[productId] || 0) + qty }));
  }, []);
  const setQty = useCallback((productId, qty) => {
    setItems((prev) => {
      const next = { ...prev };
      if (qty <= 0) delete next[productId];
      else next[productId] = qty;
      return next;
    });
  }, []);
  const remove = useCallback((productId) => {
    setItems((prev) => {
      const next = { ...prev };
      delete next[productId];
      return next;
    });
  }, []);
  const clear = useCallback(() => { setItems({}); setCoupon(null); }, []);

  const qtyOf = useCallback((id) => items[id] || 0, [items]);

  const detailed = useMemo(() => {
    const rows = Object.entries(items)
      .map(([id, qty]) => {
        const product = allProducts.find((p) => p.id === id);
        return product ? { product, qty, lineTotal: product.price * qty } : null;
      })
      .filter(Boolean);
    // group by store
    const byStore = rows.reduce((acc, r) => {
      (acc[r.product.storeId] ||= []).push(r);
      return acc;
    }, {});
    return { rows, byStore };
  }, [items]);

  const subtotal = useMemo(
    () => detailed.rows.reduce((s, r) => s + r.lineTotal, 0),
    [detailed]
  );
  const deliveryFee = useMemo(() => {
    if (subtotal === 0) return 0;
    const storeFees = Object.keys(detailed.byStore).map((sid) => {
      const storeRows = detailed.byStore[sid];
      const storeSub = storeRows.reduce((s, r) => s + r.lineTotal, 0);
      // simple mock: free over 299 else 29
      return storeSub >= 299 ? 0 : 29;
    });
    return storeFees.reduce((s, f) => s + f, 0);
  }, [subtotal, detailed]);

  const discount = useMemo(() => {
    if (!coupon) return 0;
    if (subtotal < coupon.min) return 0;
    if (coupon.type === "flat") return coupon.value;
    if (coupon.type === "pct") return Math.min(Math.round((subtotal * coupon.value) / 100), coupon.max || Infinity);
    if (coupon.type === "delivery") return deliveryFee;
    return 0;
  }, [coupon, subtotal, deliveryFee]);

  const taxes = useMemo(() => Math.round((subtotal - discount) * TAX_RATE), [subtotal, discount]);
  const total = Math.max(0, subtotal + deliveryFee + PLATFORM_FEE + taxes - (coupon?.type === "delivery" ? 0 : discount));
  const count = Object.values(items).reduce((s, q) => s + q, 0);

  const value = {
    items, add, setQty, remove, clear, qtyOf,
    rows: detailed.rows, byStore: detailed.byStore,
    subtotal, deliveryFee, discount, taxes, platformFee: PLATFORM_FEE, total, count,
    coupon, applyCoupon: setCoupon, removeCoupon: () => setCoupon(null),
  };
  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}