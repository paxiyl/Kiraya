import React from "react";
import { Link } from "react-router-dom";

export default function CategoryStrip({ categories, to = "/explore" }) {
  return (
    <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4 pb-1">
      {categories.map((c) => {
        const Icon = c.icon;
        return (
          <Link
            key={c.id}
            to={`${to}?cat=${c.id}`}
            className="press shrink-0 w-[72px] flex flex-col items-center gap-2 text-center"
          >
            <div
              className="w-16 h-16 rounded-2xl grid place-items-center"
              style={{ background: `hsl(${c.tint} / 0.14)`, color: `hsl(${c.tint})` }}
            >
              <Icon className="w-7 h-7" strokeWidth={1.5} />
            </div>
            <span className="text-[11px] font-medium text-[hsl(var(--text-secondary))] leading-tight line-clamp-2">
              {c.name}
            </span>
          </Link>
        );
      })}
    </div>
  );
}