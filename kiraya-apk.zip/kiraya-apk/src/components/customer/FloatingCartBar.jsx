import React from "react";
import { Link } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { ChevronRight } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { formatPrice } from "@/lib/appConfig";
import { springSoft } from "@/lib/motion";
import SmartImage from "@/components/customer/SmartImage";
import AnimatedNumber from "@/components/customer/AnimatedNumber";

/** Persistent cart summary that sits just above the bottom navigation. */
export default function FloatingCartBar({ visible }) {
  const { count, subtotal, rows, storeName } = useCart();
  const show = visible && count > 0;
  const thumbs = rows.slice(0, 3);

  return (
    <AnimatePresence>
      {show && (
        <motion.div
          key="cart-bar"
          initial={{ y: 96, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          exit={{ y: 96, opacity: 0 }}
          transition={springSoft}
          className="pointer-events-none fixed inset-x-0 z-40 px-3"
          style={{ bottom: "calc(var(--nav-h) + var(--safe-b) + 8px)" }}
        >
          <Link
            to="/cart"
            className="press pointer-events-auto mx-auto flex h-[var(--cartbar-h)] max-w-md items-center gap-3 rounded-card bg-brand pl-2 pr-3 text-white shadow-float"
          >
            <div className="flex shrink-0 pl-1">
              {thumbs.map(({ product }, i) => (
                <SmartImage
                  key={product.id}
                  src={product.image_url || product.imageUrl}
                  alt=""
                  className={`h-10 w-10 rounded-[10px] ring-2 ring-brand ${i > 0 ? "-ml-4" : ""}`}
                />
              ))}
            </div>
            <div className="min-w-0 flex-1 leading-tight">
              <p className="flex items-center gap-1 text-[15px] font-bold">
                <AnimatedNumber value={count} /> <span>{count === 1 ? "item" : "items"}</span>
                <span className="opacity-60">·</span>
                <AnimatedNumber value={subtotal} format={formatPrice} />
              </p>
              {storeName && <p className="truncate text-caption text-white/80">From {storeName}</p>}
            </div>
            <span className="flex shrink-0 items-center text-body font-semibold">
              View cart <ChevronRight size={18} strokeWidth={2.5} />
            </span>
          </Link>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
