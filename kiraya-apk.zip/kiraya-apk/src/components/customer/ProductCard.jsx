import React from "react";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatPrice } from "@/lib/appConfig";
import { useCart } from "@/context/CartContext";
import { toCartProduct, discountPct } from "@/lib/cartProduct";
import SmartImage from "@/components/customer/SmartImage";
import AddToCartButton from "@/components/customer/AddToCartButton";

/**
 * product: a `products` row (id, name, price, mrp, image_url, category, description, store_id)
 * store:   its `stores` row (name, eta, open, delivery_fee); optional
 * variant: "rail" (fixed width, horizontal lists) | "grid" (fills its cell) | "row" (menu list)
 */
export default function ProductCard({ product, store, variant = "grid", showStore = false, className }) {
  const { requestAdd, setQty, qtyOf } = useCart();
  const qty = qtyOf(product.id);
  const pct = discountPct(product.price, product.mrp);
  const closed = store ? store.open === false : false;

  const onAdd = () => requestAdd(toCartProduct(product, store));
  const onInc = () => setQty(product.id, qty + 1);
  const onDec = () => setQty(product.id, qty - 1);

  const price = (
    <div className="flex flex-wrap items-baseline gap-x-1.5">
      <span className="text-card font-extrabold tabular text-ink">{formatPrice(product.price)}</span>
      {pct > 0 && <span className="text-caption tabular text-ink-3 line-through">{formatPrice(product.mrp)}</span>}
    </div>
  );

  if (variant === "row") {
    return (
      <div className={cn("flex gap-4 py-4", className)}>
        <div className="min-w-0 flex-1">
          <h3 className="text-card font-semibold text-ink line-clamp-2">{product.name}</h3>
          <div className="mt-1.5">{price}</div>
          {pct > 0 && <p className="mt-0.5 text-caption font-bold text-offer-ink">{pct}% off</p>}
          {product.description && (
            <p className="mt-2 text-secondary text-ink-3 line-clamp-2">{product.description}</p>
          )}
        </div>
        <div className="relative w-[104px] shrink-0 pb-4">
          <SmartImage
            src={product.image_url}
            alt={product.name}
            category={product.category}
            className="aspect-square w-full rounded-card border border-line"
          />
          <div className="absolute inset-x-0 bottom-0 flex justify-center">
            <AddToCartButton size="sm" qty={qty} onAdd={onAdd} onIncrement={onInc} onDecrement={onDec} disabled={closed} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className={cn(variant === "rail" ? "w-[148px] shrink-0" : "w-full min-w-0", className)}>
      <div className="relative">
        <SmartImage
          src={product.image_url}
          alt={product.name}
          category={product.category}
          className="aspect-square w-full rounded-card border border-line bg-surface"
        />
        {pct > 0 && (
          <span className="absolute left-1.5 top-1.5 rounded-md bg-offer px-1.5 py-[3px] text-[10px] font-extrabold leading-none tabular text-ink">
            {pct}% OFF
          </span>
        )}
        <div className="absolute -bottom-4 right-1.5">
          <AddToCartButton size="sm" qty={qty} onAdd={onAdd} onIncrement={onInc} onDecrement={onDec} disabled={closed} />
        </div>
      </div>

      <div className="pt-5">
        {store?.eta && (
          <p className="flex items-center gap-1 truncate text-meta font-medium text-ink-2">
            <Clock size={12} strokeWidth={2.25} className="shrink-0" />
            <span className="truncate">{store.eta}</span>
          </p>
        )}
        <h3 className="mt-1 min-h-[36px] text-[13px] font-semibold leading-[18px] text-ink line-clamp-2">{product.name}</h3>
        {showStore && store?.name && <p className="truncate text-meta text-ink-3">{store.name}</p>}
        <div className="mt-1.5">{price}</div>
      </div>
    </div>
  );
}
