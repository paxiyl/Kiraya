import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * Horizontal category rail.
 * - Link mode (default): each tile links to `${to}?cat=<id>`.
 * - Select mode: pass `onSelect` (and `active`) to use it as a filter.
 */
export default function CategoryStrip({ categories, active = null, onSelect, to = "/explore", className }) {
  return (
    <div className={cn("-mx-4 flex gap-1 overflow-x-auto px-3 pb-1 no-scrollbar", className)} role={onSelect ? "tablist" : undefined}>
      {categories.map((c) => {
        const Icon = c.icon;
        const isActive = active === c.id;
        const tile = (
          <>
            <span
              className={cn(
                "relative grid h-16 w-16 place-items-center rounded-card transition-transform",
                isActive && "ring-2 ring-brand ring-offset-2 ring-offset-canvas"
              )}
              style={{ background: `hsl(${c.tint} / 0.12)`, color: `hsl(${c.tint})` }}
            >
              <Icon size={28} strokeWidth={1.6} />
            </span>
            <span
              className={cn(
                "mt-1.5 line-clamp-2 text-center text-caption leading-[15px]",
                isActive ? "font-bold text-ink" : "font-medium text-ink-2"
              )}
            >
              {c.name}
            </span>
          </>
        );
        const cls = "press flex w-[76px] shrink-0 flex-col items-center rounded-control py-1";

        return onSelect ? (
          <motion.button
            key={c.id}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => onSelect(c.id)}
            className={cls}
            whileTap={{ scale: 0.95 }}
          >
            {tile}
          </motion.button>
        ) : (
          <Link key={c.id} to={`${to}?cat=${c.id}`} className={cls}>
            {tile}
          </Link>
        );
      })}
    </div>
  );
}
