import React from "react";
import { Link } from "react-router-dom";
import { AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const TONE = {
  neutral: "bg-surface-2 text-ink-2",
  brand: "bg-brand-soft text-brand",
  danger: "bg-danger-soft text-danger",
};

/** icon + short title + helpful description + optional CTA ({ label, to } or { label, onClick }). */
export default function EmptyState({ icon: Icon, title, description, action, tone = "neutral", className }) {
  const btn = "press inline-flex h-11 items-center justify-center rounded-control px-5 text-body font-semibold";
  return (
    <div className={cn("flex flex-col items-center px-6 py-14 text-center", className)}>
      {Icon && (
        <div className={cn("grid h-14 w-14 place-items-center rounded-full", TONE[tone] || TONE.neutral)}>
          <Icon size={26} strokeWidth={1.75} />
        </div>
      )}
      <h3 className="mt-4 text-card font-bold text-ink">{title}</h3>
      {description && <p className="mt-1 max-w-[280px] text-secondary text-ink-3">{description}</p>}
      {action && (
        <div className="mt-5">
          {action.to ? (
            <Link to={action.to} className={cn(btn, "bg-brand text-white")}>{action.label}</Link>
          ) : (
            <button type="button" onClick={action.onClick} className={cn(btn, action.variant === "outline" ? "border border-line bg-surface text-ink" : "bg-brand text-white")}>
              {action.label}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

/** Friendly error. Raw backend messages are never the main UI. */
export function ErrorState({ onRetry, title = "Something went wrong", description = "We couldn't load this right now.", className }) {
  return (
    <EmptyState
      icon={AlertCircle}
      tone="danger"
      title={title}
      description={description}
      action={onRetry ? { label: "Retry", onClick: onRetry, variant: "outline" } : undefined}
      className={className}
    />
  );
}
