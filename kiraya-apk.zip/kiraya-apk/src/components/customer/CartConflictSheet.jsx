import React, { useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ShoppingBag } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { springSoft } from "@/lib/motion";
import { hapticTap } from "@/lib/haptics";

/** Asks before replacing a cart that holds items from another shop. */
export default function CartConflictSheet() {
  const { conflict, resolveConflict, storeName } = useCart();

  useEffect(() => {
    if (!conflict) return;
    const onKey = (e) => e.key === "Escape" && resolveConflict(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [conflict, resolveConflict]);

  const nextStore = conflict?.product?.storeName;

  return (
    <AnimatePresence>
      {conflict && (
        <div key="cart-conflict" className="fixed inset-0 z-50" role="dialog" aria-modal="true" aria-labelledby="cart-conflict-title">
          <motion.div
            className="absolute inset-0 bg-black/40"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => resolveConflict(false)}
          />
          <motion.div
            className="absolute inset-x-0 bottom-0 mx-auto max-w-md rounded-t-feature bg-surface px-5 pt-3"
            style={{ paddingBottom: "calc(var(--safe-b) + 20px)" }}
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={springSoft}
          >
            <div className="mx-auto h-1 w-10 rounded-full bg-line" />
            <div className="mt-5 grid h-12 w-12 place-items-center rounded-full bg-offer-soft text-offer-ink">
              <ShoppingBag size={22} strokeWidth={2} />
            </div>
            <h2 id="cart-conflict-title" className="mt-4 text-section font-bold text-ink">Start a new cart?</h2>
            <p className="mt-1.5 text-body text-ink-2">
              Your cart has items from {storeName || "another shop"}. Each order comes from one shop, so adding this
              {nextStore ? ` item from ${nextStore}` : " item"} will clear your current cart.
            </p>
            <div className="mt-6 grid grid-cols-2 gap-3">
              <button type="button" onClick={() => resolveConflict(false)}
                className="press h-12 rounded-control border border-line bg-surface text-body font-semibold text-ink">
                Keep cart
              </button>
              <button type="button" onClick={() => { hapticTap(); resolveConflict(true); }}
                className="press h-12 rounded-control bg-brand text-body font-semibold text-white">
                Start new cart
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
