import { createPortal } from "react-dom";

/** Renders fixed-position UI into <body> so no transformed ancestor can offset it. */
export default function FixedLayer({ children }) {
  if (typeof document === "undefined") return null;
  return createPortal(children, document.body);
}
