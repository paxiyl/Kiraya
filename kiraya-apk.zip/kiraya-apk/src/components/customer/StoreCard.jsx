import React from "react";
import { Link } from "react-router-dom";
import { Clock, IndianRupee } from "lucide-react";

export default function StoreCard({ store }) {
  return (
    <Link to={`/store/${store.id}`} className="press block card-soft rounded-2xl overflow-hidden group">
      <div className="relative w-full h-36 bg-gradient-to-br from-[hsl(152_58%_38%)] to-[hsl(172_60%_30%)]">
        {store.image_url
          ? <img src={store.image_url} alt={store.name} className="w-full h-full object-cover" />
          : <div className="w-full h-full flex items-center justify-center text-4xl font-bold text-white/30">{store.name?.charAt(0)}</div>
        }
        {!store.open && (
          <div className="absolute inset-0 bg-black/50 flex items-end p-3">
            <span className="text-white text-xs font-medium">Currently closed</span>
          </div>
        )}
      </div>
      <div className="p-3">
        <h3 className="text-sm font-semibold line-clamp-1">{store.name}</h3>
        {store.description && <p className="text-xs text-[hsl(var(--text-tertiary))] line-clamp-1 mt-0.5">{store.description}</p>}
        <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-secondary))]">
          {store.eta && <span className="flex items-center gap-0.5"><Clock className="w-3 h-3" /> {store.eta}</span>}
          <span className="flex items-center gap-0.5">
            <IndianRupee className="w-3 h-3" />
            {store.delivery_fee > 0 ? `${store.delivery_fee} delivery` : "Free delivery"}
          </span>
          <span className="capitalize text-[hsl(var(--text-tertiary))]">{store.category}</span>
        </div>
      </div>
    </Link>
  );
}
