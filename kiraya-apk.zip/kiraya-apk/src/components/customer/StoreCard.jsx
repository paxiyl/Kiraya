import React from "react";
import { Link } from "react-router-dom";
import { Clock } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatPrice } from "@/lib/appConfig";
import SmartImage, { categoryLabel } from "@/components/customer/SmartImage";

function DeliveryFee({ fee }) {
  return Number(fee) > 0
    ? <span>{formatPrice(fee)} delivery</span>
    : <span className="font-semibold text-brand">Free delivery</span>;
}

/**
 * store: a `stores` row (id, name, description, category, image_url, eta, delivery_fee, open)
 * variant: "row" (dense list, default) | "feature" (image-led, for horizontal rails)
 */
export default function StoreCard({ store, variant = "row", className }) {
  const closed = store.open === false;
  const label = categoryLabel(store.category);

  if (variant === "feature") {
    return (
      <Link to={`/store/${store.id}`} className={cn("press block w-[264px] shrink-0", className)}>
        <div className="relative">
          <SmartImage
            src={store.image_url}
            alt={store.name}
            category={store.category}
            fallbackSize={36}
            className={cn("aspect-[16/10] w-full rounded-feature", closed && "grayscale")}
          />
          {closed && (
            <span className="absolute left-2.5 top-2.5 rounded-md bg-ink/80 px-2 py-1 text-meta font-semibold text-white">
              Closed now
            </span>
          )}
        </div>
        <div className="px-0.5 pt-2.5">
          <h3 className="truncate text-card font-bold text-ink">{store.name}</h3>
          <p className="mt-0.5 flex items-center gap-2 text-caption text-ink-2">
            {store.eta && (
              <span className="flex items-center gap-1 font-medium">
                <Clock size={13} strokeWidth={2.25} /> {store.eta}
              </span>
            )}
            <DeliveryFee fee={store.delivery_fee} />
          </p>
        </div>
      </Link>
    );
  }

  return (
    <Link to={`/store/${store.id}`} className={cn("press flex items-center gap-3.5 py-3", className)}>
      <SmartImage
        src={store.image_url}
        alt={store.name}
        category={store.category}
        className={cn("h-[76px] w-[76px] shrink-0 rounded-card", closed && "grayscale")}
      />
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <h3 className="truncate text-card font-bold text-ink">{store.name}</h3>
          {closed && (
            <span className="shrink-0 rounded-md bg-danger-soft px-1.5 py-0.5 text-meta font-semibold text-danger">Closed</span>
          )}
        </div>
        <p className="mt-0.5 truncate text-secondary text-ink-3">
          {store.description || label || "Local shop"}
        </p>
        <p className="mt-1.5 flex items-center gap-2.5 text-caption text-ink-2">
          {store.eta && (
            <span className="flex items-center gap-1 font-semibold text-ink">
              <Clock size={13} strokeWidth={2.25} /> {store.eta}
            </span>
          )}
          <DeliveryFee fee={store.delivery_fee} />
        </p>
      </div>
    </Link>
  );
}
