import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { Home, Search, ShoppingCart, ClipboardList, User, Bell } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { useAuth } from "@/lib/AuthContext";
import { supabase } from "@/lib/supabase";

export default function BottomNav() {
  const { count }  = useCart();
  const { user }   = useAuth();
  const [unread, setUnread] = useState(0);

  useEffect(() => {
    if (!user) return;
    const load = () => supabase.from("notifications").select("id", { count:"exact" })
      .eq("user_id", user.id).eq("read", false)
      .then(({ count:c }) => setUnread(c || 0));
    load();
    const ch = supabase.channel(`notif-badge-${user.id}`)
      .on("postgres_changes", { event:"*", schema:"public", table:"notifications", filter:`user_id=eq.${user.id}` }, load)
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [user]);

  const tabs = [
    { to:"/home",          icon:Home,          label:"Home" },
    { to:"/explore",       icon:Search,        label:"Explore" },
    { to:"/cart",          icon:ShoppingCart,  label:"Cart",   badge:count },
    { to:"/orders",        icon:ClipboardList, label:"Orders" },
    { to:"/notifications", icon:Bell,          label:"Alerts",  badge:unread },
    { to:"/profile",       icon:User,          label:"Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-30 bg-background/80 backdrop-blur-xl border-t border-[hsl(var(--border))] px-2 py-1 pb-safe">
      <div className="flex justify-around max-w-md mx-auto">
        {tabs.map(({ to, icon:Icon, label, badge }) => (
          <NavLink key={to} to={to} className={({ isActive }) =>
            `flex flex-col items-center gap-0.5 px-2 py-1.5 rounded-xl transition-colors relative
            ${isActive ? "text-[hsl(var(--accent))]" : "text-[hsl(var(--text-tertiary))]"}`}>
            <div className="relative">
              <Icon className="w-5 h-5" />
              {badge > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-bold grid place-items-center">
                  {badge > 9 ? "9+" : badge}
                </span>
              )}
            </div>
            <span className="text-[10px] font-medium">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
