import React from "react";
import { NavLink } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";
import { Home, Search, ClipboardList, ShoppingBag, User } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { spring } from "@/lib/motion";
import { cn } from "@/lib/utils";

const TABS = [
  { to: "/home", icon: Home, label: "Home" },
  { to: "/explore", icon: Search, label: "Explore" },
  { to: "/orders", icon: ClipboardList, label: "Orders" },
  { to: "/cart", icon: ShoppingBag, label: "Cart", cart: true },
  { to: "/profile", icon: User, label: "Profile" },
];

export default function BottomNav() {
  const { count } = useCart();

  return (
    <nav
      className="fixed inset-x-0 bottom-0 z-30 border-t border-line bg-surface"
      style={{ paddingBottom: "var(--safe-b)" }}
      aria-label="Main"
    >
      <div className="mx-auto flex h-[var(--nav-h)] max-w-md items-stretch">
        {TABS.map(({ to, icon: Icon, label, cart }) => (
          <NavLink
            key={to}
            to={to}
            end={to !== "/orders"}
            className="flex min-w-0 flex-1 flex-col items-center justify-center gap-1"
          >
            {({ isActive }) => (
              <>
                <span className="relative grid h-8 w-14 place-items-center">
                  {isActive && (
                    <motion.span
                      layoutId="nav-active-pill"
                      className="absolute inset-0 rounded-full bg-brand-soft"
                      transition={spring}
                    />
                  )}
                  <Icon
                    size={21}
                    strokeWidth={isActive ? 2.4 : 1.9}
                    className={cn("relative", isActive ? "text-brand" : "text-ink-3")}
                  />
                  {cart && (
                    <AnimatePresence>
                      {count > 0 && (
                        <motion.span
                          key={count}
                          initial={{ scale: 0.4, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.4, opacity: 0 }}
                          transition={spring}
                          className="absolute -top-0.5 right-1.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-danger px-1 text-[10px] font-bold tabular text-white ring-2 ring-surface"
                        >
                          {count > 99 ? "99+" : count}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  )}
                </span>
                <span className={cn("text-meta", isActive ? "font-bold text-ink" : "font-medium text-ink-3")}>
                  {label}
                </span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
