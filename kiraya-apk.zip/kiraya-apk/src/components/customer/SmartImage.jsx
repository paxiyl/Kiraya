import React, { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { categories } from "@/data/mockData";

const CATEGORY_BY_ID = Object.fromEntries(categories.map((c) => [c.id, c]));

/** Tinted panel with the category's icon: the fallback for missing photos. */
export function CategoryFallback({ category, size = 28, className }) {
  const c = CATEGORY_BY_ID[category] || CATEGORY_BY_ID.more;
  const Icon = c.icon;
  return (
    <div
      className={cn("grid h-full w-full place-items-center", className)}
      style={{ background: `hsl(${c.tint} / 0.10)`, color: `hsl(${c.tint})` }}
      aria-hidden="true"
    >
      <Icon size={size} strokeWidth={1.6} />
    </div>
  );
}

export const categoryLabel = (id) => CATEGORY_BY_ID[id]?.name || null;

/**
 * Image with lazy loading, a shimmer while loading, a fade-in on load and a
 * designed fallback on error/missing src. Size it via `className`.
 */
export default function SmartImage({ src, alt = "", category, className, imgClassName, fit = "cover", fallbackSize }) {
  const [state, setState] = useState(src ? "loading" : "error");
  useEffect(() => { setState(src ? "loading" : "error"); }, [src]);

  return (
    <div className={cn("relative overflow-hidden bg-surface-2", className)}>
      {src && state !== "error" && (
        <img
          key={src}
          src={src}
          alt={alt}
          loading="lazy"
          decoding="async"
          draggable={false}
          onLoad={() => setState("loaded")}
          onError={() => setState("error")}
          className={cn(
            "absolute inset-0 h-full w-full transition-opacity duration-300",
            fit === "contain" ? "object-contain" : "object-cover",
            state === "loaded" ? "opacity-100" : "opacity-0",
            imgClassName
          )}
        />
      )}
      {state === "loading" && <div className="shimmer absolute inset-0 rounded-none" />}
      {state === "error" && (
        <div className="absolute inset-0">
          <CategoryFallback category={category} size={fallbackSize} />
        </div>
      )}
    </div>
  );
}
