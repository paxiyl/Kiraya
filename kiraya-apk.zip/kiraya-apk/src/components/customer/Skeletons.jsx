import React from "react";
import { cn } from "@/lib/utils";

/** Base block; the shimmer comes from the `.shimmer` class in index.css. */
export const Bone = ({ className }) => <div className={cn("shimmer", className)} aria-hidden="true" />;

export function ProductSkeleton({ variant = "grid" }) {
  if (variant === "row") {
    return (
      <div className="flex gap-4 py-4">
        <div className="flex-1 space-y-2"><Bone className="h-4 w-3/4" /><Bone className="h-4 w-1/3" /><Bone className="h-3 w-full" /></div>
        <Bone className="h-[104px] w-[104px] rounded-card" />
      </div>
    );
  }
  return (
    <div className={variant === "rail" ? "w-[148px] shrink-0" : "w-full"}>
      <Bone className="aspect-square w-full rounded-card" />
      <Bone className="mt-5 h-3 w-1/2" />
      <Bone className="mt-2 h-3.5 w-11/12" />
      <Bone className="mt-2 h-4 w-2/5" />
    </div>
  );
}

export function ProductRailSkeleton({ count = 3 }) {
  return (
    <div className="-mx-4 flex gap-3 overflow-hidden px-4">
      {Array.from({ length: count }, (_, i) => <ProductSkeleton key={i} variant="rail" />)}
    </div>
  );
}

export function StoreSkeleton() {
  return (
    <div className="flex items-center gap-3.5 py-3">
      <Bone className="h-[76px] w-[76px] rounded-card" />
      <div className="flex-1 space-y-2"><Bone className="h-4 w-2/3" /><Bone className="h-3 w-1/2" /><Bone className="h-3 w-2/5" /></div>
    </div>
  );
}

export function HomeSkeleton() {
  return (
    <div className="space-y-7" aria-busy="true" aria-label="Loading">
      <Bone className="h-[152px] w-full rounded-feature" />
      <div className="-mx-4 flex gap-1 overflow-hidden px-3">
        {Array.from({ length: 5 }, (_, i) => (
          <div key={i} className="flex w-[76px] shrink-0 flex-col items-center gap-2 py-1">
            <Bone className="h-16 w-16 rounded-card" /><Bone className="h-3 w-12" />
          </div>
        ))}
      </div>
      <div><Bone className="mb-4 h-5 w-40" /><ProductRailSkeleton /></div>
      <div><Bone className="mb-2 h-5 w-36" />{[0, 1, 2].map((i) => <StoreSkeleton key={i} />)}</div>
    </div>
  );
}

export function OrderSkeleton() {
  return (
    <div className="flex items-center gap-3 py-4">
      <Bone className="h-12 w-12 rounded-control" />
      <div className="flex-1 space-y-2"><Bone className="h-4 w-1/2" /><Bone className="h-3 w-1/3" /></div>
      <Bone className="h-6 w-20 rounded-full" />
    </div>
  );
}

export function DashboardSkeleton() {
  return (
    <div className="space-y-6" aria-busy="true" aria-label="Loading">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {Array.from({ length: 4 }, (_, i) => <Bone key={i} className="h-24 rounded-card" />)}
      </div>
      <Bone className="h-56 w-full rounded-card" />
      <div>{[0, 1, 2].map((i) => <OrderSkeleton key={i} />)}</div>
    </div>
  );
}
