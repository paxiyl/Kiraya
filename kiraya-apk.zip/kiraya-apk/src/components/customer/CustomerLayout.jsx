import React from "react";
import { Outlet, useLocation } from "react-router-dom";
import BottomNav from "@/components/customer/BottomNav";
import FloatingCartBar from "@/components/customer/FloatingCartBar";
import CartConflictSheet from "@/components/customer/CartConflictSheet";
import { CartProvider, useCart } from "@/context/CartContext";

// The nested CartProvider is intentional: it resets the cart when the customer
// area unmounts (e.g. on logout), so one user's cart never leaks to the next.
export default function CustomerLayout() {
  return (
    <CartProvider>
      <CustomerShell />
    </CartProvider>
  );
}

const HIDE_CART_BAR = [/^\/cart$/, /^\/checkout$/, /^\/orders\/[^/]+$/];

function CustomerShell() {
  const { pathname } = useLocation();
  const { count } = useCart();
  const showCartBar = count > 0 && !HIDE_CART_BAR.some((re) => re.test(pathname));

  // Reserve space so fixed chrome (nav + cart bar + safe area) never covers content.
  const bottomSpace = showCartBar
    ? "calc(var(--nav-h) + var(--safe-b) + var(--cartbar-h) + 32px)"
    : "calc(var(--nav-h) + var(--safe-b) + 24px)";

  return (
    <div className="min-h-screen bg-canvas">
      <main
        className="mx-auto max-w-md px-4"
        style={{ paddingTop: "calc(var(--safe-t) + 12px)", paddingBottom: bottomSpace }}
      >
        <div key={pathname} className="page-enter">
          <Outlet />
        </div>
      </main>
      <FloatingCartBar visible={showCartBar} />
      <BottomNav />
      <CartConflictSheet />
    </div>
  );
}
