import React from "react";
import { Outlet } from "react-router-dom";
import BottomNav from "@/components/customer/BottomNav";
import { CartProvider } from "@/context/CartContext";

export default function CustomerLayout() {
  return (
    <CartProvider>
      <div className="min-h-screen bg-background">
        <main className="max-w-md mx-auto px-4 pt-4 pb-28">
          <Outlet />
        </main>
        <BottomNav />
      </div>
    </CartProvider>
  );
}