import React from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus, Minus } from "lucide-react";
import { cn } from "@/lib/utils";
import { spring } from "@/lib/motion";
import { hapticTap } from "@/lib/haptics";
import AnimatedNumber from "@/components/customer/AnimatedNumber";

const SIZES = {
  sm: "h-8 w-[76px] text-[13px]",
  md: "h-9 w-[88px] text-[14px]",
};

/**
 * "Add" that morphs into a − qty + stepper.
 * The green fill animates with transform/opacity only (cheap on Android).
 */
export default function AddToCartButton({ qty = 0, onAdd, onIncrement, onDecrement, disabled = false, size = "md", className }) {
  const active = qty > 0;

  const handleAdd = (e) => {
    e.preventDefault();
    e.stopPropagation();
    hapticTap();
    onAdd?.();
  };
  const handleDec = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (qty === 1) hapticTap(); // removing the item
    onDecrement?.();
  };
  const handleInc = (e) => {
    e.preventDefault();
    e.stopPropagation();
    onIncrement?.();
  };

  return (
    <motion.div
      whileTap={!active && !disabled ? { scale: 0.94 } : undefined}
      transition={spring}
      className={cn(
        "relative select-none rounded-[10px] border font-bold",
        active ? "border-brand" : "border-brand/60 bg-surface shadow-lift",
        disabled && "pointer-events-none opacity-45",
        SIZES[size] || SIZES.md,
        className
      )}
    >
      <AnimatePresence initial={false}>
        {active && (
          <motion.span
            key="fill"
            aria-hidden="true"
            className="absolute inset-[-1px] rounded-[10px] bg-brand shadow-float"
            initial={{ opacity: 0, scale: 0.6 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.6 }}
            transition={spring}
          />
        )}
      </AnimatePresence>

      <AnimatePresence initial={false} mode="popLayout">
        {!active ? (
          <motion.button
            key="add"
            type="button"
            onClick={handleAdd}
            disabled={disabled}
            aria-label="Add to cart"
            className="hit-44 absolute inset-0 flex items-center justify-center gap-1 text-brand"
            initial={{ opacity: 0, scale: 0.85 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.85 }}
            transition={{ duration: 0.12 }}
          >
            <Plus size={14} strokeWidth={2.75} />
            Add
          </motion.button>
        ) : (
          <motion.div
            key="stepper"
            className="absolute inset-0 flex items-center justify-between text-white"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.12 }}
          >
            <button
              type="button"
              onClick={handleDec}
              aria-label={qty === 1 ? "Remove from cart" : "Decrease quantity"}
              className="hit-44 grid h-full w-8 place-items-center transition-transform active:scale-90"
            >
              <Minus size={14} strokeWidth={2.75} />
            </button>
            <span aria-live="polite" aria-label={`${qty} in cart`}>
              <AnimatedNumber value={qty} />
            </span>
            <button
              type="button"
              onClick={handleInc}
              aria-label="Increase quantity"
              className="hit-44 grid h-full w-8 place-items-center transition-transform active:scale-90"
            >
              <Plus size={14} strokeWidth={2.75} />
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
