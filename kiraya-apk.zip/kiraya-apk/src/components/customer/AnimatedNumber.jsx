import React, { useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { cn } from "@/lib/utils";
import { spring } from "@/lib/motion";

const variants = {
  enter: (dir) => ({ y: dir * 10, opacity: 0 }),
  center: { y: 0, opacity: 1 },
  exit: (dir) => ({ y: dir * -10, opacity: 0 }),
};

/** Rolls the value up when it grows and down when it shrinks. */
export default function AnimatedNumber({ value, format = (v) => v, className }) {
  const prev = useRef(value);
  const dir = value >= prev.current ? 1 : -1;
  useEffect(() => { prev.current = value; }, [value]);

  return (
    <span className={cn("relative inline-flex overflow-hidden tabular", className)}>
      <AnimatePresence initial={false} mode="popLayout" custom={dir}>
        <motion.span
          key={String(value)}
          custom={dir}
          variants={variants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={spring}
          className="inline-block"
        >
          {format(value)}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}
