import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Accepts both `to`/`actionLabel` and the `action={{ label, to }}` shape
 * that Home previously passed (and which silently rendered nothing).
 */
export default function SectionHeader({ title, subtitle, to, actionLabel = "See all", action, icon: Icon, className }) {
  const href = to || action?.to;
  const label = action?.label || actionLabel;
  return (
    <div className={cn("mb-3 flex items-end justify-between gap-3", className)}>
      <div className="min-w-0">
        <h2 className="flex items-center gap-1.5 text-section font-bold text-ink">
          {Icon && <Icon size={18} strokeWidth={2.25} className="shrink-0" />}
          <span className="truncate">{title}</span>
        </h2>
        {subtitle && <p className="mt-0.5 text-caption text-ink-3">{subtitle}</p>}
      </div>
      {href && (
        <Link to={href} className="press -my-3 flex min-h-[44px] shrink-0 items-center gap-0.5 text-secondary font-semibold text-brand">
          {label} <ChevronRight size={16} strokeWidth={2.25} />
        </Link>
      )}
    </div>
  );
}
