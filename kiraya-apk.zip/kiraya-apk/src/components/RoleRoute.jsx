const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useEffect, useState } from "react";
import { Navigate, Outlet } from "react-router-dom";

const Spinner = () => (
  <div className="fixed inset-0 grid place-items-center">
    <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
  </div>
);

// Guards a panel by user role. Builder (admin) can preview every panel.
export default function RoleRoute({ allow = [] }) {
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.auth.me()
      .then((u) => setRole(u?.role || "admin"))
      .catch(() => setRole("admin"))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;
  if (!allow.includes(role)) return <Navigate to="/" replace />;
  return <Outlet />;
}