import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

export default function RoleRoute({ allow = [] }) {
  const { profile, loading } = useAuth();
  if (loading) return null;
  const role = profile?.role || "customer";
  if (!allow.includes(role)) return <Navigate to="/" replace />;
  return <Outlet />;
}
