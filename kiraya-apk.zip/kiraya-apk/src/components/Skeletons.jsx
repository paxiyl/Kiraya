import React from "react";

export function ProductSkeleton() {
  return (
    <div className="card-soft rounded-2xl p-3 space-y-3">
      <div className="skeleton w-full h-32 rounded-xl" />
      <div className="skeleton h-3 w-3/4 rounded" />
      <div className="skeleton h-3 w-1/2 rounded" />
      <div className="skeleton h-8 w-20 rounded-full" />
    </div>
  );
}

export function StoreSkeleton() {
  return (
    <div className="card-soft rounded-2xl overflow-hidden space-y-3">
      <div className="skeleton w-full h-36" />
      <div className="p-3 space-y-2">
        <div className="skeleton h-3 w-2/3 rounded" />
        <div className="skeleton h-3 w-1/3 rounded" />
      </div>
    </div>
  );
}

export function GridSkeleton({ count = 6 }) {
  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
      {Array.from({ length: count }).map((_, i) => <ProductSkeleton key={i} />)}
    </div>
  );
}