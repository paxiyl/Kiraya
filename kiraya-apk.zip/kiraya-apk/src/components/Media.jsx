import React from "react";
import { Image } from "@/components/ui/image";
import { Leaf, UtensilsCrossed, Smartphone, Sparkles, Home as HomeIcon, Cake, Pill, Carrot, Store, ShoppingBag } from "lucide-react";

const TINTS = {
  food: "152 58% 38%", veg: "20 90% 56%", grocery: "142 60% 42%",
  beauty: "280 60% 60%", electronics: "220 70% 52%", home: "30 80% 54%",
  bakery: "40 90% 56%", pharmacy: "210 70% 56%", default: "220 8% 50%",
};
const ICONS = {
  food: UtensilsCrossed, veg: Carrot, grocery: Leaf, beauty: Sparkles,
  electronics: Smartphone, home: HomeIcon, bakery: Cake, pharmacy: Pill,
  default: ShoppingBag,
};

// Firebase-ready media: pass a real `src` (Firebase Storage URL) later.
// Until then renders a tasteful gradient + icon placeholder.
export default function Media({ src, category, label, className = "", fit = "cover", rounded = "rounded-2xl" }) {
  const tint = TINTS[category] || TINTS.default;
  const Icon = ICONS[category] || ICONS.default;
  if (src) {
    return (
      <Image
        src={src}
        alt={label || ""}
        className={`${rounded} ${className}`}
        fittingType={fit === "contain" ? "fit" : "fill"}
      />
    );
  }
  return (
    <div
      className={`${rounded} ${className} relative overflow-hidden flex items-center justify-center`}
      style={{
        background: `linear-gradient(150deg, hsl(${tint} / 0.16), hsl(${tint} / 0.04))`,
      }}
      aria-label={label}
    >
      <div className="absolute inset-0 opacity-[0.5]" style={{
        backgroundImage: "radial-gradient(circle at 30% 20%, hsl(var(--surface)) 0, transparent 60%)",
      }} />
      <Icon style={{ color: `hsl(${tint})` }} className="w-1/3 h-1/3 opacity-80" strokeWidth={1.4} />
    </div>
  );
}

export function StoreMedia({ src, category, label, className = "", rounded = "rounded-2xl" }) {
  const tint = TINTS[category] || TINTS.default;
  const Icon = ICONS[category] || Store;
  if (src) return <Image src={src} alt={label || ""} className={`${rounded} ${className}`} fittingType="fill" />;
  return (
    <div className={`${rounded} ${className} relative overflow-hidden flex items-center justify-center`}
      style={{ background: `linear-gradient(150deg, hsl(${tint} / 0.18), hsl(${tint} / 0.05))` }}>
      <Icon style={{ color: `hsl(${tint})` }} className="w-1/4 h-1/4 opacity-80" strokeWidth={1.4} />
    </div>
  );
}