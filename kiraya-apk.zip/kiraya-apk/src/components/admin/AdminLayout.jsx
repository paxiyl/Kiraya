import React, { useState } from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { LayoutDashboard, ClipboardList, Store, Package, Users, Bike, CreditCard, BarChart3, Settings, Menu, X, ChevronLeft, LogOut } from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";
import StatusBadge from "@/components/customer/StatusBadge";

const NAV = [
  { to: "/admin", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/admin/orders", label: "Orders", icon: ClipboardList },
  { to: "/admin/stores", label: "Stores", icon: Store },
  { to: "/admin/customers", label: "Customers", icon: Users },
  { to: "/admin/delivery", label: "Delivery Partners", icon: Bike },
  { to: "/admin/payments", label: "Payments", icon: CreditCard },
  { to: "/admin/analytics", label: "Analytics", icon: BarChart3 },
  { to: "/admin/settings", label: "Settings", icon: Settings },
];

export default function AdminLayout() {
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const SidebarContent = ({ onNav }) => (
    <div className="flex flex-col h-full">
      <div className="flex items-center gap-2 px-5 h-16 border-b border-[hsl(var(--border))]">
        <div className="w-8 h-8 rounded-xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] grid place-items-center font-bold text-sm">K</div>
        <div>
          <p className="text-sm font-bold leading-none">{APP_CONFIG.name}</p>
          <p className="text-[10px] text-[hsl(var(--text-tertiary))] mt-0.5">Admin Console</p>
        </div>
      </div>
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        {NAV.map((n) => {
          const Icon = n.icon;
          return (
            <NavLink key={n.to} to={n.to} end={n.end} onClick={onNav}
              className={({ isActive }) => `press flex items-center gap-3 px-3 h-11 rounded-xl text-sm font-medium ${isActive ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "text-[hsl(var(--text-secondary))] hover:bg-[hsl(var(--surface-2))]"}`}>
              <Icon className="w-4.5 h-4.5" strokeWidth={1.8} /> {n.label}
            </NavLink>
          );
        })}
      </nav>
      <div className="p-3 border-t border-[hsl(var(--border))]">
        <button onClick={() => navigate("/")} className="press w-full flex items-center gap-2 px-3 h-11 rounded-xl text-sm text-[hsl(var(--text-secondary))] hover:bg-[hsl(var(--surface-2))]">
          <ChevronLeft className="w-4 h-4" /> Back to customer app
        </button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background md:flex">
      {/* Desktop sidebar */}
      <aside className="hidden md:block w-64 shrink-0 border-r border-[hsl(var(--border))] bg-[hsl(var(--surface))]">
        <div className="sticky top-0 h-screen"><SidebarContent /></div>
      </aside>

      {/* Mobile drawer */}
      {open && (
        <div className="md:hidden fixed inset-0 z-50">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-0 bottom-0 w-72 bg-[hsl(var(--surface))] shadow-xl">
            <button onClick={() => setOpen(false)} className="absolute top-4 right-4 press w-8 h-8 rounded-full grid place-items-center"><X className="w-4 h-4" /></button>
            <SidebarContent onNav={() => setOpen(false)} />
          </div>
        </div>
      )}

      <div className="flex-1 min-w-0">
        {/* Topbar */}
        <header className="sticky top-0 z-30 h-16 glass-strong border-b border-[hsl(var(--glass-border))] flex items-center gap-3 px-4">
          <button onClick={() => setOpen(true)} className="press md:hidden w-10 h-10 rounded-xl grid place-items-center card-soft"><Menu className="w-5 h-5" /></button>
          <h1 className="text-base font-semibold">Admin Console</h1>
          <div className="ml-auto flex items-center gap-2">
            <span className="hidden sm:inline-flex"><StatusBadge status="ACCEPTED" /></span>
            <div className="w-9 h-9 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center font-semibold text-sm">A</div>
          </div>
        </header>
        <main className="p-4 md:p-6 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}