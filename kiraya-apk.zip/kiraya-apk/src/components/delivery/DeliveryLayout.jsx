import React from "react";
import { NavLink, Outlet, useNavigate } from "react-router-dom";
import { Bike, Navigation, Wallet, User } from "lucide-react";
import { motion } from "framer-motion";
import { APP_CONFIG } from "@/lib/appConfig";

const NAV = [
  { to: "/delivery", label: "Requests", icon: Bike, end: true },
  { to: "/delivery/active", label: "Active", icon: Navigation },
  { to: "/delivery/earnings", label: "Earnings", icon: Wallet },
  { to: "/delivery/profile", label: "Profile", icon: User },
];

export default function DeliveryLayout() {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-background">
      <main className="max-w-md mx-auto px-4 pt-4 pb-28">
        <Outlet />
      </main>
      <nav className="fixed bottom-0 inset-x-0 z-40 glass-strong border-t border-[hsl(var(--glass-border))] safe-bottom">
        <div className="max-w-md mx-auto grid grid-cols-4">
          {NAV.map((it) => {
            const Icon = it.icon;
            return (
              <NavLink key={it.to} to={it.to} end={it.end}>
                {({ isActive }) => (
                  <div className="press flex flex-col items-center justify-center gap-1 py-2.5 text-[hsl(var(--text-tertiary))]">
                    <Icon className="w-5 h-5" strokeWidth={isActive ? 2.4 : 1.7} />
                    <span className={`text-[10px] font-medium ${isActive ? "text-[hsl(var(--text-primary))]" : ""}`}>{it.label}</span>
                    {isActive && <motion.span layoutId="dnavdot" className="absolute top-0 w-1.5 h-1.5 rounded-full bg-[hsl(var(--accent))]" />}
                  </div>
                )}
              </NavLink>
            );
          })}
        </div>
      </nav>
    </div>
  );
}