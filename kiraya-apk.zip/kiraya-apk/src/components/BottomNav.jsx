import React from "react";
import { NavLink } from "react-router-dom";
import { Home, Compass, ClipboardList, ShoppingBag, User } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { motion } from "framer-motion";

const items = [
  { to: "/", label: "Home", icon: Home, end: true },
  { to: "/explore", label: "Explore", icon: Compass },
  { to: "/orders", label: "Orders", icon: ClipboardList },
  { to: "/cart", label: "Cart", icon: ShoppingBag, badge: "count" },
  { to: "/profile", label: "Profile", icon: User },
];

export default function BottomNav() {
  const { count } = useCart();
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 glass-strong border-t border-[hsl(var(--glass-border))] safe-bottom">
      <div className="max-w-md mx-auto grid grid-cols-5">
        {items.map((it) => {
          const Icon = it.icon;
          return (
            <NavLink key={it.to} to={it.to} end={it.end} className="relative">
              {({ isActive }) => (
                <div className="press flex flex-col items-center justify-center gap-1 py-2.5 text-[hsl(var(--text-tertiary))]">
                  <div className="relative">
                    <Icon className="w-5 h-5" strokeWidth={isActive ? 2.2 : 1.7} />
                    {it.badge === "count" && count > 0 && (
                      <span className="absolute -top-1.5 -right-2 min-w-4 h-4 px-1 rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-[10px] font-bold grid place-items-center">
                        {count > 99 ? "99+" : count}
                      </span>
                    )}
                  </div>
                  <span className={`text-[10px] font-medium ${isActive ? "text-[hsl(var(--text-primary))]" : ""}`}>
                    {it.label}
                  </span>
                  {isActive && (
                    <motion.span
                      layoutId="navdot"
                      className="absolute top-0 w-1.5 h-1.5 rounded-full bg-[hsl(var(--accent))]"
                    />
                  )}
                </div>
              )}
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
}