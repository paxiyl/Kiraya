import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Star, Plus, Minus, Zap } from "lucide-react";
import { Link } from "react-router-dom";
import { useCart } from "@/context/CartContext";
import { formatPrice } from "@/lib/appConfig";
import Media from "@/components/customer/Media";
import { Pill } from "@/components/customer/StatusBadge";

export default function ProductCard({ product }) {
  const { qtyOf, add, setQty } = useCart();
  const qty = qtyOf(product.id);
  const off = product.mrp > product.price ? Math.round(((product.mrp - product.price) / product.mrp) * 100) : 0;

  return (
    <div className="card-soft rounded-2xl p-3 press group">
      <Link to={`/product/${product.id}`} className="block">
        <div className="relative">
          <Media category={product.category} label={product.name} className="w-full h-32" />
          {product.badge && (
            <span className="absolute top-2 left-2"><Pill tone="accent">{product.badge}</Pill></span>
          )}
          {off > 0 && (
            <span className="absolute top-2 right-2"><Pill tone="success">{off}% OFF</Pill></span>
          )}
        </div>
      </Link>
      <div className="mt-2.5 px-0.5">
        <Link to={`/product/${product.id}`} className="block">
          <h3 className="text-sm font-semibold text-[hsl(var(--text-primary))] leading-snug line-clamp-1">{product.name}</h3>
          <p className="text-xs text-[hsl(var(--text-tertiary))] line-clamp-1 mt-0.5">{product.storeName}</p>
        </Link>
        <div className="flex items-center gap-2 mt-1.5 text-xs text-[hsl(var(--text-secondary))]">
          <span className="inline-flex items-center gap-0.5 text-[hsl(var(--text-primary))] font-medium">
            <Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {product.rating}
          </span>
          <span className="inline-flex items-center gap-0.5 text-[hsl(var(--accent))]">
            <Zap className="w-3 h-3" /> {product.eta}
          </span>
        </div>
        <div className="flex items-end justify-between mt-2">
          <div className="flex items-baseline gap-1.5">
            <span className="text-sm font-bold text-[hsl(var(--text-primary))]">{formatPrice(product.price)}</span>
            {product.mrp > product.price && (
              <span className="text-xs text-[hsl(var(--text-tertiary))] line-through">{formatPrice(product.mrp)}</span>
            )}
          </div>
          <AnimatePresence mode="popLayout" initial={false}>
            {qty === 0 ? (
              <motion.button
                key="add"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
                onClick={() => add(product.id)}
                className="press inline-flex items-center gap-1 px-3 h-8 rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-xs font-semibold shadow-sm"
              >
                <Plus className="w-3.5 h-3.5" /> Add
              </motion.button>
            ) : (
              <motion.div
                key="qty"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.8 }}
                transition={{ type: "spring", stiffness: 400, damping: 28 }}
                className="inline-flex items-center gap-1 h-8 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]"
              >
                <button onClick={() => setQty(product.id, qty - 1)} className="press w-8 h-8 grid place-items-center">
                  <Minus className="w-3.5 h-3.5" />
                </button>
                <span className="text-xs font-bold w-4 text-center tabular-nums">{qty}</span>
                <button onClick={() => setQty(product.id, qty + 1)} className="press w-8 h-8 grid place-items-center">
                  <Plus className="w-3.5 h-3.5" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}