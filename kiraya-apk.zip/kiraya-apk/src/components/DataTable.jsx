import React, { useMemo, useState } from "react";
import { Search, ChevronLeft, ChevronRight, ArrowUpDown } from "lucide-react";
import { cn } from "@/lib/utils";

// columns: [{ key, label, render?(row), sortable?, className? }]
export default function DataTable({ columns, rows, searchKeys = [], onRowClick, pageSize = 8, title }) {
  const [q, setQ] = useState("");
  const [sortKey, setSortKey] = useState(null);
  const [dir, setDir] = useState(1);
  const [page, setPage] = useState(0);

  const filtered = useMemo(() => {
    let list = rows;
    if (q && searchKeys.length) {
      const t = q.toLowerCase();
      list = list.filter((r) => searchKeys.some((k) => String(r[k] ?? "").toLowerCase().includes(t)));
    }
    if (sortKey) list = [...list].sort((a, b) => (a[sortKey] > b[sortKey] ? dir : a[sortKey] < b[sortKey] ? -dir : 0));
    return list;
  }, [rows, q, sortKey, dir, searchKeys]);

  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const current = Math.min(page, pages - 1);
  const slice = filtered.slice(current * pageSize, current * pageSize + pageSize);

  const toggleSort = (key) => {
    if (sortKey === key) setDir(-dir);
    else { setSortKey(key); setDir(1); }
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-3">
        {title && <h2 className="text-sm font-semibold">{title}</h2>}
        {searchKeys.length > 0 && (
          <div className="ml-auto flex items-center gap-2 h-9 px-3 rounded-xl glass">
            <Search className="w-3.5 h-3.5 text-[hsl(var(--text-tertiary))]" />
            <input value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} placeholder="Search…" className="bg-transparent outline-none text-sm w-32" />
          </div>
        )}
      </div>

      {/* Desktop table */}
      <div className="hidden md:block card-soft rounded-2xl overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-[hsl(var(--surface-2))]">
            <tr>
              {columns.map((c) => (
                <th key={c.key} className="text-left px-4 py-3 font-medium text-xs text-[hsl(var(--text-secondary))]">
                  {c.sortable ? (
                    <button onClick={() => toggleSort(c.key)} className="press inline-flex items-center gap-1">
                      {c.label} <ArrowUpDown className="w-3 h-3 opacity-60" />
                    </button>
                  ) : c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[hsl(var(--border))]">
            {slice.map((row) => (
              <tr key={row.id} onClick={() => onRowClick?.(row)} className={cn("hover:bg-[hsl(var(--surface-2))]", onRowClick && "cursor-pointer")}>
                {columns.map((c) => (
                  <td key={c.key} className={cn("px-4 py-3", c.className)}>{c.render ? c.render(row) : row[c.key]}</td>
                ))}
              </tr>
            ))}
            {slice.length === 0 && (
              <tr><td colSpan={columns.length} className="px-4 py-10 text-center text-sm text-[hsl(var(--text-tertiary))]">No results found.</td></tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-2">
        {slice.map((row) => (
          <div key={row.id} onClick={() => onRowClick?.(row)} className={cn("card-soft rounded-2xl p-4 space-y-2", onRowClick && "press cursor-pointer")}>
            {columns.map((c) => (
              <div key={c.key} className="flex justify-between gap-3 text-sm">
                <span className="text-xs text-[hsl(var(--text-tertiary))]">{c.label}</span>
                <span className="text-right font-medium">{c.render ? c.render(row) : row[c.key]}</span>
              </div>
            ))}
          </div>
        ))}
        {slice.length === 0 && <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-8">No results found.</p>}
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex items-center justify-between text-xs text-[hsl(var(--text-secondary))]">
          <span>{current * pageSize + 1}–{Math.min((current + 1) * pageSize, filtered.length)} of {filtered.length}</span>
          <div className="flex gap-1">
            <button onClick={() => setPage(Math.max(0, current - 1))} disabled={current === 0} className="press w-8 h-8 rounded-lg card-soft grid place-items-center disabled:opacity-40"><ChevronLeft className="w-4 h-4" /></button>
            <button onClick={() => setPage(Math.min(pages - 1, current + 1))} disabled={current === pages - 1} className="press w-8 h-8 rounded-lg card-soft grid place-items-center disabled:opacity-40"><ChevronRight className="w-4 h-4" /></button>
          </div>
        </div>
      )}
    </div>
  );
}