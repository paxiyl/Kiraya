import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";

export default function SectionHeader({ title, subtitle, to, actionLabel = "See all" }) {
  return (
    <div className="flex items-end justify-between mb-3">
      <div>
        <h2 className="text-lg font-semibold tracking-tight text-[hsl(var(--text-primary))]">{title}</h2>
        {subtitle && <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">{subtitle}</p>}
      </div>
      {to && (
        <Link to={to} className="press inline-flex items-center gap-0.5 text-xs font-medium text-[hsl(var(--accent))]">
          {actionLabel} <ChevronRight className="w-3.5 h-3.5" />
        </Link>
      )}
    </div>
  );
}