import React from "react";
import { cn } from "@/lib/utils";

export default function EmptyState({ icon: Icon, title, desc, action, className }) {
  return (
    <div className={cn("flex flex-col items-center justify-center text-center py-16 px-6", className)}>
      {Icon && (
        <div className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4 bg-[hsl(var(--muted))] text-[hsl(var(--text-tertiary))]">
          <Icon className="w-7 h-7" strokeWidth={1.5} />
        </div>
      )}
      <h3 className="text-base font-semibold text-[hsl(var(--text-primary))]">{title}</h3>
      {desc && <p className="text-sm text-[hsl(var(--text-secondary))] mt-1 max-w-xs">{desc}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}