import React from "react";
import { cn } from "@/lib/utils";

const MAP = {
  PENDING: { label: "Pending", tone: "warning" },
  ACCEPTED: { label: "Accepted", tone: "accent" },
  PREPARING: { label: "Preparing", tone: "accent" },
  READY: { label: "Ready", tone: "accent" },
  PICKED_UP: { label: "Picked up", tone: "accent" },
  OUT_FOR_DELIVERY: { label: "On the way", tone: "accent" },
  DELIVERED: { label: "Delivered", tone: "success" },
  CANCELLED: { label: "Cancelled", tone: "danger" },
};

const TONES = {
  accent: "bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]",
  success: "bg-[hsl(var(--success-soft))] text-[hsl(var(--success))]",
  warning: "bg-[hsl(var(--warning-soft))] text-[hsl(var(--warning))]",
  danger: "bg-[hsl(var(--danger-soft))] text-[hsl(var(--danger))]",
  neutral: "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]",
};

export default function StatusBadge({ status, className }) {
  const m = MAP[status] || { label: status, tone: "neutral" };
  return (
    <span className={cn(
      "inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium",
      TONES[m.tone], className
    )}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {m.label}
    </span>
  );
}

export function Pill({ children, tone = "neutral", className }) {
  return (
    <span className={cn("inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium", TONES[tone], className)}>
      {children}
    </span>
  );
}