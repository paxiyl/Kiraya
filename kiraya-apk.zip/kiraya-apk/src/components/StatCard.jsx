import React from "react";
import { cn } from "@/lib/utils";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import { formatPrice } from "@/lib/appConfig";

export default function StatCard({ label, value, prefix, suffix, delta, up, icon: Icon, tone = "accent" }) {
  const tones = {
    accent: "text-[hsl(var(--accent))] bg-[hsl(var(--accent-soft))]",
    success: "text-[hsl(var(--success))] bg-[hsl(var(--success-soft))]",
    warning: "text-[hsl(var(--warning))] bg-[hsl(var(--warning-soft))]",
    danger: "text-[hsl(var(--danger))] bg-[hsl(var(--danger-soft))]",
    neutral: "text-[hsl(var(--text-secondary))] bg-[hsl(var(--muted))]",
  };
  const display = prefix ? formatPrice(value) : `${value}${suffix || ""}`;
  return (
    <div className="card-soft rounded-2xl p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">{label}</p>
          <p className="text-2xl font-bold mt-1 tracking-tight">{display}</p>
        </div>
        {Icon && (
          <div className={cn("w-9 h-9 rounded-xl grid place-items-center", tones[tone])}>
            <Icon className="w-4.5 h-4.5" strokeWidth={1.8} />
          </div>
        )}
      </div>
      {delta && (
        <div className="flex items-center gap-1 mt-2 text-xs">
          <span className={cn("inline-flex items-center gap-0.5 font-medium", up === true ? "text-[hsl(var(--success))]" : up === false ? "text-[hsl(var(--danger))]" : "text-[hsl(var(--text-tertiary))]")}>
            {up === true && <ArrowUpRight className="w-3 h-3" />}
            {up === false && <ArrowDownRight className="w-3 h-3" />}
            {delta}
          </span>
          <span className="text-[hsl(var(--text-tertiary))]">vs last period</span>
        </div>
      )}
    </div>
  );
}