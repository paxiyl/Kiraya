import React, { useState, useEffect, useRef, useCallback } from "react";
import { MapPin, Search, Loader2, X, Check, Navigation, AlertCircle } from "lucide-react";

const HINDAUN = {
  lat: 26.7285, lng: 77.0350, zoom: 15,
  bounds: { minLat: 26.65, maxLat: 26.82, minLng: 76.95, maxLng: 77.12 },
  landmarks: [
    { name: "Hindaun Bus Stand",       lat: 26.7264, lng: 77.0298 },
    { name: "Hindaun Railway Station", lat: 26.7221, lng: 77.0412 },
    { name: "Ganj Market",             lat: 26.7291, lng: 77.0327 },
    { name: "Indira Colony",           lat: 26.7320, lng: 77.0280 },
    { name: "Shiv Colony",             lat: 26.7255, lng: 77.0365 },
    { name: "Nagar Palika Office",     lat: 26.7275, lng: 77.0310 },
    { name: "Government Hospital",     lat: 26.7248, lng: 77.0285 },
    { name: "Ambedkar Circle",         lat: 26.7305, lng: 77.0345 },
    { name: "Old Bus Stand",           lat: 26.7270, lng: 77.0315 },
    { name: "Subhash Chowk",          lat: 26.7282, lng: 77.0338 },
  ],
};

function inBounds(lat, lng) {
  const b = HINDAUN.bounds;
  return lat >= b.minLat && lat <= b.maxLat && lng >= b.minLng && lng <= b.maxLng;
}

async function reverseGeocode(lat, lng) {
  try {
    const res = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1&zoom=18`,
      { headers: { "Accept-Language": "en" } }
    );
    const d = await res.json();
    if (!d || d.error) return "";
    const a = d.address || {};
    const parts = [
      a.shop || a.amenity || a.building || a.place,
      a.road || a.pedestrian || a.footway,
      a.neighbourhood || a.suburb || a.village || a.town,
    ].filter(Boolean);
    return parts.length
      ? parts.join(", ")
      : (d.display_name || "").split(",").slice(0, 2).join(",").trim();
  } catch { return ""; }
}

async function searchPlaces(query) {
  try {
    const b = HINDAUN.bounds;
    const res = await fetch(
      `https://nominatim.openstreetmap.org/search` +
      `?q=${encodeURIComponent(query + " Hindaun Rajasthan")}` +
      `&format=json&limit=5&addressdetails=1` +
      `&viewbox=${b.minLng},${b.maxLat},${b.maxLng},${b.minLat}`,
      { headers: { "Accept-Language": "en" } }
    );
    return await res.json();
  } catch { return []; }
}

export default function MapPicker({ onSelect, onClose, initial }) {
  const mapDiv    = useRef(null);
  const mapObj    = useRef(null);
  const markerObj = useRef(null);

  const [address, setAddress]       = useState(initial?.line || "");
  const [lat, setLat]               = useState(initial?.lat  || HINDAUN.lat);
  const [lng, setLng]               = useState(initial?.lng  || HINDAUN.lng);
  const [search, setSearch]         = useState("");
  const [results, setResults]       = useState([]);
  const [geocoding, setGeocoding]   = useState(false);
  const [searching, setSearching]   = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [outOfArea, setOutOfArea]   = useState(false);
  const [tab, setTab]               = useState("map");
  const [mapReady, setMapReady]     = useState(false);

  const onPin = useCallback(async (newLat, newLng) => {
    setLat(newLat); setLng(newLng);
    if (!inBounds(newLat, newLng)) {
      setOutOfArea(true);
      setAddress("Outside Hindaun City delivery area");
      return;
    }
    setOutOfArea(false);
    setGeocoding(true);
    const addr = await reverseGeocode(newLat, newLng);
    setAddress(addr || `${newLat.toFixed(5)}, ${newLng.toFixed(5)}`);
    setGeocoding(false);
  }, []);

  useEffect(() => {
    if (mapObj.current || !mapDiv.current) return;

    // Small delay to ensure the container has rendered with correct dimensions
    const timer = setTimeout(() => {
      import("leaflet").then(L => {
        delete L.Icon.Default.prototype._getIconUrl;
        L.Icon.Default.mergeOptions({
          iconUrl:       "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
          iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
          shadowUrl:     "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
        });

        const map = L.map(mapDiv.current, {
          center:      [HINDAUN.lat, HINDAUN.lng],
          zoom:        HINDAUN.zoom,
          zoomControl: false,
          tap:         false,
        });

        L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom:     19,
          attribution: "© OpenStreetMap contributors",
        }).addTo(map);

        L.control.zoom({ position: "topright" }).addTo(map);

        // Service boundary
        L.rectangle(
          [[HINDAUN.bounds.minLat, HINDAUN.bounds.minLng],
           [HINDAUN.bounds.maxLat, HINDAUN.bounds.maxLng]],
          { color: "#22c55e", weight: 2, fillOpacity: 0.04, dashArray: "6 4" }
        ).addTo(map);

        // Custom pin
        const pinIcon = L.divIcon({
          className: "",
          html: `<div style="position:relative;width:32px;height:42px;">
            <svg viewBox="0 0 32 42" xmlns="http://www.w3.org/2000/svg"
              style="width:32px;height:42px;filter:drop-shadow(0 2px 5px rgba(0,0,0,.35))">
              <path d="M16 0C8 0 2 6 2 14c0 10 14 28 14 28S30 24 30 14C30 6 24 0 16 0z" fill="#ef4444"/>
              <circle cx="16" cy="14" r="6" fill="white"/>
            </svg>
          </div>`,
          iconSize:   [32, 42],
          iconAnchor: [16, 42],
        });

        const initLat = initial?.lat || HINDAUN.lat;
        const initLng = initial?.lng || HINDAUN.lng;

        const marker = L.marker([initLat, initLng], {
          icon: pinIcon, draggable: true,
        }).addTo(map);

        marker.on("dragend", e => {
          const p = e.target.getLatLng();
          onPin(p.lat, p.lng);
        });

        map.on("click", e => {
          marker.setLatLng(e.latlng);
          onPin(e.latlng.lat, e.latlng.lng);
        });

        mapObj.current    = map;
        markerObj.current = marker;
        setMapReady(true);

        // CRITICAL: force map to recalculate its size after render
        setTimeout(() => map.invalidateSize(), 100);
        setTimeout(() => map.invalidateSize(), 400);

        if (!initial?.line) onPin(initLat, initLng);
      });
    }, 50);

    return () => {
      clearTimeout(timer);
      if (mapObj.current) {
        mapObj.current.remove();
        mapObj.current = null;
        markerObj.current = null;
      }
    };
  }, []);

  // Invalidate size whenever tab switches back to map
  useEffect(() => {
    if (tab === "map" && mapObj.current) {
      setTimeout(() => mapObj.current?.invalidateSize(), 50);
    }
  }, [tab]);

  const flyTo = useCallback((newLat, newLng, zoom = 17) => {
    if (mapObj.current && markerObj.current) {
      mapObj.current.flyTo([newLat, newLng], zoom, { duration: 0.8 });
      markerObj.current.setLatLng([newLat, newLng]);
    }
    onPin(newLat, newLng);
  }, [onPin]);

  const useGPS = () => {
    if (!navigator.geolocation) return;
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      pos => { setGpsLoading(false); flyTo(pos.coords.latitude, pos.coords.longitude, 18); },
      ()  => setGpsLoading(false),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  };

  const doSearch = async () => {
    if (!search.trim()) return;
    setSearching(true);
    const data = await searchPlaces(search);
    setSearching(false);
    setResults(data.length ? data : [{ noResult: true }]);
  };

  const pickResult = r => {
    if (r.noResult) return;
    setResults([]); setSearch("");
    flyTo(parseFloat(r.lat), parseFloat(r.lon), 17);
  };

  const pickLandmark = lm => {
    setTab("map");
    // Wait for tab switch then fly
    setTimeout(() => flyTo(lm.lat, lm.lng, 18), 100);
  };

  const confirm = () => {
    if (outOfArea || !address || geocoding) return;
    onSelect({ lat, lng, line: address });
  };

  return (
    <div className="fixed inset-0 z-[200] flex flex-col bg-background" style={{ height: "100dvh" }}>

      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-[hsl(var(--border))] bg-background shrink-0">
        <button onClick={onClose}
          className="press w-9 h-9 rounded-full bg-[hsl(var(--muted))] grid place-items-center shrink-0">
          <X className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="font-semibold text-sm">Select delivery location</h2>
          <p className="text-[11px] text-[hsl(var(--text-tertiary))]">Hindaun City, Rajasthan</p>
        </div>
        <button onClick={confirm} disabled={outOfArea || !address || geocoding}
          className="press h-9 px-4 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold disabled:opacity-40 shrink-0 flex items-center gap-1.5">
          <Check className="w-3.5 h-3.5" /> Done
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[hsl(var(--border))] bg-background shrink-0">
        {[["map","🗺️ Map"], ["landmarks","📍 Landmarks"]].map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors
              ${tab === id
                ? "border-b-2 border-[hsl(var(--accent))] text-[hsl(var(--accent))]"
                : "text-[hsl(var(--text-tertiary))]"}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Search + GPS */}
      <div className="px-3 py-2 bg-background shrink-0 relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            <input
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--muted))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
              placeholder="Search colony, street, shop…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === "Enter" && doSearch()}
            />
          </div>
          <button onClick={doSearch} disabled={searching}
            className="press h-10 px-3 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold shrink-0">
            {searching ? <Loader2 className="w-4 h-4 animate-spin" /> : "Go"}
          </button>
          <button onClick={useGPS} disabled={gpsLoading}
            className="press h-10 w-10 rounded-xl bg-blue-500 text-white grid place-items-center shrink-0">
            {gpsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
          </button>
        </div>

        {results.length > 0 && (
          <div className="absolute left-3 right-3 top-[52px] bg-background border border-[hsl(var(--border))] rounded-2xl shadow-xl z-50 overflow-hidden max-h-52 overflow-y-auto">
            {results.map((r, i) => (
              <button key={i} onClick={() => pickResult(r)} disabled={r.noResult}
                className="w-full text-left px-4 py-3 text-sm hover:bg-[hsl(var(--muted))] border-b border-[hsl(var(--border))] last:border-0 disabled:opacity-50">
                {r.noResult
                  ? <p className="text-[hsl(var(--text-tertiary))]">No results found</p>
                  : <>
                      <p className="font-medium line-clamp-1">{r.display_name?.split(",")[0]}</p>
                      <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5 line-clamp-1">
                        {r.display_name?.split(",").slice(1, 3).join(",")}
                      </p>
                    </>
                }
              </button>
            ))}
            <button onClick={() => setResults([])} className="w-full py-2 text-xs text-[hsl(var(--text-tertiary))] text-center">
              Close
            </button>
          </div>
        )}
      </div>

      {/* Map container — always rendered, hidden when landmarks tab active */}
      {/* Must stay in DOM so Leaflet doesn't lose its container */}
      <div
        className="relative"
        style={{
          flex: 1,
          display: tab === "landmarks" ? "none" : "block",
          minHeight: 0,
        }}
      >
        <div
          ref={mapDiv}
          style={{ position: "absolute", inset: 0, width: "100%", height: "100%" }}
        />
        <div className="absolute top-2 left-1/2 -translate-x-1/2 z-10 pointer-events-none">
          <div className="bg-white/90 backdrop-blur-sm text-xs px-3 py-1.5 rounded-full shadow text-slate-700 font-medium whitespace-nowrap">
            Tap map or drag pin to set location
          </div>
        </div>
      </div>

      {/* Landmarks tab */}
      {tab === "landmarks" && (
        <div className="flex-1 overflow-y-auto px-4 py-3">
          <p className="text-xs text-[hsl(var(--text-tertiary))] mb-3">
            Tap a landmark to jump to it on the map
          </p>
          <div className="space-y-2">
            {HINDAUN.landmarks.map(lm => (
              <button key={lm.name} onClick={() => pickLandmark(lm)}
                className="press w-full flex items-center gap-3 p-3.5 rounded-2xl card-soft text-left">
                <div className="w-9 h-9 rounded-xl bg-[hsl(var(--accent-soft))] grid place-items-center shrink-0">
                  <MapPin className="w-4 h-4 text-[hsl(var(--accent))]" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{lm.name}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">Hindaun City, Rajasthan</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Bottom address bar */}
      <div className={`shrink-0 border-t border-[hsl(var(--border))] bg-background`}>
        <div className="px-4 py-3 flex items-start gap-3">
          {outOfArea
            ? <AlertCircle className="w-4.5 h-4.5 text-red-500 shrink-0 mt-0.5" />
            : geocoding
              ? <Loader2 className="w-4.5 h-4.5 text-[hsl(var(--accent))] shrink-0 mt-0.5 animate-spin" />
              : <MapPin className="w-4.5 h-4.5 text-[hsl(var(--accent))] shrink-0 mt-0.5" />
          }
          <div className="flex-1 min-w-0">
            <p className="text-xs text-[hsl(var(--text-tertiary))] mb-0.5">
              {outOfArea ? "Outside delivery area" : geocoding ? "Getting address…" : "Selected location"}
            </p>
            <p className={`text-sm font-medium line-clamp-2 ${outOfArea ? "text-red-500" : ""}`}>
              {address || "Tap anywhere on the map to pin your location"}
            </p>
          </div>
        </div>
        {!outOfArea && address && !geocoding && (
          <div className="px-4 pb-5">
            <button onClick={confirm}
              className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold flex items-center justify-center gap-2">
              <Check className="w-4 h-4" /> Confirm this location
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
