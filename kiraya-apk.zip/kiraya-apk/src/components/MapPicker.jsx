/**
 * MapPicker — Full-featured address picker for Hindaun City
 * - High-quality OpenStreetMap tiles (Carto Voyager - shows roads, shops, labels clearly)
 * - GPS "Use my location" button
 * - Live search with Nominatim (scoped to Hindaun)
 * - Reverse geocoding on pin drop
 * - Hindaun City boundary enforcement
 * - Landmark suggestions
 * - No API key required
 */
import React, { useState, useEffect, useRef, useCallback } from "react";
import { MapPin, Search, Loader2, X, Check, Navigation, AlertCircle } from "lucide-react";

const HINDAUN = {
  lat: 26.7285, lng: 77.0350,
  bounds: { minLat:26.67, maxLat:26.79, minLng:76.97, maxLng:77.10 },
  zoom: 15,
  // Well-known landmarks for quick selection
  landmarks: [
    { name: "Hindaun City Bus Stand",  lat:26.7264, lng:77.0298 },
    { name: "Hindaun City Railway Station", lat:26.7221, lng:77.0412 },
    { name: "Ganj Market",             lat:26.7291, lng:77.0327 },
    { name: "Indira Colony",           lat:26.7320, lng:77.0280 },
    { name: "Shiv Colony",             lat:26.7255, lng:77.0365 },
    { name: "Nagar Palika",            lat:26.7275, lng:77.0310 },
    { name: "Government Hospital",     lat:26.7248, lng:77.0285 },
    { name: "Ambedkar Circle",         lat:26.7305, lng:77.0345 },
  ],
};

function inBounds(lat, lng) {
  const b = HINDAUN.bounds;
  return lat >= b.minLat && lat <= b.maxLat && lng >= b.minLng && lng <= b.maxLng;
}

async function reverseGeocode(lat, lng) {
  try {
    const r = await fetch(
      `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1&zoom=18`,
      { headers:{ "Accept-Language":"en", "User-Agent":"KirayaApp/1.0" } }
    );
    const d = await r.json();
    const a = d.address || {};
    const parts = [
      a.shop || a.amenity || a.building,
      a.road || a.pedestrian || a.footway,
      a.neighbourhood || a.suburb || a.village || a.town || a.county,
    ].filter(Boolean);
    return parts.length ? parts.join(", ") : d.display_name?.split(",").slice(0,2).join(",") || "";
  } catch { return ""; }
}

async function searchPlaces(q) {
  try {
    const r = await fetch(
      `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q + " Hindaun Karauli Rajasthan India")}&format=json&limit=6&addressdetails=1&bounded=1&viewbox=${HINDAUN.bounds.minLng},${HINDAUN.bounds.maxLat},${HINDAUN.bounds.maxLng},${HINDAUN.bounds.minLat}`,
      { headers:{ "Accept-Language":"en", "User-Agent":"KirayaApp/1.0" } }
    );
    return await r.json();
  } catch { return []; }
}

export default function MapPicker({ onSelect, onClose, initial }) {
  const mapDiv    = useRef(null);
  const mapObj    = useRef(null);
  const markerObj = useRef(null);
  const [address, setAddress]   = useState(initial?.line || "");
  const [search, setSearch]     = useState("");
  const [results, setResults]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [gpsLoading, setGpsLoading] = useState(false);
  const [outOfArea, setOutOfArea]   = useState(false);
  const [tab, setTab] = useState("map"); // "map" | "landmarks"
  const [lat, setLat] = useState(initial?.lat || HINDAUN.lat);
  const [lng, setLng] = useState(initial?.lng || HINDAUN.lng);

  const onPinMove = useCallback(async (newLat, newLng) => {
    setLat(newLat); setLng(newLng);
    if (!inBounds(newLat, newLng)) {
      setOutOfArea(true);
      setAddress("📍 Outside Hindaun City delivery area");
      return;
    }
    setOutOfArea(false);
    setLoading(true);
    const addr = await reverseGeocode(newLat, newLng);
    setAddress(addr || `${newLat.toFixed(5)}, ${newLng.toFixed(5)}`);
    setLoading(false);
  }, []);

  useEffect(() => {
    if (mapObj.current || !mapDiv.current) return;

    import("leaflet").then(L => {
      // Fix broken default icons
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl:       "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl:     "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      });

      const map = L.map(mapDiv.current, {
        center:      [HINDAUN.lat, HINDAUN.lng],
        zoom:        HINDAUN.zoom,
        zoomControl: false,
      });

      // High-quality Carto Voyager tiles — shows roads, shops, labels in Hindi & English
      L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png",
        {
          attribution: '© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> © <a href="https://carto.com">CARTO</a>',
          subdomains:  "abcd",
          maxZoom:     20,
        }
      ).addTo(map);

      // Add zoom control top-right
      L.control.zoom({ position:"topright" }).addTo(map);

      // Service boundary rectangle
      L.rectangle(
        [[HINDAUN.bounds.minLat, HINDAUN.bounds.minLng],
         [HINDAUN.bounds.maxLat, HINDAUN.bounds.maxLng]],
        { color:"#22c55e", weight:2.5, fillOpacity:0.04, dashArray:"6 4" }
      ).addTo(map);

      // Custom red pin icon
      const pinIcon = L.divIcon({
        className: "",
        html: `<div style="
          width:36px;height:44px;position:relative;
          display:flex;align-items:flex-end;justify-content:center;
        ">
          <svg viewBox="0 0 36 44" fill="none" xmlns="http://www.w3.org/2000/svg" style="width:36px;height:44px;filter:drop-shadow(0 3px 6px rgba(0,0,0,0.35))">
            <path d="M18 0C9.163 0 2 7.163 2 16c0 11 16 28 16 28S34 27 34 16C34 7.163 26.837 0 18 0z" fill="#ef4444"/>
            <circle cx="18" cy="16" r="7" fill="white"/>
          </svg>
        </div>`,
        iconSize:   [36, 44],
        iconAnchor: [18, 44],
      });

      const marker = L.marker([initial?.lat || HINDAUN.lat, initial?.lng || HINDAUN.lng], {
        icon:      pinIcon,
        draggable: true,
        autoPan:   true,
      }).addTo(map);

      marker.on("dragend", e => {
        const p = e.target.getLatLng();
        onPinMove(p.lat, p.lng);
      });

      map.on("click", e => {
        marker.setLatLng(e.latlng);
        map.panTo(e.latlng);
        onPinMove(e.latlng.lat, e.latlng.lng);
      });

      mapObj.current    = map;
      markerObj.current = marker;

      // Initial reverse geocode if no address provided
      if (!initial?.line) onPinMove(HINDAUN.lat, HINDAUN.lng);
    });

    return () => {
      if (mapObj.current) { mapObj.current.remove(); mapObj.current = null; }
    };
  }, []);

  const flyTo = useCallback((newLat, newLng, zoom = 17) => {
    if (mapObj.current && markerObj.current) {
      mapObj.current.flyTo([newLat, newLng], zoom, { duration:1 });
      markerObj.current.setLatLng([newLat, newLng]);
      onPinMove(newLat, newLng);
    }
  }, [onPinMove]);

  const useGPS = () => {
    if (!navigator.geolocation) return;
    setGpsLoading(true);
    navigator.geolocation.getCurrentPosition(
      pos => {
        setGpsLoading(false);
        const { latitude, longitude } = pos.coords;
        if (!inBounds(latitude, longitude)) {
          setOutOfArea(true);
          setAddress("Your GPS location is outside Hindaun City");
          return;
        }
        flyTo(latitude, longitude, 18);
      },
      () => { setGpsLoading(false); },
      { enableHighAccuracy:true, timeout:8000 }
    );
  };

  const doSearch = async () => {
    if (!search.trim()) return;
    setLoading(true);
    const data = await searchPlaces(search);
    setResults(data);
    setLoading(false);
    if (data.length === 0) setResults([{ display_name:"No results found", noResult:true }]);
  };

  const pickResult = (r) => {
    if (r.noResult) return;
    setResults([]); setSearch("");
    flyTo(parseFloat(r.lat), parseFloat(r.lon), 18);
  };

  const pickLandmark = (lm) => {
    setTab("map");
    flyTo(lm.lat, lm.lng, 18);
  };

  const confirm = () => {
    if (outOfArea || !address || loading) return;
    onSelect({ lat, lng, line: address });
  };

  return (
    <div className="fixed inset-0 z-[100] flex flex-col bg-background" style={{ touchAction:"none" }}>
      {/* Header */}
      <div className="flex items-center gap-2 px-4 py-3 border-b border-[hsl(var(--border))] shrink-0 bg-background">
        <button onClick={onClose} className="press w-9 h-9 rounded-full bg-[hsl(var(--muted))] grid place-items-center shrink-0">
          <X className="w-4 h-4" />
        </button>
        <div className="flex-1 min-w-0">
          <h2 className="font-semibold text-sm">Select delivery location</h2>
          <p className="text-[11px] text-[hsl(var(--text-tertiary))]">Hindaun City, Rajasthan</p>
        </div>
        <button onClick={confirm} disabled={outOfArea || !address || loading}
          className="press h-9 px-4 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold disabled:opacity-40 shrink-0 flex items-center gap-1.5">
          <Check className="w-3.5 h-3.5" /> Done
        </button>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[hsl(var(--border))] shrink-0 bg-background">
        {[["map","🗺️ Map"],["landmarks","📍 Landmarks"]].map(([id,label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`flex-1 py-2.5 text-xs font-semibold transition-colors
              ${tab===id ? "border-b-2 border-[hsl(var(--accent))] text-[hsl(var(--accent))]" : "text-[hsl(var(--text-tertiary))]"}`}>
            {label}
          </button>
        ))}
      </div>

      {/* Search bar */}
      <div className="px-3 py-2 shrink-0 bg-background relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            <input
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-[hsl(var(--muted))] text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
              placeholder="Search colony, street, shop…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === "Enter" && doSearch()}
            />
          </div>
          <button onClick={doSearch} disabled={loading}
            className="press h-10 px-3 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold shrink-0">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Go"}
          </button>
          <button onClick={useGPS} disabled={gpsLoading} title="Use my GPS location"
            className="press h-10 w-10 rounded-xl bg-blue-500 text-white grid place-items-center shrink-0">
            {gpsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Navigation className="w-4 h-4" />}
          </button>
        </div>

        {/* Search results */}
        {results.length > 0 && (
          <div className="absolute left-3 right-3 top-[52px] bg-background border border-[hsl(var(--border))] rounded-2xl shadow-xl z-20 overflow-hidden max-h-56 overflow-y-auto">
            {results.map((r, i) => (
              <button key={i} onClick={() => pickResult(r)} disabled={r.noResult}
                className="w-full text-left px-4 py-3 text-sm hover:bg-[hsl(var(--muted))] border-b border-[hsl(var(--border))] last:border-0 disabled:opacity-50">
                {r.noResult ? (
                  <p className="text-[hsl(var(--text-tertiary))]">No results found</p>
                ) : (
                  <>
                    <p className="font-medium line-clamp-1">{r.display_name?.split(",")[0]}</p>
                    <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5 line-clamp-1">
                      {r.display_name?.split(",").slice(1,3).join(",")}
                    </p>
                  </>
                )}
              </button>
            ))}
            <button onClick={() => setResults([])} className="w-full py-2 text-xs text-[hsl(var(--text-tertiary))] text-center">
              Close
            </button>
          </div>
        )}
      </div>

      {/* Map */}
      <div className={`flex-1 relative ${tab === "landmarks" ? "hidden" : "block"}`}>
        <div ref={mapDiv} className="w-full h-full" />

        {/* Center instruction */}
        <div className="absolute top-2 left-0 right-0 flex justify-center pointer-events-none z-10">
          <div className="bg-white/90 backdrop-blur-sm text-xs px-3 py-1.5 rounded-full shadow text-slate-600 font-medium">
            Tap map or drag pin to set location
          </div>
        </div>
      </div>

      {/* Landmarks tab */}
      {tab === "landmarks" && (
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          <p className="text-xs text-[hsl(var(--text-tertiary))] mb-3">Quick select a well-known location</p>
          {HINDAUN.landmarks.map(lm => (
            <button key={lm.name} onClick={() => pickLandmark(lm)}
              className="press w-full flex items-center gap-3 p-3.5 rounded-2xl card-soft text-left">
              <div className="w-9 h-9 rounded-xl bg-[hsl(var(--accent-soft))] grid place-items-center shrink-0">
                <MapPin className="w-4.5 h-4.5 text-[hsl(var(--accent))]" />
              </div>
              <div>
                <p className="text-sm font-semibold">{lm.name}</p>
                <p className="text-xs text-[hsl(var(--text-tertiary))]">Hindaun City</p>
              </div>
            </button>
          ))}
        </div>
      )}

      {/* Bottom address bar */}
      <div className={`shrink-0 border-t border-[hsl(var(--border))] bg-background ${outOfArea ? "bg-red-50" : ""}`}>
        <div className="px-4 py-3 flex items-start gap-3">
          {outOfArea
            ? <AlertCircle className="w-4.5 h-4.5 text-red-500 shrink-0 mt-0.5" />
            : loading
              ? <Loader2 className="w-4.5 h-4.5 text-[hsl(var(--accent))] shrink-0 mt-0.5 animate-spin" />
              : <MapPin className="w-4.5 h-4.5 text-[hsl(var(--accent))] shrink-0 mt-0.5" />
          }
          <div className="flex-1 min-w-0">
            <p className="text-xs text-[hsl(var(--text-tertiary))] mb-0.5">
              {outOfArea ? "Outside delivery area" : loading ? "Getting address…" : "Selected address"}
            </p>
            <p className={`text-sm font-medium line-clamp-2 ${outOfArea ? "text-red-500" : ""}`}>
              {address || "Tap anywhere on the map"}
            </p>
          </div>
        </div>
        {!outOfArea && address && !loading && (
          <div className="px-4 pb-4">
            <button onClick={confirm}
              className="press w-full h-12 rounded-2xl bg-[hsl(var(--accent))] text-white font-semibold flex items-center justify-center gap-2">
              <Check className="w-4 h-4" /> Confirm this location
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
