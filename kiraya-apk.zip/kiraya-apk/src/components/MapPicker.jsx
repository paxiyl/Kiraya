/**
 * MapPicker — OpenStreetMap address picker
 * Free, no API key needed. Centered on Hindaun City, Rajasthan.
 * Uses Nominatim for reverse geocoding (address from pin drop).
 */
import React, { useState, useEffect, useRef, useCallback } from "react";
import { MapPin, Search, Loader2, X, Check } from "lucide-react";

// Hindaun City, Rajasthan coordinates
const HINDAUN_LAT = 26.7285;
const HINDAUN_LNG = 77.0350;
const HINDAUN_BOUNDS = {
  minLat: 26.68, maxLat: 26.78,
  minLng: 77.00, maxLng: 77.10,
};

function isInHindaun(lat, lng) {
  return lat >= HINDAUN_BOUNDS.minLat && lat <= HINDAUN_BOUNDS.maxLat &&
         lng >= HINDAUN_BOUNDS.minLng && lng <= HINDAUN_BOUNDS.maxLng;
}

async function reverseGeocode(lat, lng) {
  const res = await fetch(
    `https://nominatim.openstreetmap.org/reverse?lat=${lat}&lon=${lng}&format=json&addressdetails=1`,
    { headers: { "Accept-Language": "en" } }
  );
  return res.json();
}

async function searchAddress(query) {
  const res = await fetch(
    `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(query + " Hindaun Rajasthan India")}&format=json&limit=5&addressdetails=1`,
    { headers: { "Accept-Language": "en" } }
  );
  return res.json();
}

export default function MapPicker({ onSelect, onClose, initial }) {
  const mapRef       = useRef(null);
  const leafletMap   = useRef(null);
  const markerRef    = useRef(null);
  const [lat, setLat]       = useState(initial?.lat || HINDAUN_LAT);
  const [lng, setLng]       = useState(initial?.lng || HINDAUN_LNG);
  const [address, setAddress]   = useState(initial?.line || "");
  const [search, setSearch]     = useState("");
  const [results, setResults]   = useState([]);
  const [loading, setLoading]   = useState(false);
  const [outOfRange, setOutOfRange] = useState(false);

  const updateMarker = useCallback(async (newLat, newLng) => {
    setLat(newLat); setLng(newLng);
    if (!isInHindaun(newLat, newLng)) {
      setOutOfRange(true);
      setAddress("Location outside Hindaun City service area");
      return;
    }
    setOutOfRange(false);
    setLoading(true);
    try {
      const data = await reverseGeocode(newLat, newLng);
      const a = data.address;
      const line = [a.road, a.suburb, a.neighbourhood, a.village, a.town]
        .filter(Boolean).join(", ");
      setAddress(line || data.display_name?.split(",")[0] || "");
    } catch { setAddress(""); }
    finally { setLoading(false); }
  }, []);

  useEffect(() => {
    if (leafletMap.current) return;
    import("leaflet").then(L => {
      // Fix default icon paths
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon-2x.png",
        iconUrl:       "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-icon.png",
        shadowUrl:     "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/images/marker-shadow.png",
      });

      const map = L.map(mapRef.current, {
        center: [HINDAUN_LAT, HINDAUN_LNG],
        zoom: 14,
        zoomControl: true,
      });

      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "© OpenStreetMap contributors",
        maxZoom: 19,
      }).addTo(map);

      // Draw service boundary
      L.rectangle([
        [HINDAUN_BOUNDS.minLat, HINDAUN_BOUNDS.minLng],
        [HINDAUN_BOUNDS.maxLat, HINDAUN_BOUNDS.maxLng],
      ], { color: "#22c55e", weight: 2, fillOpacity: 0.05 }).addTo(map);

      const marker = L.marker([HINDAUN_LAT, HINDAUN_LNG], { draggable: true }).addTo(map);
      markerRef.current = marker;

      marker.on("dragend", (e) => {
        const { lat, lng } = e.target.getLatLng();
        updateMarker(lat, lng);
      });

      map.on("click", (e) => {
        marker.setLatLng(e.latlng);
        updateMarker(e.latlng.lat, e.latlng.lng);
      });

      leafletMap.current = map;

      // Initial geocode
      if (!initial?.line) updateMarker(HINDAUN_LAT, HINDAUN_LNG);
    });

    return () => {
      if (leafletMap.current) {
        leafletMap.current.remove();
        leafletMap.current = null;
      }
    };
  }, []);

  const doSearch = async () => {
    if (!search.trim()) return;
    setLoading(true);
    try {
      const data = await searchAddress(search);
      setResults(data.slice(0, 5));
    } catch { setResults([]); }
    finally { setLoading(false); }
  };

  const selectResult = (r) => {
    const newLat = parseFloat(r.lat);
    const newLng = parseFloat(r.lon);
    setResults([]);
    setSearch("");
    import("leaflet").then(() => {
      if (leafletMap.current && markerRef.current) {
        leafletMap.current.setView([newLat, newLng], 16);
        markerRef.current.setLatLng([newLat, newLng]);
      }
    });
    updateMarker(newLat, newLng);
  };

  const confirm = () => {
    if (outOfRange || !address) return;
    onSelect({ lat, lng, line: address });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-background">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[hsl(var(--border))] shrink-0">
        <button onClick={onClose} className="press w-9 h-9 rounded-full bg-[hsl(var(--muted))] grid place-items-center">
          <X className="w-4 h-4" />
        </button>
        <h2 className="font-semibold text-sm flex-1">Choose delivery location</h2>
        <button onClick={confirm} disabled={outOfRange || !address}
          className="press h-9 px-4 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-semibold disabled:opacity-40 flex items-center gap-1.5">
          <Check className="w-3.5 h-3.5" /> Confirm
        </button>
      </div>

      {/* Search bar */}
      <div className="px-4 py-2 shrink-0 relative">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[hsl(var(--text-tertiary))]" />
            <input
              className="w-full h-10 pl-9 pr-3 rounded-xl border border-[hsl(var(--border))] bg-background text-sm focus:outline-none focus:ring-2 focus:ring-[hsl(var(--accent))]"
              placeholder="Search area, street, landmark…"
              value={search}
              onChange={e => setSearch(e.target.value)}
              onKeyDown={e => e.key === "Enter" && doSearch()}
            />
          </div>
          <button onClick={doSearch} disabled={loading}
            className="press h-10 px-3 rounded-xl bg-[hsl(var(--accent))] text-white text-sm font-medium">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Go"}
          </button>
        </div>

        {/* Search results dropdown */}
        {results.length > 0 && (
          <div className="absolute left-4 right-4 top-14 bg-background border border-[hsl(var(--border))] rounded-2xl shadow-lg z-10 overflow-hidden">
            {results.map((r, i) => (
              <button key={i} onClick={() => selectResult(r)}
                className="press w-full text-left px-4 py-3 text-sm hover:bg-[hsl(var(--muted))] border-b border-[hsl(var(--border))] last:border-0">
                <p className="font-medium line-clamp-1">{r.display_name?.split(",")[0]}</p>
                <p className="text-xs text-[hsl(var(--text-tertiary))] line-clamp-1 mt-0.5">{r.display_name}</p>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Map */}
      <div className="flex-1 relative">
        <div ref={mapRef} className="w-full h-full" />
        {/* Center crosshair hint */}
        <div className="absolute bottom-4 left-0 right-0 flex justify-center pointer-events-none">
          <div className={`px-3 py-1.5 rounded-full text-xs font-medium shadow-lg ${outOfRange ? "bg-red-500 text-white" : "bg-white text-slate-700"}`}>
            {loading ? "Getting address…" : outOfRange ? "Outside Hindaun City area" : address || "Tap map or drag pin to set location"}
          </div>
        </div>
      </div>

      {/* Selected address bar */}
      {address && !outOfRange && (
        <div className="px-4 py-3 border-t border-[hsl(var(--border))] shrink-0 flex items-center gap-3">
          <MapPin className="w-4 h-4 text-[hsl(var(--accent))] shrink-0" />
          <p className="text-sm flex-1 line-clamp-2">{address}</p>
        </div>
      )}
    </div>
  );
}
