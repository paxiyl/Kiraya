import React, { createContext, useContext, useMemo, useState, useCallback } from "react";

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

const PLATFORM_FEE = 5;
export const FREE_DELIVERY_MIN = 499;
const TAX_RATE = 0.05;

export function CartProvider({ children }) {
  const [items, setItems] = useState({});   // { productId: { product, qty } }
  const [coupon, setCoupon] = useState(null);
  // Set when the user adds an item from a different store than the cart holds.
  const [conflict, setConflict] = useState(null); // { product, qty } | null

  const add = useCallback((product, qty = 1) => {
    setItems(prev => ({
      ...prev,
      [product.id]: {
        product,
        qty: (prev[product.id]?.qty || 0) + qty,
      },
    }));
  }, []);

  const setQty = useCallback((productId, qty) => {
    setItems(prev => {
      const next = { ...prev };
      if (qty <= 0) delete next[productId];
      else next[productId] = { ...next[productId], qty };
      return next;
    });
  }, []);

  const remove = useCallback((productId) => {
    setItems(prev => { const next = { ...prev }; delete next[productId]; return next; });
  }, []);

  const clear = useCallback(() => { setItems({}); setCoupon(null); }, []);
  const qtyOf = useCallback((id) => items[id]?.qty || 0, [items]);

  const rows = useMemo(() => Object.values(items), [items]);
  const subtotal = useMemo(() => rows.reduce((s, { product, qty }) => s + product.price * qty, 0), [rows]);
  const storeDeliveryFee = useMemo(() => {
    const store = rows[0]?.product?.storeDeliveryFee ?? 29;
    return subtotal >= FREE_DELIVERY_MIN ? 0 : store;
  }, [rows, subtotal]);
  const taxes = useMemo(() => Math.round(subtotal * TAX_RATE), [subtotal]);
  const discount = useMemo(() => {
    if (!coupon) return 0;
    if (coupon.type === "flat") return coupon.min <= subtotal ? coupon.value : 0;
    if (coupon.type === "pct") return Math.min(Math.round(subtotal * coupon.value / 100), coupon.max || Infinity);
    if (coupon.type === "delivery") return subtotal >= coupon.min ? storeDeliveryFee : 0;
    return 0;
  }, [coupon, subtotal, storeDeliveryFee]);
  const total = useMemo(() => Math.max(0, subtotal + storeDeliveryFee + taxes + PLATFORM_FEE - discount), [subtotal, storeDeliveryFee, taxes, discount]);
  const count = useMemo(() => rows.reduce((s, { qty }) => s + qty, 0), [rows]);
  const storeId = useMemo(() => rows[0]?.product?.storeId || null, [rows]);
  const storeName = useMemo(() => rows[0]?.product?.storeName || null, [rows]);
  // Savings vs MRP (only for items that carry an mrp).
  const savings = useMemo(() => rows.reduce((s, { product, qty }) =>
    s + Math.max(0, (Number(product.mrp) || 0) - product.price) * qty, 0), [rows]);

  // Orders are created with a single store_id, so a cart must hold one store.
  // requestAdd() adds directly, or asks before replacing a cart from another store.
  const requestAdd = useCallback((product, qty = 1) => {
    const current = Object.values(items)[0]?.product?.storeId;
    if (current && product.storeId && current !== product.storeId) {
      setConflict({ product, qty });
      return false;
    }
    add(product, qty);
    return true;
  }, [items, add]);

  const resolveConflict = useCallback((replace) => {
    if (replace && conflict) {
      setItems({ [conflict.product.id]: { product: conflict.product, qty: conflict.qty } });
      setCoupon(null);
    }
    setConflict(null);
  }, [conflict]);

  return (
    <CartContext.Provider value={{ items, rows, add, setQty, remove, clear, qtyOf, coupon, setCoupon, subtotal, deliveryFee: storeDeliveryFee, taxes, platformFee: PLATFORM_FEE, discount, total, count, storeId,
      storeName, savings, requestAdd, conflict, resolveConflict }}>
      {children}
    </CartContext.Provider>
  );
}
