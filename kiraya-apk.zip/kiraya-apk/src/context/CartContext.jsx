import React, { createContext, useContext, useMemo, useState, useCallback } from "react";

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

const PLATFORM_FEE = 5;
const TAX_RATE = 0.05;

export function CartProvider({ children }) {
  const [items, setItems] = useState({});   // { productId: { product, qty } }
  const [coupon, setCoupon] = useState(null);

  const add = useCallback((product, qty = 1) => {
    setItems(prev => ({
      ...prev,
      [product.id]: {
        product,
        qty: (prev[product.id]?.qty || 0) + qty,
      },
    }));
  }, []);

  const setQty = useCallback((productId, qty) => {
    setItems(prev => {
      const next = { ...prev };
      if (qty <= 0) delete next[productId];
      else next[productId] = { ...next[productId], qty };
      return next;
    });
  }, []);

  const remove = useCallback((productId) => {
    setItems(prev => { const next = { ...prev }; delete next[productId]; return next; });
  }, []);

  const clear = useCallback(() => { setItems({}); setCoupon(null); }, []);
  const qtyOf = useCallback((id) => items[id]?.qty || 0, [items]);

  const rows = useMemo(() => Object.values(items), [items]);
  const subtotal = useMemo(() => rows.reduce((s, { product, qty }) => s + product.price * qty, 0), [rows]);
  const storeDeliveryFee = useMemo(() => {
    const store = rows[0]?.product?.storeDeliveryFee ?? 29;
    return subtotal >= 499 ? 0 : store;
  }, [rows, subtotal]);
  const taxes = useMemo(() => Math.round(subtotal * TAX_RATE), [subtotal]);
  const discount = useMemo(() => {
    if (!coupon) return 0;
    if (coupon.type === "flat") return coupon.min <= subtotal ? coupon.value : 0;
    if (coupon.type === "pct") return Math.min(Math.round(subtotal * coupon.value / 100), coupon.max || Infinity);
    if (coupon.type === "delivery") return subtotal >= coupon.min ? storeDeliveryFee : 0;
    return 0;
  }, [coupon, subtotal, storeDeliveryFee]);
  const total = useMemo(() => Math.max(0, subtotal + storeDeliveryFee + taxes + PLATFORM_FEE - discount), [subtotal, storeDeliveryFee, taxes, discount]);
  const count = useMemo(() => rows.reduce((s, { qty }) => s + qty, 0), [rows]);
  const storeId = useMemo(() => rows[0]?.product?.storeId || null, [rows]);

  return (
    <CartContext.Provider value={{ items, rows, add, setQty, remove, clear, qtyOf, coupon, setCoupon, subtotal, deliveryFee: storeDeliveryFee, taxes, platformFee: PLATFORM_FEE, discount, total, count, storeId }}>
      {children}
    </CartContext.Provider>
  );
}
