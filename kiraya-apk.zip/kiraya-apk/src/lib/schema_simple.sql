-- Run this entire block in Supabase SQL Editor
-- This creates all tables with RLS disabled from the start

create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text,
  display_name text,
  phone text,
  role text default 'customer',
  vehicle_type text,
  vehicle_number text,
  address jsonb default '{}',
  avatar_url text,
  bio text,
  agreed_terms boolean default false,
  profile_complete boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table profiles disable row level security;

create table if not exists stores (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid references profiles(id) on delete cascade,
  name text not null,
  description text,
  category text default 'food',
  address text,
  phone text,
  image_url text,
  delivery_fee numeric default 29,
  eta text default '30-45 min',
  open boolean default false,
  approved boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table stores disable row level security;

create table if not exists products (
  id uuid primary key default gen_random_uuid(),
  store_id uuid references stores(id) on delete cascade,
  store_name text,
  store_delivery_fee numeric default 29,
  name text not null,
  description text,
  price numeric not null,
  mrp numeric,
  stock integer default 0,
  category text default 'food',
  image_url text,
  available boolean default true,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
alter table products disable row level security;

create table if not exists orders (
  id uuid primary key default gen_random_uuid(),
  customer_id uuid references profiles(id),
  customer_name text,
  store_id uuid references stores(id),
  delivery_partner_id uuid references profiles(id),
  items jsonb default '[]',
  subtotal numeric default 0,
  delivery_fee numeric default 0,
  taxes numeric default 0,
  platform_fee numeric default 0,
  discount numeric default 0,
  total numeric default 0,
  address jsonb default '{}',
  payment_method text default 'cod',
  status text default 'PENDING',
  rating integer,
  review text,
  created_at timestamptz default now(),
  updated_at timestamptz default now(),
  accepted_at timestamptz,
  delivered_at timestamptz
);
alter table orders disable row level security;

create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  title text,
  body text,
  type text default 'info',
  read boolean default false,
  created_at timestamptz default now()
);
alter table notifications disable row level security;

create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  store_id uuid references stores(id) on delete cascade,
  customer_id uuid references profiles(id) on delete cascade,
  customer_name text,
  order_id uuid references orders(id) on delete cascade,
  rating integer check (rating >= 1 and rating <= 5),
  comment text,
  created_at timestamptz default now()
);
alter table reviews disable row level security;

select 'All tables created successfully!' as result;
