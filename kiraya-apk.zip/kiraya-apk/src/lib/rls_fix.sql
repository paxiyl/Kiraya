-- Run this in Supabase SQL Editor to fix all permission issues

-- Drop all existing policies first
drop policy if exists "users can view own profile" on profiles;
drop policy if exists "users can insert own profile" on profiles;
drop policy if exists "users can update own profile" on profiles;
drop policy if exists "public can view approved stores" on stores;
drop policy if exists "owners manage own store" on stores;
drop policy if exists "admin all stores" on stores;
drop policy if exists "public can view products" on products;
drop policy if exists "store owners manage products" on products;
drop policy if exists "customers view own orders" on orders;
drop policy if exists "customers insert orders" on orders;
drop policy if exists "store owners view store orders" on orders;
drop policy if exists "delivery partners view assigned" on orders;
drop policy if exists "delivery partners view available" on orders;
drop policy if exists "auth users update orders" on orders;
drop policy if exists "admin all orders" on orders;
drop policy if exists "users view own notifications" on notifications;
drop policy if exists "users update own notifications" on notifications;

-- PROFILES: authenticated users can do anything to their own row
create policy "profiles_select" on profiles for select to authenticated using (true);
create policy "profiles_insert" on profiles for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update" on profiles for update to authenticated using (auth.uid() = id);

-- STORES: public read approved, owner full access
create policy "stores_select" on stores for select using (approved = true or auth.uid() = owner_id);
create policy "stores_insert" on stores for insert to authenticated with check (auth.uid() = owner_id);
create policy "stores_update" on stores for update to authenticated using (auth.uid() = owner_id);
create policy "stores_delete" on stores for delete to authenticated using (auth.uid() = owner_id);

-- PRODUCTS: public read, store owner write
create policy "products_select" on products for select using (true);
create policy "products_insert" on products for insert to authenticated with check (
  store_id in (select id from stores where owner_id = auth.uid())
);
create policy "products_update" on products for update to authenticated using (
  store_id in (select id from stores where owner_id = auth.uid())
);
create policy "products_delete" on products for delete to authenticated using (
  store_id in (select id from stores where owner_id = auth.uid())
);

-- ORDERS: open policy for authenticated users (simplest, most reliable)
create policy "orders_select" on orders for select to authenticated using (true);
create policy "orders_insert" on orders for insert to authenticated with check (auth.uid() = customer_id);
create policy "orders_update" on orders for update to authenticated using (true);

-- NOTIFICATIONS
create policy "notifications_select" on notifications for select to authenticated using (auth.uid() = user_id);
create policy "notifications_insert" on notifications for insert to authenticated with check (true);
create policy "notifications_update" on notifications for update to authenticated using (auth.uid() = user_id);
