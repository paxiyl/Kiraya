-- ============================================================
-- NUCLEAR OPTION — completely disable RLS on all tables
-- This is the most reliable fix for permission denied errors
-- Run this in Supabase SQL Editor
-- ============================================================

-- Disable RLS on every table (no policies needed at all)
alter table profiles  disable row level security;
alter table stores    disable row level security;
alter table products  disable row level security;
alter table orders    disable row level security;
alter table notifications disable row level security;

-- Drop every single existing policy to clean slate
do $$ declare r record;
begin
  for r in
    select policyname, tablename
    from pg_policies
    where schemaname = 'public'
      and tablename in ('profiles','stores','products','orders','notifications','reviews')
  loop
    execute format('drop policy if exists %I on %I', r.policyname, r.tablename);
  end loop;
end $$;

-- Reviews table (create if not exists)
create table if not exists reviews (
  id            uuid primary key default gen_random_uuid(),
  store_id      uuid references stores(id) on delete cascade,
  customer_id   uuid references profiles(id) on delete cascade,
  customer_name text,
  order_id      uuid references orders(id) on delete cascade,
  rating        integer check (rating >= 1 and rating <= 5),
  comment       text,
  created_at    timestamptz default now()
);
alter table reviews disable row level security;

-- Add rating/review columns to orders
alter table orders add column if not exists rating integer check (rating >= 1 and rating <= 5);
alter table orders add column if not exists review text;

-- Realtime (ignore errors if already added)
do $$ begin
  alter publication supabase_realtime add table orders;
exception when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table notifications;
exception when others then null; end $$;
do $$ begin
  alter publication supabase_realtime add table reviews;
exception when others then null; end $$;

select 'Done! RLS disabled on all tables.' as result;
