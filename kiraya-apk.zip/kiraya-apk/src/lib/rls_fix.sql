-- ============================================================
-- COMPLETE RLS RESET — run this in Supabase SQL Editor
-- ============================================================

-- 1. Disable RLS entirely on all tables (simplest fix)
alter table profiles disable row level security;
alter table stores disable row level security;
alter table products disable row level security;
alter table orders disable row level security;
alter table notifications disable row level security;

-- 2. Drop ALL existing policies
do $$ declare
  r record;
begin
  for r in select schemaname, tablename, policyname
    from pg_policies
    where schemaname = 'public'
      and tablename in ('profiles','stores','products','orders','notifications')
  loop
    execute format('drop policy if exists %I on %I.%I', r.policyname, r.schemaname, r.tablename);
  end loop;
end $$;

-- 3. Re-enable RLS
alter table profiles enable row level security;
alter table stores enable row level security;
alter table products enable row level security;
alter table orders enable row level security;
alter table notifications enable row level security;

-- 4. Create simple, working policies

-- PROFILES: any authenticated user can read all profiles,
-- only owner can insert/update their own
create policy "profiles_read"   on profiles for select to authenticated using (true);
create policy "profiles_insert" on profiles for insert to authenticated with check (auth.uid() = id);
create policy "profiles_update" on profiles for update to authenticated using (auth.uid() = id);

-- STORES: anyone can read approved stores; authenticated can insert/update their own
create policy "stores_read_approved" on stores for select using (true);
create policy "stores_insert"        on stores for insert to authenticated with check (auth.uid() = owner_id);
create policy "stores_update"        on stores for update to authenticated using (auth.uid() = owner_id);
create policy "stores_delete"        on stores for delete to authenticated using (auth.uid() = owner_id);

-- PRODUCTS: public read; store owners write
create policy "products_read"   on products for select using (true);
create policy "products_insert" on products for insert to authenticated with check (
  store_id in (select id from stores where owner_id = auth.uid())
);
create policy "products_update" on products for update to authenticated using (
  store_id in (select id from stores where owner_id = auth.uid())
);
create policy "products_delete" on products for delete to authenticated using (
  store_id in (select id from stores where owner_id = auth.uid())
);

-- ORDERS: authenticated users full access (simplest, most reliable for delivery app)
create policy "orders_read"   on orders for select to authenticated using (true);
create policy "orders_insert" on orders for insert to authenticated with check (auth.uid() = customer_id);
create policy "orders_update" on orders for update to authenticated using (true);
create policy "orders_delete" on orders for delete to authenticated using (true);

-- NOTIFICATIONS: owner access
create policy "notif_read"   on notifications for select to authenticated using (auth.uid() = user_id);
create policy "notif_insert" on notifications for insert to authenticated with check (true);
create policy "notif_update" on notifications for update to authenticated using (auth.uid() = user_id);

-- 5. Verify
select tablename, policyname, cmd from pg_policies
where schemaname = 'public'
order by tablename, policyname;

-- ============================================================
-- ADDITIONAL TABLES (run after main schema)
-- ============================================================

-- Reviews table
create table if not exists reviews (
  id           uuid primary key default gen_random_uuid(),
  store_id     uuid references stores(id) on delete cascade,
  customer_id  uuid references profiles(id) on delete cascade,
  customer_name text,
  order_id     uuid references orders(id) on delete cascade,
  rating       integer check (rating >= 1 and rating <= 5),
  comment      text,
  created_at   timestamptz default now()
);

alter table reviews enable row level security;
create policy "reviews_read"   on reviews for select using (true);
create policy "reviews_insert" on reviews for insert to authenticated with check (auth.uid() = customer_id);
create policy "reviews_update" on reviews for update to authenticated using (auth.uid() = customer_id);

-- Add rating columns to orders if not exists
alter table orders add column if not exists rating  integer check (rating >= 1 and rating <= 5);
alter table orders add column if not exists review  text;

-- Add reviews to realtime
alter publication supabase_realtime add table reviews;
