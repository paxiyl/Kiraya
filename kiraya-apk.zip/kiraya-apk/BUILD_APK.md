# Kiraya — Build APK Guide

This project is a React + Vite app wrapped with **Capacitor** to produce an Android APK.

---

## Prerequisites

Install these before anything else:

| Tool | Version | Download |
|------|---------|----------|
| Node.js | 18+ | https://nodejs.org |
| Java JDK | 17 or 21 | https://adoptium.net |
| Android Studio | Latest | https://developer.android.com/studio |

After installing Android Studio, open it and:
1. Go to **SDK Manager** → install **Android SDK** (API 34 recommended)
2. Go to **SDK Manager** → **SDK Tools** → install **Android SDK Build-Tools**
3. Set `ANDROID_HOME` environment variable to your SDK path
   - Windows: `C:\Users\<you>\AppData\Local\Android\Sdk`
   - Mac/Linux: `~/Library/Android/sdk` or `~/Android/Sdk`

---

## Step 1 — Install dependencies

```bash
cd kiraya-apk
npm install
```

---

## Step 2 — Add the Android platform

```bash
npx cap add android
```

This creates the `android/` folder (a full Gradle project).

---

## Step 3 — Build the web app

```bash
npm run build
```

This creates `dist/` — the compiled React app.

---

## Step 4 — Sync web build into Android

```bash
npx cap sync android
```

This copies `dist/` into the Android project and installs any Capacitor plugins.

---

## Step 5 — Build the APK

### Option A — Debug APK (fastest, no signing needed)

```bash
cd android
./gradlew assembleDebug
```

Your APK will be at:
```
android/app/build/outputs/apk/debug/app-debug.apk
```

Install on a device:
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

### Option B — Release APK (for distribution)

**Generate a keystore** (one-time, keep this file safe):
```bash
keytool -genkey -v -keystore kiraya.keystore -alias kiraya \
  -keyalg RSA -keysize 2048 -validity 10000
```

**Build signed release APK:**
```bash
cd android
./gradlew assembleRelease \
  -Pandroid.injected.signing.store.file=../../kiraya.keystore \
  -Pandroid.injected.signing.store.password=YOUR_STORE_PASSWORD \
  -Pandroid.injected.signing.key.alias=kiraya \
  -Pandroid.injected.signing.key.password=YOUR_KEY_PASSWORD
```

APK location:
```
android/app/build/outputs/apk/release/app-release.apk
```

---

## One-liner shortcut

After Step 2, you can do Steps 3+4+5 together:

```bash
npm run cap:build
cd android && ./gradlew assembleDebug
```

---

## Open in Android Studio (optional)

To use the GUI, run and debug on an emulator:

```bash
npx cap open android
```

Then press the green **Run** button in Android Studio.

---

## Connect your backend

The app currently uses mock data (`USE_MOCK_DATA: true` in `src/lib/appConfig.js`).

To connect to Firebase:
1. Create a Firebase project at https://console.firebase.google.com
2. Enable Authentication and Firestore
3. Copy your config into `src/lib/appConfig.js` under the `firebase` key
4. Set `USE_MOCK_DATA: false`
5. Rebuild and re-sync: `npm run cap:build`

---

## Troubleshooting

**`ANDROID_HOME` not set** — add to your shell profile:
```bash
export ANDROID_HOME=~/Android/Sdk
export PATH=$PATH:$ANDROID_HOME/tools:$ANDROID_HOME/platform-tools
```

**Gradle build fails with Java error** — make sure JAVA_HOME points to JDK 17 or 21, not JRE.

**White screen on device** — this usually means the backend isn't connected. Check that `USE_MOCK_DATA: true` is set in `appConfig.js` for local testing.

**`adb` not found** — install Android platform-tools and add to PATH, or use Android Studio's built-in terminal.
