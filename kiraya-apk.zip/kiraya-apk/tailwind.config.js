/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: ["./index.html", "./src/**/*.{ts,tsx,js,jsx}"],
  theme: {
    extend: {
      opacity: Object.fromEntries(Array.from({ length: 101 }, (_, i) => [i, `${i / 100}`])),
      // 4.5 is used ~46 times across the app (w-4.5 / h-4.5) but is not a Tailwind v3 default.
      spacing: { 4.5: "1.125rem", 13: "3.25rem", 15: "3.75rem", 18: "4.5rem" },
      borderRadius: {
        lg: "var(--radius)",
        md: "calc(var(--radius) - 2px)",
        sm: "calc(var(--radius) - 4px)",
        control: "12px",   // inputs, buttons
        card: "16px",      // normal cards
        feature: "22px",   // featured modules
      },
      fontSize: {
        meta:      ["11px", { lineHeight: "14px" }],
        caption:   ["12px", { lineHeight: "16px" }],
        secondary: ["13px", { lineHeight: "18px" }],
        body:      ["14px", { lineHeight: "20px" }],
        card:      ["15px", { lineHeight: "20px" }],
        section:   ["19px", { lineHeight: "24px", letterSpacing: "-0.012em" }],
        title:     ["26px", { lineHeight: "32px", letterSpacing: "-0.02em" }],
        display:   ["34px", { lineHeight: "38px", letterSpacing: "-0.025em" }],
      },
      colors: {
        background: "hsl(var(--background) / <alpha-value>)",
        foreground: "hsl(var(--foreground) / <alpha-value>)",
        card: { DEFAULT: "hsl(var(--card) / <alpha-value>)", foreground: "hsl(var(--card-foreground) / <alpha-value>)" },
        popover: { DEFAULT: "hsl(var(--popover) / <alpha-value>)", foreground: "hsl(var(--popover-foreground) / <alpha-value>)" },
        primary: { DEFAULT: "hsl(var(--primary) / <alpha-value>)", foreground: "hsl(var(--primary-foreground) / <alpha-value>)" },
        secondary: { DEFAULT: "hsl(var(--secondary) / <alpha-value>)", foreground: "hsl(var(--secondary-foreground) / <alpha-value>)" },
        muted: { DEFAULT: "hsl(var(--muted) / <alpha-value>)", foreground: "hsl(var(--muted-foreground) / <alpha-value>)" },
        accent: { DEFAULT: "hsl(var(--accent) / <alpha-value>)", foreground: "hsl(var(--accent-foreground) / <alpha-value>)" },
        destructive: { DEFAULT: "hsl(var(--destructive) / <alpha-value>)", foreground: "hsl(var(--destructive-foreground) / <alpha-value>)" },
        border: "hsl(var(--border) / <alpha-value>)",
        input: "hsl(var(--input) / <alpha-value>)",
        ring: "hsl(var(--ring) / <alpha-value>)",
        // OnlineMall semantic tokens
        brand:   { DEFAULT: "hsl(var(--accent) / <alpha-value>)", soft: "hsl(var(--accent-soft) / <alpha-value>)", deep: "hsl(var(--accent-deep) / <alpha-value>)" },
        ink:     { DEFAULT: "hsl(var(--text-primary) / <alpha-value>)", 2: "hsl(var(--text-secondary) / <alpha-value>)", 3: "hsl(var(--text-tertiary) / <alpha-value>)" },
        canvas:  "hsl(var(--background) / <alpha-value>)",
        surface: { DEFAULT: "hsl(var(--surface) / <alpha-value>)", 2: "hsl(var(--surface-2) / <alpha-value>)" },
        line:    "hsl(var(--border) / <alpha-value>)",
        offer:   { DEFAULT: "hsl(var(--offer) / <alpha-value>)", soft: "hsl(var(--offer-soft) / <alpha-value>)", ink: "hsl(var(--offer-ink) / <alpha-value>)" },
        danger:  { DEFAULT: "hsl(var(--danger) / <alpha-value>)", soft: "hsl(var(--danger-soft) / <alpha-value>)" },
        info:    { DEFAULT: "hsl(var(--info) / <alpha-value>)", soft: "hsl(var(--info-soft) / <alpha-value>)" },
        chart: {
          1: "hsl(var(--chart-1) / <alpha-value>)", 2: "hsl(var(--chart-2) / <alpha-value>)", 3: "hsl(var(--chart-3) / <alpha-value>)",
          4: "hsl(var(--chart-4) / <alpha-value>)", 5: "hsl(var(--chart-5) / <alpha-value>)",
        },
        sidebar: {
          DEFAULT: "hsl(var(--sidebar-background) / <alpha-value>)",
          foreground: "hsl(var(--sidebar-foreground) / <alpha-value>)",
          primary: "hsl(var(--sidebar-primary) / <alpha-value>)",
          "primary-foreground": "hsl(var(--sidebar-primary-foreground) / <alpha-value>)",
          accent: "hsl(var(--sidebar-accent) / <alpha-value>)",
          "accent-foreground": "hsl(var(--sidebar-accent-foreground) / <alpha-value>)",
          border: "hsl(var(--sidebar-border) / <alpha-value>)",
          ring: "hsl(var(--sidebar-ring) / <alpha-value>)",
        },
      },
      boxShadow: {
        hairline: "0 0 0 1px hsl(var(--border))",
        lift: "0 1px 2px rgba(24,32,28,0.06), 0 2px 6px rgba(24,32,28,0.04)",
        float: "0 8px 24px -8px rgba(24,32,28,0.28)",
      },
      fontFamily: {
        heading: ["var(--font-heading)"],
        body: ["var(--font-body)"],
        display: ["var(--font-display)"],
        mono: ["var(--font-mono)"],
      },
      keyframes: {
        "accordion-down": { from: { height: "0" }, to: { height: "var(--radix-accordion-content-height)" } },
        "accordion-up": { from: { height: "var(--radix-accordion-content-height)" }, to: { height: "0" } },
      },
      animation: {
        "accordion-down": "accordion-down 0.2s ease-out",
        "accordion-up": "accordion-up 0.2s ease-out",
      },
    },
  },
  plugins: [require("tailwindcss-animate")],
};
