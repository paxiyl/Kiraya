import React, { createContext, useContext, useMemo, useState, useCallback } from "react";
import { APP_CONFIG } from "@/lib/appConfig";

const CartContext = createContext(null);
export const useCart = () => useContext(CartContext);

const PLATFORM_FEE = APP_CONFIG.tax.platformFee;
const TAX_RATE = APP_CONFIG.tax.gstRate;

export function CartProvider({ children }) {
  // items: { [productId]: { product, qty } }
  const [items, setItems] = useState({});
  const [coupon, setCoupon] = useState(null);

  const add = useCallback((product, qty = 1) => {
    setItems((prev) => {
      const existing = prev[product.id];
      return {
        ...prev,
        [product.id]: {
          product,
          qty: (existing?.qty || 0) + qty,
        },
      };
    });
  }, []);

  const setQty = useCallback((productId, qty, product) => {
    setItems((prev) => {
      const next = { ...prev };
      if (qty <= 0) {
        delete next[productId];
      } else {
        next[productId] = {
          product: product || next[productId]?.product,
          qty,
        };
      }
      return next;
    });
  }, []);

  const remove = useCallback((productId) => {
    setItems((prev) => {
      const next = { ...prev };
      delete next[productId];
      return next;
    });
  }, []);

  const clear = useCallback(() => {
    setItems({});
    setCoupon(null);
  }, []);

  const qtyOf = useCallback((id) => items[id]?.qty || 0, [items]);

  const detailed = useMemo(() => {
    const rows = Object.entries(items)
      .map(([id, { product, qty }]) => {
        return product ? { product, qty, lineTotal: product.price * qty } : null;
      })
      .filter(Boolean);

    // Group by store
    const byStore = rows.reduce((acc, r) => {
      const storeId = r.product.storeId;
      if (!acc[storeId]) {
        acc[storeId] = {
          storeId,
          storeName: r.product.storeName,
          items: [],
        };
      }
      acc[storeId].items.push(r);
      return acc;
    }, {});

    return { rows, byStore };
  }, [items]);

  const subtotal = useMemo(
    () => detailed.rows.reduce((s, r) => s + r.lineTotal, 0),
    [detailed]
  );

  const deliveryFee = useMemo(() => {
    if (subtotal === 0) return 0;
    const storeFees = Object.values(detailed.byStore).map((store) => {
      const storeSub = store.items.reduce((s, r) => s + r.lineTotal, 0);
      // Free delivery over minimum order amount
      return storeSub >= APP_CONFIG.delivery.freeDeliveryMinOrder
        ? 0
        : APP_CONFIG.delivery.defaultDeliveryFee;
    });
    return storeFees.reduce((s, f) => s + f, 0);
  }, [subtotal, detailed]);

  const discount = useMemo(() => {
    if (!coupon) return 0;
    if (subtotal < coupon.min) return 0;
    if (coupon.type === "flat") return coupon.value;
    if (coupon.type === "pct")
      return Math.min(
        Math.round((subtotal * coupon.value) / 100),
        coupon.max || Infinity
      );
    if (coupon.type === "delivery") return deliveryFee;
    return 0;
  }, [coupon, subtotal, deliveryFee]);

  const taxes = useMemo(
    () => Math.round((subtotal - discount) * TAX_RATE),
    [subtotal, discount]
  );

  const total = Math.max(
    0,
    subtotal + deliveryFee + PLATFORM_FEE + taxes - (coupon?.type === "delivery" ? 0 : discount)
  );

  const count = Object.values(items).reduce((s, { qty }) => s + qty, 0);

  const value = {
    items,
    add,
    setQty,
    remove,
    clear,
    qtyOf,
    rows: detailed.rows,
    byStore: detailed.byStore,
    subtotal,
    deliveryFee,
    discount,
    taxes,
    platformFee: PLATFORM_FEE,
    total,
    count,
    coupon,
    applyCoupon: setCoupon,
    removeCoupon: () => setCoupon(null),
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}
