import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from '@/lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from '@/components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import Login from '@/pages/auth/Login';
import Register from '@/pages/auth/Register';
import ForgotPassword from '@/pages/auth/ForgotPassword';
import ResetPassword from '@/pages/auth/ResetPassword';
import CustomerLayout from '@/components/customer/CustomerLayout';
import Home from '@/pages/customer/Home';
import Explore from '@/pages/customer/Explore';
import ProductDetail from '@/pages/customer/ProductDetail';
import StoreDetail from '@/pages/customer/StoreDetail';
import Cart from '@/pages/customer/Cart';
import Checkout from '@/pages/customer/Checkout';
import Orders from '@/pages/customer/Orders';
import OrderTracking from '@/pages/customer/OrderTracking';
import Profile from '@/pages/customer/Profile';
import Notifications from '@/pages/customer/Notifications';
import RoleRoute from '@/components/RoleRoute';
import AdminLayout from '@/components/admin/AdminLayout';
import StoreLayout from '@/components/store/StoreLayout';
import DeliveryLayout from '@/components/delivery/DeliveryLayout';
import AdminDashboard from '@/pages/admin/Dashboard';
import AdminOrders from '@/pages/admin/Orders';
import AdminStores from '@/pages/admin/Stores';
import AdminCustomers from '@/pages/admin/Customers';
import AdminDelivery from '@/pages/admin/Delivery';
import AdminPayments from '@/pages/admin/Payments';
import AdminAnalytics from '@/pages/admin/Analytics';
import AdminSettings from '@/pages/admin/Settings';
import StoreDashboard from '@/pages/store/Dashboard';
import StoreOrders from '@/pages/store/Orders';
import StoreProducts from '@/pages/store/Products';
import StoreInventory from '@/pages/store/Inventory';
import StoreEarnings from '@/pages/store/Earnings';
import StoreReviews from '@/pages/store/Reviews';
import StoreSettings from '@/pages/store/Settings';
import DeliveryHome from '@/pages/delivery/Home';
import ActiveDelivery from '@/pages/delivery/ActiveDelivery';
import DeliveryEarnings from '@/pages/delivery/Earnings';
import DeliveryProfile from '@/pages/delivery/Profile';

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<CustomerLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/product/:id" element={<ProductDetail />} />
          <Route path="/store/:id" element={<StoreDetail />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/orders" element={<Orders />} />
          <Route path="/orders/:id" element={<OrderTracking />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/profile" element={<Profile />} />
        </Route>
        <Route element={<RoleRoute allow={['admin']} />}>
          <Route element={<AdminLayout />}>
            <Route path="/admin" element={<AdminDashboard />} />
            <Route path="/admin/orders" element={<AdminOrders />} />
            <Route path="/admin/stores" element={<AdminStores />} />
            <Route path="/admin/customers" element={<AdminCustomers />} />
            <Route path="/admin/delivery" element={<AdminDelivery />} />
            <Route path="/admin/payments" element={<AdminPayments />} />
            <Route path="/admin/analytics" element={<AdminAnalytics />} />
            <Route path="/admin/settings" element={<AdminSettings />} />
          </Route>
        </Route>
        <Route element={<RoleRoute allow={['admin', 'store_owner', 'manager', 'staff']} />}>
          <Route element={<StoreLayout />}>
            <Route path="/store" element={<StoreDashboard />} />
            <Route path="/store/orders" element={<StoreOrders />} />
            <Route path="/store/products" element={<StoreProducts />} />
            <Route path="/store/inventory" element={<StoreInventory />} />
            <Route path="/store/earnings" element={<StoreEarnings />} />
            <Route path="/store/reviews" element={<StoreReviews />} />
            <Route path="/store/settings" element={<StoreSettings />} />
          </Route>
        </Route>
        <Route element={<RoleRoute allow={['admin', 'delivery_partner']} />}>
          <Route element={<DeliveryLayout />}>
            <Route path="/delivery" element={<DeliveryHome />} />
            <Route path="/delivery/active" element={<ActiveDelivery />} />
            <Route path="/delivery/earnings" element={<DeliveryEarnings />} />
            <Route path="/delivery/profile" element={<DeliveryProfile />} />
          </Route>
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {
  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App
