import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getOrdersByStore, updateOrderStatus, getOrder, uploadDeliveryProof } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { Phone, MessageCircle, Navigation, MapPin, Check, Package, Camera } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import { motion } from "framer-motion";

const STAGES = [
  { id: "PICKED_UP", label: "Picked up", sub: "From store" },
  { id: "OUT_FOR_DELIVERY", label: "On the way", sub: "Heading to customer" },
  { id: "DELIVERED", label: "Delivered", sub: "Order complete" },
];
const ORDER = ["PICKED_UP", "OUT_FOR_DELIVERY", "DELIVERED"];

export default function ActiveDelivery() {
  const { user } = useAuth();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [activeDelivery, setActiveDelivery] = useState(null);
  const [loading, setLoading] = useState(true);
  const [stage, setStage] = useState("PICKED_UP");
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    loadActiveDelivery();
  }, [user]);

  const loadActiveDelivery = async () => {
    if (!user) return;
    try {
      // Find orders assigned to this partner that are not delivered
      const snap = await getOrdersByStore(user.uid); // This needs to be updated to query by deliveryPartnerId
      const active = snap.find((o) => o.deliveryPartnerId === user.uid && o.status !== "DELIVERED");
      if (active) {
        setActiveDelivery(active);
        setStage(active.status === "PICKED_UP" ? "PICKED_UP" : active.status);
      }
    } catch (error) {
      console.error("Error loading active delivery:", error);
    } finally {
      setLoading(false);
    }
  };

  const advance = async () => {
    const idx = ORDER.indexOf(stage);
    const next = ORDER[idx + 1];
    if (next && activeDelivery) {
      try {
        await updateOrderStatus(activeDelivery.id, next);
        setStage(next);
        toast({ title: next === "DELIVERED" ? "Order delivered 🎉" : "Status updated", description: STAGES.find((s) => s.id === next).label });
        if (next === "DELIVERED") setTimeout(() => navigate("/delivery"), 1200);
      } catch (error) {
        toast({ title: "Error", description: "Failed to update status", variant: "destructive" });
      }
    }
  };

  const handleProofUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !activeDelivery) return;

    setUploading(true);
    try {
      const proofUrl = await uploadDeliveryProof(file, activeDelivery.id, user.uid);
      toast({ title: "Proof uploaded", description: "Delivery proof saved" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to upload proof", variant: "destructive" });
    } finally {
      setUploading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-4 -mx-4">
        <div className="px-4">
          <div className="w-full h-48 bg-gray-200 rounded-3xl animate-pulse"></div>
        </div>
        <div className="px-4">
          <div className="h-20 bg-gray-200 rounded-2xl animate-pulse"></div>
        </div>
        <div className="px-4">
          <div className="h-32 bg-gray-200 rounded-2xl animate-pulse"></div>
        </div>
      </div>
    );
  }

  if (!activeDelivery) {
    return (
      <div className="py-20 text-center">
        <p className="text-sm text-[hsl(var(--text-secondary))]">No active delivery</p>
        <button onClick={() => navigate("/delivery")} className="text-[hsl(var(--accent))] text-sm font-medium mt-2">
          Go to available deliveries
        </button>
      </div>
    );
  }

  const idx = ORDER.indexOf(stage);

  return (
    <div className="space-y-4 -mx-4">
      {/* Map */}
      <div className="px-4">
        <div className="relative w-full h-48 rounded-3xl overflow-hidden bg-[hsl(var(--surface-2))]">
          <div className="absolute inset-0 opacity-60" style={{ backgroundImage: "linear-gradient(hsl(var(--border)) 1px, transparent 1px), linear-gradient(90deg, hsl(var(--border)) 1px, transparent 1px)", backgroundSize: "26px 26px" }} />
          <motion.div className="absolute top-1/2 left-1/3 w-8 h-8 rounded-full bg-[hsl(var(--accent))] text-white grid place-items-center shadow-lg"
            animate={{ x: [0, 60, 0], y: [0, -8, 0] }} transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}>
            <Navigation className="w-4 h-4" />
          </motion.div>
        </div>
      </div>

      <div className="px-4 flex items-center justify-between">
        <div>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">{activeDelivery.id}</p>
          <p className="text-sm font-semibold">{activeDelivery.storeName} · {formatPrice(activeDelivery.total)}</p>
        </div>
        <div className="flex gap-2">
          {activeDelivery.customerPhone && (
            <a href={`tel:${activeDelivery.customerPhone}`} className="press w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center">
              <Phone className="w-4 h-4" />
            </a>
          )}
          <button className="press w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center">
            <MessageCircle className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Stops */}
      <div className="px-4 card-soft rounded-2xl p-4 space-y-3">
        <div className="flex gap-3">
          <div className="flex flex-col items-center">
            <span className="w-3 h-3 rounded-full bg-[hsl(var(--accent))]" />
            <span className="w-0.5 flex-1 min-h-6 bg-[hsl(var(--border))]" />
            <span className="w-3 h-3 rounded-full bg-[hsl(var(--warning))]" />
          </div>
          <div className="flex-1 space-y-3 pb-1">
            <div>
              <p className="text-xs text-[hsl(var(--text-tertiary))] flex items-center gap-1"><Package className="w-3 h-3" /> Pickup</p>
              <p className="text-sm font-medium">{activeDelivery.storeName}</p>
              <p className="text-xs text-[hsl(var(--text-secondary))]">Store address</p>
            </div>
            <div>
              <p className="text-xs text-[hsl(var(--text-tertiary))] flex items-center gap-1"><MapPin className="w-3 h-3" /> Drop-off</p>
              <p className="text-sm font-medium">{activeDelivery.customerName}</p>
              <p className="text-xs text-[hsl(var(--text-secondary))]">{activeDelivery.deliveryAddress?.line}</p>
              <p className="text-xs text-[hsl(var(--text-secondary))]">{activeDelivery.deliveryAddress?.city}, {activeDelivery.deliveryAddress?.state} - {activeDelivery.deliveryAddress?.pin}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Items */}
      <div className="px-4 card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-2">Order items</h3>
        <div className="space-y-1">
          {activeDelivery.items?.map((item, i) => (
            <div key={i} className="flex justify-between text-sm">
              <span className="text-[hsl(var(--text-secondary))]">{item.name} × {item.qty}</span>
              <span>{formatPrice(item.price * item.qty)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Progress */}
      <div className="px-4 card-soft rounded-2xl p-4">
        <div className="flex items-center justify-between">
          {STAGES.map((s, i) => (
            <div key={s.id} className="flex-1 text-center">
              <div className={`w-7 h-7 rounded-full grid place-items-center mx-auto ${i <= idx ? "bg-[hsl(var(--accent))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-tertiary))]"}`}>
                {i < idx ? <Check className="w-3.5 h-3.5" /> : <span className="w-1.5 h-1.5 rounded-full bg-current" />}
              </div>
              <p className="text-[10px] mt-1 font-medium">{s.label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Upload proof */}
      {stage === "OUT_FOR_DELIVERY" && (
        <div className="px-4">
          <label className="press w-full h-11 rounded-2xl card-soft text-sm font-medium flex items-center justify-center gap-2 cursor-pointer">
            <Camera className="w-4 h-4" /> Upload delivery proof
            <input type="file" accept="image/*" onChange={handleProofUpload} className="hidden" disabled={uploading} />
          </label>
        </div>
      )}

      {/* Big action */}
      <div className="fixed bottom-0 inset-x-0 z-40 glass-strong border-t border-[hsl(var(--glass-border))] safe-bottom">
        <div className="max-w-md mx-auto px-4 py-3 flex gap-2">
          <button className="press flex-1 h-13 rounded-2xl card-soft text-sm font-semibold flex items-center justify-center gap-2 py-3.5">
            <Navigation className="w-4 h-4" /> Navigate
          </button>
          <button onClick={advance} disabled={stage === "DELIVERED"}
            className="press flex-[1.4] h-13 py-3.5 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold disabled:opacity-60">
            {stage === "PICKED_UP" ? "Picked up" : stage === "OUT_FOR_DELIVERY" ? "Mark delivered" : "Completed"}
          </button>
        </div>
      </div>
      <div className="h-20" />
    </div>
  );
}
