import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ChevronRight, Bike, FileText, Star, Shield, HelpCircle, Settings, LogOut, Bell, Moon, Loader2 } from "lucide-react";
import { getDeliveryPartner } from "@/lib/firestore";
import { useAuth } from "@/lib/AuthContext";

export default function DeliveryProfile() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [partner, setPartner] = useState(null);

  useEffect(() => {
    loadProfile();
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;
    try {
      const profile = await getDeliveryPartner(user.uid);
      setPartner(profile);
    } catch (error) {
      console.error("Error loading profile:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logout();
      navigate("/login");
    } catch (error) {
      console.error("Error logging out:", error);
    }
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="card-soft rounded-3xl p-5 flex items-center gap-4 animate-pulse">
          <div className="w-16 h-16 bg-gray-200 rounded-full"></div>
          <div className="flex-1 space-y-2">
            <div className="h-4 w-32 bg-gray-200 rounded"></div>
            <div className="h-3 w-24 bg-gray-200 rounded"></div>
            <div className="h-3 w-40 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  const SECTIONS = [
    { title: "Profile", items: [
      { icon: Bike, label: "Vehicle & documents", value: partner?.vehicle || "Bike" },
      { icon: Star, label: "Ratings", value: `${partner?.rating || 0} ★` },
      { icon: Bell, label: "Notifications" },
    ]},
    { title: "Support", items: [
      { icon: HelpCircle, label: "Help & support", to: "/support" },
      { icon: Shield, label: "Privacy & safety" },
      { icon: Settings, label: "Settings" },
    ]},
  ];

  return (
    <div className="space-y-5">
      <div className="card-soft rounded-3xl p-5 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[hsl(var(--accent))] to-[hsl(172_60%_30%)] text-white grid place-items-center text-xl font-bold">
          {user?.displayName?.charAt(0) || "D"}
        </div>
        <div className="flex-1">
          <h1 className="text-base font-semibold">{user?.displayName || "Delivery Partner"}</h1>
          <p className="text-xs text-[hsl(var(--text-secondary))]">Delivery Partner</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">
            {partner?.totalDeliveries || 0} deliveries · {partner?.rating || 0} ★
          </p>
        </div>
      </div>

      {SECTIONS.map((sec) => (
        <div key={sec.title}>
          <p className="text-xs font-semibold text-[hsl(var(--text-tertiary))] uppercase mb-2 px-1">{sec.title}</p>
          <div className="card-soft rounded-2xl overflow-hidden divide-y divide-[hsl(var(--border))]">
            {sec.items.map((it) => {
              const Icon = it.icon;
              return (
                <div key={it.label} className="flex items-center gap-3 px-4 py-3.5">
                  <Icon className="w-4.5 h-4.5 text-[hsl(var(--text-secondary))]" />
                  <span className="flex-1 text-sm">{it.label}</span>
                  {it.value && <span className="text-xs text-[hsl(var(--text-tertiary))]">{it.value}</span>}
                  <Link to={it.to || "#"} className="press"><ChevronRight className="w-4 h-4 text-[hsl(var(--text-tertiary))]" /></Link>
                </div>
              );
            })}
          </div>
        </div>
      ))}

      <button
        onClick={handleLogout}
        className="press w-full h-12 rounded-2xl card-soft text-sm font-medium text-[hsl(var(--danger))] flex items-center justify-center gap-2"
      >
        <LogOut className="w-4 h-4" /> Log out
      </button>
    </div>
  );
}
