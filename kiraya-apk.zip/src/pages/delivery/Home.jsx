import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { getAvailableDeliveries, updateDeliveryPartnerStatus, assignDeliveryPartner, getDeliveryPartner } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import StatCard from "@/components/admin/StatCard";
import { Bike, Navigation, CheckCircle2, Star, MapPin } from "lucide-react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import { motion } from "framer-motion";

export default function DeliveryHome() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [online, setOnline] = useState(true);
  const [requests, setRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    todayEarnings: 0,
    weekEarnings: 0,
    completed: 0,
    rating: 0,
  });

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    try {
      // Load partner profile
      const partner = await getDeliveryPartner(user.uid);
      if (partner) {
        setOnline(partner.isOnline);
        setStats({
          todayEarnings: partner.earnings || 0,
          weekEarnings: partner.earnings || 0,
          completed: partner.totalDeliveries || 0,
          rating: partner.rating || 0,
        });
      }

      // Load available deliveries
      const deliveries = await getAvailableDeliveries();
      setRequests(deliveries);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const toggleOnline = async () => {
    const newStatus = !online;
    setOnline(newStatus);
    try {
      await updateDeliveryPartnerStatus(user.uid, newStatus);
      toast({ title: newStatus ? "You're online" : "You're offline" });
    } catch (error) {
      setOnline(!newStatus);
      toast({ title: "Error", description: "Failed to update status", variant: "destructive" });
    }
  };

  const accept = async (orderId) => {
    try {
      await assignDeliveryPartner(orderId, user.uid);
      setRequests((r) => r.filter((x) => x.id !== orderId));
      toast({ title: "Delivery accepted", description: orderId });
      navigate("/delivery/active");
    } catch (error) {
      toast({ title: "Error", description: "Failed to accept delivery", variant: "destructive" });
    }
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="flex items-center justify-between animate-pulse">
          <div className="space-y-2">
            <div className="h-5 w-32 bg-gray-200 rounded"></div>
            <div className="h-3 w-24 bg-gray-200 rounded"></div>
          </div>
          <div className="w-24 h-10 bg-gray-200 rounded-full"></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
        <div className="space-y-3">
          {[1, 2].map((i) => (
            <div key={i} className="h-40 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  const deliveryStats = [
    { label: "Today's Earnings", value: stats.todayEarnings, prefix: "₹", icon: Bike },
    { label: "This Week", value: stats.weekEarnings, prefix: "₹", icon: Navigation },
    { label: "Completed", value: stats.completed, icon: CheckCircle2 },
    { label: "Rating", value: stats.rating, icon: Star },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-lg font-semibold">Hi, {user?.displayName || "Partner"} 👋</h1>
          <p className="text-xs text-[hsl(var(--text-tertiary))]">You're ready to deliver</p>
        </div>
        <button onClick={toggleOnline} className="press flex items-center gap-2 px-3 h-10 rounded-full glass">
          <span className={`w-2.5 h-2.5 rounded-full ${online ? "bg-[hsl(var(--success))]" : "bg-[hsl(var(--text-tertiary))]"}`} />
          <span className="text-sm font-medium">{online ? "Online" : "Offline"}</span>
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        {deliveryStats.map((stat, i) => (
          <StatCard key={i} {...stat} tone="accent" />
        ))}
      </div>

      <div>
        <h2 className="text-sm font-semibold mb-2">Available deliveries</h2>
        {!online ? (
          <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-10">You're offline. Go online to receive requests.</p>
        ) : requests.length === 0 ? (
          <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-10">No deliveries nearby right now.</p>
        ) : (
          <div className="space-y-3">
            {requests.map((r) => (
              <motion.div key={r.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card-soft rounded-2xl p-4">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-semibold">{r.storeName}</p>
                  <span className="text-sm font-bold text-[hsl(var(--accent))]">{formatPrice(r.total)}</span>
                </div>
                <div className="mt-2 space-y-1.5 text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))]" />
                    <span className="text-[hsl(var(--text-secondary))]">{r.deliveryAddress?.line || "Pickup location"}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[hsl(var(--warning))]" />
                    <span className="text-[hsl(var(--text-secondary))]">{r.deliveryAddress?.city || "Drop location"}</span>
                  </div>
                </div>
                <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-tertiary))]">
                  <span>{r.items?.length || 0} items</span> · <span>{r.deliveryType || "Express"}</span>
                </div>
                <button onClick={() => accept(r.id)} className="press w-full h-11 mt-3 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold">
                  Accept · {formatPrice(r.total)}
                </button>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
