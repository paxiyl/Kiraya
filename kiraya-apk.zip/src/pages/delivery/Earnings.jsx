import React, { useState, useEffect } from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart } from "@/components/admin/Charts";
import { getDeliveryPartner } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { Wallet, Navigation, CheckCircle2, Star } from "lucide-react";
import { useAuth } from "@/lib/AuthContext";

export default function DeliveryEarnings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState([]);

  useEffect(() => {
    loadEarnings();
  }, [user]);

  const loadEarnings = async () => {
    if (!user) return;
    try {
      const partner = await getDeliveryPartner(user.uid);
      if (partner) {
        setStats([
          { label: "Today's Earnings", value: partner.earnings || 0, prefix: "₹", icon: Wallet },
          { label: "This Week", value: (partner.earnings || 0) * 7, prefix: "₹", icon: Navigation },
          { label: "Completed", value: partner.totalDeliveries || 0, icon: CheckCircle2 },
          { label: "Rating", value: partner.rating || 0, icon: Star },
        ]);
      }
    } catch (error) {
      console.error("Error loading earnings:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="animate-pulse">
          <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
          <div className="h-4 w-48 bg-gray-200 rounded"></div>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-lg font-semibold">Earnings</h1>
        <p className="text-xs text-[hsl(var(--text-tertiary))]">Your delivery income</p>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {stats.map((stat, i) => (
          <StatCard key={i} {...stat} tone="accent" />
        ))}
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Weekly earnings</h3>
        <RevenueChart data={[
          { day: "Mon", revenue: 1200 },
          { day: "Tue", revenue: 1800 },
          { day: "Wed", revenue: 1500 },
          { day: "Thu", revenue: 2100 },
          { day: "Fri", revenue: 2400 },
          { day: "Sat", revenue: 2800 },
          { day: "Sun", revenue: 1900 },
        ]} />
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Payouts</h3>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <div>
              <p className="font-medium">This week</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">Weekly payout</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-bold">{formatPrice(stats[1]?.value || 0)}</span>
              <span className="px-2 py-0.5 rounded-full bg-[hsl(var(--warning-soft))] text-[hsl(var(--warning))] text-xs font-medium">Pending</span>
            </div>
          </div>
          <div className="flex items-center justify-between text-sm">
            <div>
              <p className="font-medium">Last week</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">Weekly payout</p>
            </div>
            <div className="flex items-center gap-3">
              <span className="font-bold">{formatPrice(8960)}</span>
              <span className="px-2 py-0.5 rounded-full bg-[hsl(var(--success-soft))] text-[hsl(var(--success))] text-xs font-medium">Paid</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
