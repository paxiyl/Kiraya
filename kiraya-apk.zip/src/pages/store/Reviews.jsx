import React, { useState, useEffect } from "react";
import { Star } from "lucide-react";
import { getDocs, query, collection, where } from "firebase/firestore";
import { db } from "@/lib/firebase";
import { useAuth } from "@/lib/AuthContext";

export default function StoreReviews() {
  const { user } = useAuth();
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadReviews(); }, [user]);

  const loadReviews = async () => {
    if (!user) return;
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      if (profile?.storeId) {
        const snap = await getDocs(query(collection(db, "ratings"), where("storeId", "==", profile.storeId)));
        setReviews(snap.docs.map(d => ({ id: d.id, ...d.data() })));
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const avgRating = reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : "0";
  const breakdown = [5, 4, 3, 2, 1].map(star => ({
    star,
    pct: reviews.length ? Math.round((reviews.filter(r => r.rating === star).length / reviews.length) * 100) : 0,
  }));

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /></div>
      <div className="h-32 bg-gray-200 rounded-2xl animate-pulse" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Reviews</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Customer feedback</p>
      </div>
      <div className="card-soft rounded-2xl p-4 flex items-center gap-4">
        <div className="text-center">
          <p className="text-4xl font-bold">{avgRating}</p>
          <div className="flex justify-center mt-1">{[1,2,3,4,5].map((i) => <Star key={i} className="w-3.5 h-3.5 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" />)}</div>
          <p className="text-xs text-[hsl(var(--text-tertiary))] mt-1">{reviews.length} reviews</p>
        </div>
        <div className="flex-1 space-y-1.5">
          {breakdown.map((b) => (
            <div key={b.star} className="flex items-center gap-2 text-xs">
              <span className="w-3 text-[hsl(var(--text-tertiary))]">{b.star}</span>
              <div className="flex-1 h-1.5 rounded-full bg-[hsl(var(--muted))] overflow-hidden">
                <div className="h-full rounded-full bg-[hsl(var(--warning))]" style={{ width: `${b.pct}%` }} />
              </div>
              <span className="w-8 text-right text-[hsl(var(--text-tertiary))]">{b.pct}%</span>
            </div>
          ))}
        </div>
      </div>
      <div className="space-y-3">
        {reviews.length === 0 ? (
          <p className="text-sm text-[hsl(var(--text-tertiary))] text-center py-10">No reviews yet</p>
        ) : reviews.map((r) => (
          <div key={r.id} className="card-soft rounded-2xl p-4">
            <div className="flex items-center justify-between">
              <p className="text-sm font-semibold">{r.customerName || "Customer"}</p>
              <div className="flex items-center gap-0.5">{[1,2,3,4,5].map((s) => <Star key={s} className={`w-3.5 h-3.5 ${s <= r.rating ? "fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" : "text-[hsl(var(--border))]"}`} />)}</div>
            </div>
            {r.comment && <p className="text-sm text-[hsl(var(--text-secondary))] mt-1.5">{r.comment}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
