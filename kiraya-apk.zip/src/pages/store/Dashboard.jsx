import React, { useState, useEffect } from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart } from "@/components/admin/Charts";
import { getOrdersByStore, getProductsByStore } from "@/lib/firestore";
import { Wallet, ClipboardList, CheckCircle2, Clock } from "lucide-react";
import StatusBadge from "@/components/customer/StatusBadge";
import { formatPrice } from "@/lib/appConfig";
import { useAuth } from "@/lib/AuthContext";

const ICONS = { sales: Wallet, pending: ClipboardList, completed: CheckCircle2, prepTime: Clock };
const STOCK_TONE = { ok: "success", low: "warning", out: "danger" };
const STOCK_LABEL = { ok: "In stock", low: "Low stock", out: "Out of stock" };

export default function StoreDashboard() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState([]);
  const [orders, setOrders] = useState([]);
  const [inventory, setInventory] = useState([]);
  const [storeName, setStoreName] = useState("Your Store");

  useEffect(() => {
    loadDashboard();
  }, [user]);

  const loadDashboard = async () => {
    if (!user) return;
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      const storeId = profile?.storeId;

      if (storeId) {
        const [storeOrders, products] = await Promise.all([
          getOrdersByStore(storeId),
          getProductsByStore(storeId),
        ]);

        setOrders(storeOrders);
        setStoreName(profile?.displayName || "Your Store");

        // Calculate stats
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const todayOrders = storeOrders.filter((o) => {
          const createdAt = o.createdAt?.toDate?.() || new Date(o.createdAt);
          return createdAt >= today;
        });

        const todaySales = todayOrders.reduce((sum, o) => sum + (o.total || 0), 0);
        const pendingOrders = storeOrders.filter((o) => ["PENDING", "ACCEPTED"].includes(o.status));
        const completedOrders = storeOrders.filter((o) => o.status === "DELIVERED");

        setStats([
          { key: "sales", label: "Today's Sales", value: todaySales, prefix: "₹", delta: "+9.2%", up: true },
          { key: "pending", label: "Pending Orders", value: pendingOrders.length, delta: "—", up: null },
          { key: "completed", label: "Completed Today", value: todayOrders.filter((o) => o.status === "DELIVERED").length, delta: "+5", up: true },
          { key: "prepTime", label: "Avg Prep Time", value: 18, suffix: " min", delta: "-2 min", up: true },
        ]);

        // Set inventory from products
        setInventory(products.map((p) => ({
          id: p.id,
          name: p.name,
          stock: p.stock || 0,
          status: p.stock === 0 ? "out" : p.stock < 10 ? "low" : "ok",
        })));
      }
    } catch (error) {
      console.error("Error loading dashboard:", error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="animate-pulse">
          <div className="h-6 w-48 bg-gray-200 rounded mb-2"></div>
          <div className="h-4 w-64 bg-gray-200 rounded"></div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
        <div className="h-64 bg-gray-200 rounded-2xl animate-pulse"></div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Store Dashboard</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{storeName} · today</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.map(({ key, ...rest }) => (
          <StatCard key={key} {...rest} icon={ICONS[key]} tone={key === "pending" ? "warning" : "accent"} />
        ))}
      </div>

      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Sales (last 7 days)</h3>
        <RevenueChart data={[
          { day: "Mon", revenue: 5400 },
          { day: "Tue", revenue: 6100 },
          { day: "Wed", revenue: 5850 },
          { day: "Thu", revenue: 7200 },
          { day: "Fri", revenue: 8900 },
          { day: "Sat", revenue: 9600 },
          { day: "Sun", revenue: 7150 },
        ]} />
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Order queue</h3>
          <div className="space-y-2">
            {orders.slice(0, 4).map((o) => (
              <div key={o.id} className="flex items-center justify-between text-sm">
                <div>
                  <p className="font-medium">{o.id?.slice(0, 8)}...</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{o.customerName} · {o.items?.length || 0} items</p>
                </div>
                <div className="text-right">
                  <p className="font-medium">{formatPrice(o.total)}</p>
                  <StatusBadge status={o.status} />
                </div>
              </div>
            ))}
            {orders.length === 0 && (
              <p className="text-sm text-[hsl(var(--text-tertiary))] text-center py-4">No orders yet</p>
            )}
          </div>
        </div>
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Low stock alerts</h3>
          <div className="space-y-2">
            {inventory.filter((i) => i.status !== "ok").map((i) => (
              <div key={i.id} className="flex items-center justify-between text-sm">
                <span className="font-medium">{i.name}</span>
                <span className={`text-xs font-medium px-2 py-0.5 rounded-full bg-[hsl(var(--${STOCK_TONE[i.status]}-soft))] text-[hsl(var(--${STOCK_TONE[i.status]}))]`}>
                  {STOCK_LABEL[i.status]} · {i.stock} left
                </span>
              </div>
            ))}
            {inventory.filter((i) => i.status !== "ok").length === 0 && (
              <p className="text-sm text-[hsl(var(--text-tertiary))]">All items well stocked.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
