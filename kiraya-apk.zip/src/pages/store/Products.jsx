import React, { useState, useEffect } from "react";
import { getProductsByStore, createProduct, updateProduct, deleteProduct } from "@/lib/firestore";
import { uploadProductImage, compressImage } from "@/lib/storage";
import { formatPrice } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import { Plus, Pencil, Trash2, X, Upload, Loader2 } from "lucide-react";

const CATEGORIES = [
  { id: "food", name: "Food" },
  { id: "grocery", name: "Grocery" },
  { id: "veg", name: "Fruits & Veg" },
  { id: "pharmacy", name: "Pharmacy" },
  { id: "beauty", name: "Beauty" },
  { id: "electronics", name: "Electronics" },
  { id: "fashion", name: "Fashion" },
  { id: "home", name: "Home" },
  { id: "bakery", name: "Bakery" },
  { id: "gifts", name: "Gifts" },
  { id: "stationery", name: "Stationery" },
  { id: "pets", name: "Pets" },
];

export default function StoreProducts() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [items, setItems] = useState([]);
  const [editing, setEditing] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [imagePreview, setImagePreview] = useState(null);

  useEffect(() => {
    loadProducts();
  }, [user]);

  const loadProducts = async () => {
    if (!user) return;
    try {
      // Get user profile to find storeId
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      if (profile?.storeId) {
        const products = await getProductsByStore(profile.storeId);
        setItems(products);
      }
    } catch (error) {
      console.error("Error loading products:", error);
    } finally {
      setLoading(false);
    }
  };

  const remove = async (id) => {
    try {
      await deleteProduct(id);
      setItems((prev) => prev.filter((i) => i.id !== id));
      toast({ title: "Product removed" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to remove product", variant: "destructive" });
    }
  };

  const handleImageChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    try {
      const compressed = await compressImage(file, 800, 0.8);
      const preview = URL.createObjectURL(compressed);
      setImagePreview({ file: compressed, preview });
    } catch (error) {
      console.error("Error processing image:", error);
    }
  };

  const save = async (data) => {
    setSaving(true);
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      const storeId = profile?.storeId;

      let imageUrl = data.image || null;

      // Upload image if selected
      if (imagePreview?.file && storeId) {
        const productId = data.id || `prod_${Date.now()}`;
        imageUrl = await uploadProductImage(imagePreview.file, storeId, productId);
      }

      const productData = {
        name: data.name,
        price: Number(data.price),
        mrp: Number(data.mrp) || Number(data.price),
        stock: Number(data.stock) || 0,
        category: data.category,
        description: data.description || "",
        image: imageUrl,
        storeId: storeId,
        storeName: profile?.displayName || "Store",
        eta: "30-60 min",
        badge: null,
        rating: 0,
      };

      if (data.id) {
        // Update existing product
        await updateProduct(data.id, productData);
        setItems((prev) => prev.map((i) => (i.id === data.id ? { ...i, ...productData } : i)));
      } else {
        // Create new product
        const newId = await createProduct(productData);
        setItems((prev) => [...prev, { id: newId, ...productData }]);
      }

      setEditing(null);
      setImagePreview(null);
      toast({ title: "Product saved" });
    } catch (error) {
      console.error("Error saving product:", error);
      toast({ title: "Error", description: "Failed to save product", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="flex items-center justify-between animate-pulse">
          <div className="space-y-2">
            <div className="h-6 w-32 bg-gray-200 rounded"></div>
            <div className="h-4 w-24 bg-gray-200 rounded"></div>
          </div>
          <div className="h-10 w-32 bg-gray-200 rounded-2xl"></div>
        </div>
        <div className="space-y-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-20 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Products</h1>
          <p className="text-sm text-[hsl(var(--text-tertiary))]">{items.length} products</p>
        </div>
        <button onClick={() => {
          setEditing({ id: null, name: "", price: "", mrp: "", stock: "", category: "food", description: "", image: null });
          setImagePreview(null);
        }}
          className="press h-10 px-4 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold inline-flex items-center gap-1.5">
          <Plus className="w-4 h-4" /> Add product
        </button>
      </div>

      <div className="space-y-2">
        {items.map((p) => (
          <div key={p.id} className="card-soft rounded-2xl p-3 flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-[hsl(var(--muted))] grid place-items-center font-semibold text-[hsl(var(--text-tertiary))] overflow-hidden">
              {p.image ? (
                <img src={p.image} alt={p.name} className="w-full h-full object-cover" />
              ) : (
                p.name.charAt(0)
              )}
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium">{p.name}</p>
              <p className="text-xs text-[hsl(var(--text-tertiary))]">{formatPrice(p.price)} · stock {p.stock} · {p.isActive !== false ? "Available" : "Hidden"}</p>
            </div>
            <button onClick={() => {
              setEditing(p);
              setImagePreview(p.image ? { file: null, preview: p.image } : null);
            }} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))]">
              <Pencil className="w-4 h-4" />
            </button>
            <button onClick={() => remove(p.id)} className="press w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--muted))] text-[hsl(var(--danger))]">
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>

      {items.length === 0 && (
        <div className="text-center py-10">
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No products yet</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))] mt-1">Add your first product to get started</p>
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setEditing(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm card-soft rounded-3xl p-5 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-base font-semibold">{editing.id ? "Edit product" : "New product"}</h3>
              <button onClick={() => setEditing(null)} className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>
            <div className="space-y-3">
              {/* Image upload */}
              <div>
                <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">Product Image</label>
                <div className="mt-1 flex items-center gap-3">
                  {imagePreview?.preview ? (
                    <div className="relative w-20 h-20 rounded-xl overflow-hidden">
                      <img src={imagePreview.preview} alt="Preview" className="w-full h-full object-cover" />
                      <button
                        onClick={() => setImagePreview(null)}
                        className="absolute top-1 right-1 w-5 h-5 rounded-full bg-black/50 text-white grid place-items-center"
                      >
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  ) : (
                    <label className="w-20 h-20 rounded-xl bg-[hsl(var(--muted))] grid place-items-center cursor-pointer hover:bg-[hsl(var(--border))] transition-colors">
                      <Upload className="w-6 h-6 text-[hsl(var(--text-tertiary))]" />
                      <input type="file" accept="image/*" onChange={handleImageChange} className="hidden" />
                    </label>
                  )}
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">Optional</p>
                </div>
              </div>

              <Input label="Name" value={editing.name} onChange={(v) => setEditing({ ...editing, name: v })} />
              <div className="grid grid-cols-3 gap-2">
                <Input label="Price ₹" type="number" value={editing.price} onChange={(v) => setEditing({ ...editing, price: v })} />
                <Input label="MRP ₹" type="number" value={editing.mrp} onChange={(v) => setEditing({ ...editing, mrp: v })} />
                <Input label="Stock" type="number" value={editing.stock} onChange={(v) => setEditing({ ...editing, stock: v })} />
              </div>
              <div>
                <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">Category</label>
                <select
                  value={editing.category}
                  onChange={(e) => setEditing({ ...editing, category: e.target.value })}
                  className="mt-1 w-full h-11 px-3 rounded-xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--warning))]"
                >
                  {CATEGORIES.map((c) => (
                    <option key={c.id} value={c.id}>{c.name}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">Description</label>
                <textarea
                  value={editing.description || ""}
                  onChange={(e) => setEditing({ ...editing, description: e.target.value })}
                  placeholder="Product description (optional)"
                  className="mt-1 w-full h-20 px-3 py-2 rounded-xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--warning))]"
                />
              </div>
              <button
                onClick={() => save(editing)}
                disabled={saving || !editing.name || !editing.price}
                className="press w-full h-11 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {saving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save product"
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Input({ label, value, onChange, type = "text" }) {
  return (
    <div>
      <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)}
        className="mt-1 w-full h-11 px-3 rounded-xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--warning))]" />
    </div>
  );
}
