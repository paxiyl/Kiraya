import React, { useState, useEffect } from "react";
import { getOrdersByStore, updateOrderStatus } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import { motion } from "framer-motion";

const TABS = [
  { id: "NEW", label: "New" },
  { id: "PREPARING", label: "Preparing" },
  { id: "READY", label: "Ready" },
  { id: "COMPLETED", label: "Completed" },
  { id: "CANCELLED", label: "Cancelled" },
];

const STATUS_MAP = {
  PENDING: "NEW",
  ACCEPTED: "PREPARING",
  PREPARING: "PREPARING",
  READY: "READY",
  PICKED_UP: "COMPLETED",
  OUT_FOR_DELIVERY: "COMPLETED",
  DELIVERED: "COMPLETED",
  CANCELLED: "CANCELLED",
};

export default function StoreOrders() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState("NEW");

  useEffect(() => {
    loadOrders();
  }, [user]);

  const loadOrders = async () => {
    if (!user) return;
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      if (profile?.storeId) {
        const storeOrders = await getOrdersByStore(profile.storeId);
        setOrders(storeOrders);
      }
    } catch (error) {
      console.error("Error loading orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const advance = async (id) => {
    const order = orders.find((o) => o.id === id);
    if (!order) return;

    const flow = {
      PENDING: "ACCEPTED",
      ACCEPTED: "PREPARING",
      PREPARING: "READY",
      READY: "PICKED_UP",
    };

    const nextStatus = flow[order.status];
    if (nextStatus) {
      try {
        await updateOrderStatus(id, nextStatus);
        setOrders((prev) =>
          prev.map((o) => (o.id === id ? { ...o, status: nextStatus } : o))
        );
        toast({ title: "Order updated", description: `${id} → ${nextStatus}` });
      } catch (error) {
        toast({ title: "Error", description: "Failed to update order", variant: "destructive" });
      }
    }
  };

  const cancel = async (id) => {
    try {
      await updateOrderStatus(id, "CANCELLED");
      setOrders((prev) =>
        prev.map((o) => (o.id === id ? { ...o, status: "CANCELLED" } : o))
      );
      toast({ title: "Order cancelled", description: id, variant: "destructive" });
    } catch (error) {
      toast({ title: "Error", description: "Failed to cancel order", variant: "destructive" });
    }
  };

  const list = orders.filter((o) => STATUS_MAP[o.status] === tab);

  const nextAction = {
    PENDING: "Accept & start preparing",
    ACCEPTED: "Mark as preparing",
    PREPARING: "Mark as ready",
    READY: "Mark picked up",
  };

  if (loading) {
    return (
      <div className="space-y-5">
        <div className="animate-pulse">
          <div className="h-6 w-32 bg-gray-200 rounded mb-2"></div>
          <div className="h-4 w-48 bg-gray-200 rounded"></div>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="w-20 h-9 bg-gray-200 rounded-full animate-pulse"></div>
          ))}
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Orders</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Accept, prepare & complete</p>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {TABS.map((t) => {
          const count = orders.filter((o) => STATUS_MAP[o.status] === t.id).length;
          return (
            <button key={t.id} onClick={() => setTab(t.id)}
              className={`press shrink-0 px-3.5 h-9 rounded-full text-sm font-medium inline-flex items-center gap-1.5 ${tab === t.id ? "bg-[hsl(var(--warning))] text-white" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
              {t.label} <span className="text-xs opacity-70">{count}</span>
            </button>
          );
        })}
      </div>

      {list.length === 0 ? (
        <p className="text-center text-sm text-[hsl(var(--text-tertiary))] py-12">No {tab.toLowerCase()} orders.</p>
      ) : (
        <div className="space-y-3">
          {list.map((o) => (
            <motion.div key={o.id} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="card-soft rounded-2xl p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-semibold">{o.id?.slice(0, 8)}... · {o.customerName}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">
                    {o.items?.length || 0} items · {o.paymentMethod} · {o.createdAt ? new Date(o.createdAt).toLocaleTimeString() : "Just now"}
                  </p>
                </div>
                <p className="text-sm font-bold">{formatPrice(o.total)}</p>
              </div>
              {nextAction[o.status] ? (
                <div className="flex gap-2 mt-3">
                  <button onClick={() => advance(o.id)} className="press flex-1 h-11 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold">
                    {nextAction[o.status]}
                  </button>
                  {o.status === "PENDING" && (
                    <button onClick={() => cancel(o.id)} className="press h-11 px-4 rounded-2xl card-soft text-sm font-medium text-[hsl(var(--danger))]">
                      Decline
                    </button>
                  )}
                </div>
              ) : (
                <p className="text-xs text-[hsl(var(--text-tertiary))] mt-3">No action needed.</p>
              )}
            </motion.div>
          ))}
        </div>
      )}
    </div>
  );
}
