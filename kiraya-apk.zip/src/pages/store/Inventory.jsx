import React, { useState, useEffect } from "react";
import { getProductsByStore } from "@/lib/firestore";
import { useAuth } from "@/lib/AuthContext";
import { Boxes, AlertTriangle, PackageX } from "lucide-react";

const TONE = { ok: "success", low: "warning", out: "danger" };
const LABEL = { ok: "In stock", low: "Low stock", out: "Out of stock" };
const ICON = { ok: Boxes, low: AlertTriangle, out: PackageX };

export default function StoreInventory() {
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadInventory(); }, [user]);

  const loadInventory = async () => {
    if (!user) return;
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      if (profile?.storeId) {
        const products = await getProductsByStore(profile.storeId);
        setItems(products.map(p => ({
          id: p.id,
          name: p.name,
          stock: p.stock || 0,
          status: p.stock === 0 ? "out" : p.stock < 10 ? "low" : "ok",
        })));
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const low = items.filter((i) => i.status !== "ok");

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /></div>
      <div className="grid grid-cols-3 gap-3">{[1,2,3].map(i => <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse" />)}</div>
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Inventory</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Stock levels & status</p>
      </div>

      <div className="grid grid-cols-3 gap-3">
        {["ok", "low", "out"].map((st) => {
          const Icon = ICON[st];
          const count = items.filter((i) => i.status === st).length;
          return (
            <div key={st} className="card-soft rounded-2xl p-3 text-center">
              <div className={`w-9 h-9 rounded-xl grid place-items-center mx-auto bg-[hsl(var(--${TONE[st]}-soft))] text-[hsl(var(--${TONE[st]}))]`}>
                <Icon className="w-4.5 h-4.5" />
              </div>
              <p className="text-xl font-bold mt-2">{count}</p>
              <p className="text-[11px] text-[hsl(var(--text-tertiary))]">{LABEL[st]}</p>
            </div>
          );
        })}
      </div>

      {low.length > 0 && (
        <div className="rounded-2xl p-4 bg-[hsl(var(--warning-soft))] text-[hsl(var(--warning))] flex items-center gap-2">
          <AlertTriangle className="w-4 h-4" />
          <p className="text-sm font-medium">{low.length} items need restocking soon.</p>
        </div>
      )}

      <div className="card-soft rounded-2xl divide-y divide-[hsl(var(--border))]">
        {items.length === 0 ? (
          <p className="p-4 text-sm text-[hsl(var(--text-tertiary))] text-center">No products yet. Add products from the Products page.</p>
        ) : items.map((i) => {
          const Icon = ICON[i.status];
          return (
            <div key={i.id} className="flex items-center gap-3 p-4">
              <div className={`w-9 h-9 rounded-xl grid place-items-center bg-[hsl(var(--${TONE[i.status]}-soft))] text-[hsl(var(--${TONE[i.status]}))]`}>
                <Icon className="w-4.5 h-4.5" />
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{i.name}</p>
                <p className="text-xs text-[hsl(var(--text-tertiary))]">{i.stock} units</p>
              </div>
              <span className={`text-xs font-medium px-2.5 py-1 rounded-full bg-[hsl(var(--${TONE[i.status]}-soft))] text-[hsl(var(--${TONE[i.status]}))]`}>{LABEL[i.status]}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
