import React, { useState, useEffect } from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart } from "@/components/admin/Charts";
import { getOrdersByStore } from "@/lib/firestore";
import { useAuth } from "@/lib/AuthContext";
import { Wallet, TrendingUp, Star, Calendar } from "lucide-react";
import { formatPrice } from "@/lib/appConfig";

export default function StoreEarnings() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({ weekRev: 0, orders: 0, avgOrder: 0 });

  useEffect(() => { loadEarnings(); }, [user]);

  const loadEarnings = async () => {
    if (!user) return;
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      if (profile?.storeId) {
        const orders = await getOrdersByStore(profile.storeId);
        const weekRev = orders.reduce((s, o) => s + (o.total || 0), 0);
        setStats({
          weekRev,
          orders: orders.length,
          avgOrder: orders.length ? Math.round(weekRev / orders.length) : 0,
        });
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /></div>
      <div className="grid grid-cols-2 gap-3">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse" />)}</div>
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Earnings</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Revenue & payouts</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Total Revenue" value={stats.weekRev} prefix="₹" icon={Wallet} tone="accent" />
        <StatCard label="Net (after 12%)" value={Math.round(stats.weekRev * 0.88)} prefix="₹" icon={TrendingUp} tone="success" />
        <StatCard label="Avg Order Value" value={stats.avgOrder} prefix="₹" icon={Star} tone="warning" />
        <StatCard label="Orders" value={stats.orders} icon={Calendar} tone="neutral" />
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Revenue</h3>
        <RevenueChart data={[
          { day: "Mon", revenue: 5400 },
          { day: "Tue", revenue: 6100 },
          { day: "Wed", revenue: 5850 },
          { day: "Thu", revenue: 7200 },
          { day: "Fri", revenue: 8900 },
          { day: "Sat", revenue: 9600 },
          { day: "Sun", revenue: 7150 },
        ]} />
      </div>
    </div>
  );
}
