import React, { useState, useEffect } from "react";
import { useToast } from "@/components/ui/use-toast";
import { useAuth } from "@/lib/AuthContext";
import { getStore, updateStore } from "@/lib/firestore";
import { Loader2 } from "lucide-react";

export default function StoreSettings() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [storeId, setStoreId] = useState(null);
  const [name, setName] = useState("");
  const [tag, setTag] = useState("");
  const [open, setOpen] = useState(true);
  const [radius, setRadius] = useState(5);
  const [fee, setFee] = useState(29);

  useEffect(() => { loadSettings(); }, [user]);

  const loadSettings = async () => {
    if (!user) return;
    try {
      const { getUserProfile } = await import("@/lib/firebase");
      const profile = await getUserProfile(user.uid);
      if (profile?.storeId) {
        setStoreId(profile.storeId);
        const store = await getStore(profile.storeId);
        if (store) {
          setName(store.name || "");
          setTag(store.tag || "");
          setOpen(store.isOpen !== false);
          setFee(store.fee || 29);
        }
      }
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const save = async () => {
    if (!storeId) return;
    setSaving(true);
    try {
      await updateStore(storeId, {
        name,
        tag,
        isOpen: open,
        fee: Number(fee),
      });
      toast({ title: "Settings saved" });
    } catch (e) {
      toast({ title: "Error", description: "Failed to save settings", variant: "destructive" });
    } finally { setSaving(false); }
  };

  if (loading) return (
    <div className="space-y-5 max-w-xl">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /></div>
      <div className="h-48 bg-gray-200 rounded-2xl animate-pulse" />
    </div>
  );

  return (
    <div className="space-y-5 max-w-xl">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Settings</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Store profile & operations</p>
      </div>
      <div className="card-soft rounded-2xl p-4 space-y-3">
        <Field label="Store name" value={name} onChange={setName} />
        <Field label="Store tag / description" value={tag} onChange={setTag} placeholder="e.g. North Indian • Chinese" />
        <Field label="Delivery fee (₹)" type="number" value={fee} onChange={(v) => setFee(Number(v))} />
        <div className="flex items-center justify-between pt-1">
          <div><p className="text-sm font-medium">Store open</p><p className="text-xs text-[hsl(var(--text-tertiary))]">Accept new orders</p></div>
          <button onClick={() => setOpen(!open)} className={`press w-11 h-6 rounded-full transition-colors ${open ? "bg-[hsl(var(--success))]" : "bg-[hsl(var(--border))]"}`}>
            <span className={`block w-5 h-5 rounded-full bg-white transition-transform ${open ? "translate-x-5" : "translate-x-0.5"} mt-0.5`} />
          </button>
        </div>
      </div>
      <button onClick={save} disabled={saving} className="press h-11 px-5 rounded-2xl bg-[hsl(var(--warning))] text-white text-sm font-semibold flex items-center gap-2 disabled:opacity-50">
        {saving && <Loader2 className="w-4 h-4 animate-spin" />}
        Save changes
      </button>
    </div>
  );
}

function Field({ label, value, onChange, type = "text", placeholder = "" }) {
  return (
    <div>
      <label className="text-xs font-medium text-[hsl(var(--text-secondary))]">{label}</label>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} placeholder={placeholder}
        className="mt-1 w-full h-11 px-4 rounded-2xl card-soft text-sm outline-none focus:ring-2 ring-[hsl(var(--warning))]" />
    </div>
  );
}
