import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { ClipboardList } from "lucide-react";
import { getOrdersByCustomer } from "@/lib/firestore";
import { useAuth } from "@/lib/AuthContext";
import StatusBadge from "@/components/customer/StatusBadge";
import EmptyState from "@/components/customer/EmptyState";
import { formatPrice } from "@/lib/appConfig";

const TABS = [
  { id: "all", label: "All" },
  { id: "ongoing", label: "Ongoing" },
  { id: "completed", label: "Completed" },
  { id: "cancelled", label: "Cancelled" },
];

const ONGOING = ["PENDING", "ACCEPTED", "PREPARING", "READY", "PICKED_UP", "OUT_FOR_DELIVERY"];

export default function Orders() {
  const { user } = useAuth();
  const [tab, setTab] = useState("all");
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOrders();
  }, [user]);

  const loadOrders = async () => {
    if (!user) return;
    try {
      const userOrders = await getOrdersByCustomer(user.uid);
      setOrders(userOrders);
    } catch (error) {
      console.error("Error loading orders:", error);
    } finally {
      setLoading(false);
    }
  };

  const list = orders.filter((o) => {
    if (tab === "all") return true;
    if (tab === "ongoing") return ONGOING.includes(o.status);
    if (tab === "completed") return o.status === "DELIVERED";
    if (tab === "cancelled") return o.status === "CANCELLED";
    return true;
  });

  if (loading) {
    return (
      <div className="space-y-4">
        <h1 className="text-lg font-semibold">Your orders</h1>
        <div className="flex gap-2">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="w-20 h-9 bg-gray-200 rounded-full animate-pulse"></div>
          ))}
        </div>
        <div className="space-y-3">
          {[1, 2, 3].map((i) => (
            <div key={i} className="h-32 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h1 className="text-lg font-semibold">Your orders</h1>

      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={`press shrink-0 px-4 h-9 rounded-full text-sm font-medium ${tab === t.id ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {t.label}
          </button>
        ))}
      </div>

      {list.length === 0 ? (
        <EmptyState icon={ClipboardList} title="No orders yet" desc="Your past and ongoing orders will appear here."
          action={<Link to="/explore" className="press h-11 px-5 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold inline-flex items-center">Start ordering</Link>} />
      ) : (
        <div className="space-y-3">
          {list.map((o) => (
            <Link key={o.id} to={`/orders/${o.id}`} className="press block card-soft rounded-2xl p-4">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-semibold">{o.storeName}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))] mt-0.5">
                    {o.createdAt ? new Date(o.createdAt.seconds ? o.createdAt.seconds * 1000 : o.createdAt).toLocaleString() : "Just now"}
                  </p>
                </div>
                <StatusBadge status={o.status} />
              </div>
              <p className="text-xs text-[hsl(var(--text-secondary))] mt-2 line-clamp-1">
                {o.items?.map((item) => item.name).join(" · ") || "Order items"}
              </p>
              <div className="flex items-center justify-between mt-3">
                <span className="text-sm font-bold">{formatPrice(o.total)}</span>
                <span className="text-xs text-[hsl(var(--accent))] font-medium">{ONGOING.includes(o.status) ? "Track order →" : "View details →"}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
