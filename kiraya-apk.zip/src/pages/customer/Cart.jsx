import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Trash2, Tag, X, Plus, Minus, ShoppingBag } from "lucide-react";
import { useCart } from "@/context/CartContext";
import { getCoupons } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import EmptyState from "@/components/customer/EmptyState";
import { useToast } from "@/components/ui/use-toast";
import { motion, AnimatePresence } from "framer-motion";

export default function Cart() {
  const { rows, byStore, setQty, remove, subtotal, deliveryFee, discount, taxes, platformFee, total, count, coupon, applyCoupon, removeCoupon } = useCart();
  const { toast } = useToast();
  const navigate = useNavigate();
  const [showCoupons, setShowCoupons] = useState(false);
  const [coupons, setCoupons] = useState([]);

  useEffect(() => {
    loadCoupons();
  }, []);

  const loadCoupons = async () => {
    try {
      const availableCoupons = await getCoupons();
      setCoupons(availableCoupons);
    } catch (error) {
      console.error("Error loading coupons:", error);
    }
  };

  const apply = (c) => {
    if (subtotal < c.minOrder) {
      toast({ title: "Coupon not applicable", description: `Minimum order ${formatPrice(c.minOrder)} required`, variant: "destructive" });
      return;
    }
    applyCoupon(c);
    setShowCoupons(false);
    toast({ title: "Coupon applied", description: c.title });
  };

  if (count === 0) {
    return (
      <div>
        <Header />
        <EmptyState icon={ShoppingBag} title="Your cart is empty" desc="Add items from your favourite stores to get started."
          action={<Link to="/explore" className="press h-11 px-5 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold inline-flex items-center">Browse stores</Link>} />
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <Header />

      {/* Items grouped by store */}
      <div className="space-y-4">
        {Object.entries(byStore).map(([storeId, storeData]) => (
          <div key={storeId} className="card-soft rounded-2xl p-4 space-y-3">
            <h3 className="text-sm font-semibold text-[hsl(var(--text-primary))]">{storeData.storeName}</h3>
            {storeData.items.map(({ product, qty }) => (
              <div key={product.id} className="flex items-center gap-3">
                <div className="w-14 h-14 rounded-xl bg-[hsl(var(--muted))] grid place-items-center text-[hsl(var(--text-tertiary))] text-lg font-semibold shrink-0 overflow-hidden">
                  {product.image ? (
                    <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                  ) : (
                    product.name.charAt(0)
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium line-clamp-1">{product.name}</p>
                  <p className="text-xs text-[hsl(var(--text-tertiary))]">{formatPrice(product.price)} each</p>
                  <div className="inline-flex items-center gap-1 mt-1.5 h-7 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]">
                    <button onClick={() => setQty(product.id, qty - 1, product)} className="press w-7 h-7 grid place-items-center"><Minus className="w-3 h-3" /></button>
                    <span className="text-xs font-bold w-4 text-center tabular-nums">{qty}</span>
                    <button onClick={() => setQty(product.id, qty + 1, product)} className="press w-7 h-7 grid place-items-center"><Plus className="w-3 h-3" /></button>
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-sm font-semibold">{formatPrice(product.price * qty)}</p>
                  <button onClick={() => remove(product.id)} className="press text-[hsl(var(--text-tertiary))] mt-1 inline-flex items-center gap-1 text-xs"><Trash2 className="w-3 h-3" />Remove</button>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>

      {/* Coupon */}
      <button onClick={() => setShowCoupons(true)} className="press w-full card-soft rounded-2xl p-4 flex items-center justify-between">
        <span className="inline-flex items-center gap-2 text-sm font-medium"><Tag className="w-4 h-4 text-[hsl(var(--accent))]" />
          {coupon ? coupon.code : "Apply coupon"}</span>
        {coupon ? <button onClick={(e) => { e.stopPropagation(); removeCoupon(); }} className="press text-xs text-[hsl(var(--text-tertiary))] inline-flex items-center gap-1"><X className="w-3 h-3" />Remove</button> : <span className="text-xs text-[hsl(var(--text-tertiary))]">{coupons.length} available</span>}
      </button>

      {/* Bill summary */}
      <div className="card-soft rounded-2xl p-4 space-y-2.5 text-sm">
        <Row label="Subtotal" value={formatPrice(subtotal)} />
        <Row label="Delivery" value={deliveryFee === 0 ? "Free" : formatPrice(deliveryFee)} />
        <Row label="Platform fee" value={formatPrice(platformFee)} />
        <Row label="Taxes" value={formatPrice(taxes)} />
        {discount > 0 && <Row label="Discount" value={`− ${formatPrice(discount)}`} tone="success" />}
        <div className="border-t border-[hsl(var(--border))] pt-2.5 flex items-center justify-between">
          <span className="font-semibold">Total</span>
          <span className="text-lg font-bold">{formatPrice(total)}</span>
        </div>
      </div>

      {/* Sticky checkout */}
      <div className="fixed bottom-0 inset-x-0 z-40 glass-strong border-t border-[hsl(var(--glass-border))] safe-bottom">
        <div className="max-w-md mx-auto px-4 py-3 flex items-center gap-3">
          <div>
            <p className="text-[11px] text-[hsl(var(--text-tertiary))]">{count} items</p>
            <p className="text-lg font-bold">{formatPrice(total)}</p>
          </div>
          <button onClick={() => navigate("/checkout")} className="press flex-1 h-12 rounded-2xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] font-semibold text-sm">
            Continue to checkout
          </button>
        </div>
      </div>
      <div className="h-20" />

      {/* Coupon sheet */}
      <AnimatePresence>
        {showCoupons && (
          <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowCoupons(false)}>
            <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
            <motion.div initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }} transition={{ type: "spring", stiffness: 360, damping: 34 }}
              className="relative w-full max-w-md mx-auto rounded-t-3xl glass-strong p-5 safe-bottom" onClick={(e) => e.stopPropagation()}>
              <div className="w-10 h-1 rounded-full bg-[hsl(var(--border))] mx-auto mb-4" />
              <h3 className="text-base font-semibold mb-3">Available coupons</h3>
              <div className="space-y-3">
                {coupons.map((c) => (
                  <div key={c.code} className="card-soft rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <p className="text-sm font-bold text-[hsl(var(--accent))]">{c.title}</p>
                      <p className="text-xs text-[hsl(var(--text-secondary))]">{c.description}</p>
                      <p className="text-[11px] text-[hsl(var(--text-tertiary))] mt-0.5">Min order: {formatPrice(c.minOrder)} · {c.code}</p>
                    </div>
                    <button onClick={() => apply(c)} className="press h-9 px-3 rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-xs font-semibold">Apply</button>
                  </div>
                ))}
                {coupons.length === 0 && (
                  <p className="text-sm text-[hsl(var(--text-tertiary))] text-center py-4">No coupons available</p>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

function Header() {
  const navigate = useNavigate();
  return (
    <div className="flex items-center gap-3">
      <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
      <h1 className="text-lg font-semibold">Cart</h1>
    </div>
  );
}

function Row({ label, value, tone }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-[hsl(var(--text-secondary))]">{label}</span>
      <span className={tone === "success" ? "text-[hsl(var(--success))] font-medium" : "font-medium"}>{value}</span>
    </div>
  );
}
