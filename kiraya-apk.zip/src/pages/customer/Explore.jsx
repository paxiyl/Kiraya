import React, { useMemo, useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { Search, SlidersHorizontal, X } from "lucide-react";
import { motion } from "framer-motion";
import { getCategories, getProducts, getStores, searchProducts } from "@/lib/firestore";
import ProductCard from "@/components/customer/ProductCard";
import StoreCard from "@/components/customer/StoreCard";
import EmptyState from "@/components/customer/EmptyState";
import { Pill } from "@/components/customer/StatusBadge";

export default function Explore() {
  const [params, setParams] = useSearchParams();
  const cat = params.get("cat") || "all";
  const type = params.get("type");
  const [q, setQ] = useState("");
  const [sort, setSort] = useState("relevance");
  const [maxEta, setMaxEta] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [loading, setLoading] = useState(true);

  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [stores, setStores] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [cats, prods, stors] = await Promise.all([
        getCategories(),
        getProducts(),
        getStores(),
      ]);
      setCategories(cats);
      setProducts(prods);
      setStores(stors);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const setCat = (c) => setParams(c === "all" ? {} : { cat: c });

  const results = useMemo(() => {
    let list = products;
    if (cat !== "all") list = list.filter((p) => p.category === cat);
    if (q.trim()) {
      const t = q.toLowerCase();
      list = list.filter((p) => p.name.toLowerCase().includes(t) || p.storeName?.toLowerCase().includes(t));
    }
    if (maxEta) list = list.filter((p) => /15-25|20-30/.test(p.eta));
    if (sort === "priceLow") list = [...list].sort((a, b) => a.price - b.price);
    if (sort === "priceHigh") list = [...list].sort((a, b) => b.price - a.price);
    if (sort === "rating") list = [...list].sort((a, b) => b.rating - a.rating);
    return list;
  }, [cat, q, sort, maxEta, products]);

  const storeResults = useMemo(() => {
    let list = stores;
    if (type) list = list.filter((s) => s.type === type);
    if (cat !== "all") list = list.filter((s) => s.category === cat);
    if (q.trim()) list = list.filter((s) => s.name.toLowerCase().includes(q.toLowerCase()));
    return list;
  }, [cat, type, q, stores]);

  const activeFilters = (sort !== "relevance" ? 1 : 0) + (maxEta ? 1 : 0);
  const toggleTrack = maxEta ? "translate-x-4" : "translate-x-0.5";
  const toggleBg = maxEta ? "bg-[hsl(var(--accent))]" : "bg-[hsl(var(--border))]";

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="flex items-center gap-2 animate-pulse">
          <div className="flex-1 h-12 bg-gray-200 rounded-2xl"></div>
          <div className="w-12 h-12 bg-gray-200 rounded-2xl"></div>
        </div>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map((i) => (
            <div key={i} className="w-16 h-8 bg-gray-200 rounded-full animate-pulse"></div>
          ))}
        </div>
        <div className="grid grid-cols-2 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-40 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <div className="flex-1 flex items-center gap-2.5 h-12 px-4 rounded-2xl glass">
          <Search className="w-4.5 h-4.5 text-[hsl(var(--text-tertiary))]" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search products, stores, brands…"
            className="flex-1 bg-transparent outline-none text-sm placeholder:text-[hsl(var(--text-tertiary))]"
          />
          {q && <button onClick={() => setQ("")}><X className="w-4 h-4 text-[hsl(var(--text-tertiary))]" /></button>}
        </div>
        <button onClick={() => setShowFilters(true)} className="press relative w-12 h-12 rounded-2xl glass grid place-items-center">
          <SlidersHorizontal className="w-4.5 h-4.5" />
          {activeFilters > 0 && (
            <span className="absolute -top-1 -right-1 min-w-4 h-4 px-1 rounded-full bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-[10px] font-bold grid place-items-center">{activeFilters}</span>
          )}
        </button>
      </div>

      {/* Category pills */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4">
        <button onClick={() => setCat("all")} className="press shrink-0">
          <Pill tone={cat === "all" ? "accent" : "neutral"}>All</Pill>
        </button>
        {categories.map((c) => (
          <button key={c.id} onClick={() => setCat(c.id)} className="press shrink-0">
            <Pill tone={cat === c.id ? "accent" : "neutral"}>{c.name}</Pill>
          </button>
        ))}
      </div>

      {/* Stores */}
      {storeResults.length > 0 && (
        <section>
          <h2 className="text-sm font-semibold mb-2 text-[hsl(var(--text-primary))]">Stores</h2>
          <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4">
            {storeResults.map((s) => <div key={s.id} className="w-60 shrink-0"><StoreCard store={s} /></div>)}
          </div>
        </section>
      )}

      {/* Products */}
      <section>
        <h2 className="text-sm font-semibold mb-2 text-[hsl(var(--text-primary))]">
          Products <span className="text-[hsl(var(--text-tertiary))] font-normal">· {results.length}</span>
        </h2>
        {results.length === 0 ? (
          <EmptyState icon={Search} title="No products found" desc="Try a different search or clear filters." />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {results.map((p, i) => (
              <motion.div key={p.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.03, duration: 0.3 }}>
                <ProductCard product={p} />
              </motion.div>
            ))}
          </div>
        )}
      </section>

      {/* Filter bottom sheet */}
      {showFilters && (
        <div className="fixed inset-0 z-50 flex items-end" onClick={() => setShowFilters(false)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <motion.div
            initial={{ y: "100%" }} animate={{ y: 0 }} exit={{ y: "100%" }}
            transition={{ type: "spring", stiffness: 360, damping: 34 }}
            className="relative w-full max-w-md mx-auto rounded-t-3xl glass-strong p-5 safe-bottom"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-[hsl(var(--border))] mx-auto mb-4" />
            <h3 className="text-base font-semibold mb-4">Filters</h3>
            <div className="space-y-4">
              <div>
                <p className="text-xs font-medium text-[hsl(var(--text-secondary))] mb-2">Sort</p>
                <div className="flex flex-wrap gap-2">
                  {[["relevance","Relevant"],["priceLow","Price: Low"],["priceHigh","Price: High"],["rating","Rating"]].map(([v,l]) => (
                    <button key={v} onClick={() => setSort(v)} className="press"><Pill tone={sort===v?"accent":"neutral"}>{l}</Pill></button>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs font-medium text-[hsl(var(--text-secondary))] mb-2">Delivery</p>
                <button onClick={() => setMaxEta(!maxEta)} className="press flex items-center justify-between w-full p-3 rounded-xl card-soft">
                  <span className="text-sm">Express only (≤30 min)</span>
                  <span className={"w-10 h-6 rounded-full transition-colors " + toggleBg}>
                    <span className={"block w-5 h-5 rounded-full bg-white transition-transform mt-0.5 " + toggleTrack} />
                  </span>
                </button>
              </div>
            </div>
            <div className="flex gap-2 mt-5">
              <button onClick={() => { setSort("relevance"); setMaxEta(false); }} className="press flex-1 h-11 rounded-xl card-soft text-sm font-medium">Clear</button>
              <button onClick={() => setShowFilters(false)} className="press flex-1 h-11 rounded-xl bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] text-sm font-semibold">Apply</button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
