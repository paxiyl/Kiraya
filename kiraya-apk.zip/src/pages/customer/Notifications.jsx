import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { ArrowLeft, Bell, Package, Tag, Sparkles, Gift } from "lucide-react";
import { getNotifications } from "@/lib/firestore";
import { useAuth } from "@/lib/AuthContext";

const ICONS = { package: Package, tag: Tag, sparkles: Sparkles, gift: Gift };
const TONES = {
  accent: "bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))]",
  success: "bg-[hsl(var(--success-soft))] text-[hsl(var(--success))]",
  warning: "bg-[hsl(var(--warning-soft))] text-[hsl(var(--warning))]",
  neutral: "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]",
};

export default function Notifications() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadNotifications(); }, [user]);

  const loadNotifications = async () => {
    if (!user) return;
    try {
      const notifs = await getNotifications(user.uid);
      setNotifications(notifs);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <button onClick={() => navigate(-1)} className="press w-10 h-10 rounded-full glass grid place-items-center"><ArrowLeft className="w-4.5 h-4.5" /></button>
        <h1 className="text-lg font-semibold">Notifications</h1>
      </div>

      {loading ? (
        <div className="space-y-2">
          {[1, 2, 3].map((i) => <div key={i} className="h-20 bg-gray-200 rounded-2xl animate-pulse" />)}
        </div>
      ) : notifications.length === 0 ? (
        <div className="py-20 text-center">
          <Bell className="w-12 h-12 mx-auto text-[hsl(var(--text-tertiary))] mb-3" />
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No notifications yet</p>
        </div>
      ) : (
        <div className="space-y-2">
          {notifications.map((n) => {
            const Icon = ICONS[n.icon] || Bell;
            return (
              <div key={n.id} className={`card-soft rounded-2xl p-4 flex gap-3 ${n.read ? "opacity-70" : ""}`}>
                <div className={`w-10 h-10 rounded-xl grid place-items-center shrink-0 ${TONES[n.tone] || TONES.neutral}`}><Icon className="w-4.5 h-4.5" /></div>
                <div className="flex-1">
                  <p className="text-sm font-medium">{n.title}</p>
                  <p className="text-xs text-[hsl(var(--text-secondary))] mt-0.5">{n.body || n.desc}</p>
                  <p className="text-[11px] text-[hsl(var(--text-tertiary))] mt-1">{n.time || "Just now"}</p>
                </div>
                {!n.read && <span className="w-2 h-2 rounded-full bg-[hsl(var(--accent))] mt-1.5" />}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
