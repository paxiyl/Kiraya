import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Search, Bell, ChevronDown, MapPin, Zap, Heart } from "lucide-react";
import { APP_CONFIG } from "@/lib/appConfig";
import { getCategories, getStores, getProducts } from "@/lib/firestore";
import CategoryStrip from "@/components/customer/CategoryStrip";
import SectionHeader from "@/components/customer/SectionHeader";
import ProductCard from "@/components/customer/ProductCard";
import StoreCard from "@/components/customer/StoreCard";
import { useAuth } from "@/lib/AuthContext";

const fade = {
  hidden: { opacity: 0, y: 12 },
  show: (i = 0) => ({ opacity: 1, y: 0, transition: { delay: i * 0.04, duration: 0.4, ease: [0.22, 1, 0.36, 1] } }),
};

function HeroBanner() {
  return (
    <div className="relative overflow-hidden rounded-3xl p-5 text-white"
      style={{ background: "linear-gradient(135deg, hsl(152 58% 38%), hsl(172 60% 30%))" }}>
      <div className="absolute -right-8 -top-8 w-32 h-32 rounded-full bg-white/10 blur-xl" />
      <p className="text-xs/5 opacity-90 font-medium">{APP_CONFIG.tagline}</p>
      <h2 className="text-xl font-bold mt-1 leading-tight">Get anything, delivered fast.</h2>
      <p className="text-xs opacity-85 mt-1">Food, groceries, meds, electronics & more — from local shops in {APP_CONFIG.city}.</p>
      <Link to="/explore" className="press inline-flex items-center gap-1 mt-3 px-3 py-1.5 rounded-full bg-white text-[hsl(152 58% 30%)] text-xs font-semibold">
        Start exploring
      </Link>
    </div>
  );
}

export default function Home() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [categories, setCategories] = useState([]);
  const [stores, setStores] = useState([]);
  const [products, setProducts] = useState([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [cats, stor, prod] = await Promise.all([
        getCategories(),
        getStores(),
        getProducts(),
      ]);
      setCategories(cats);
      setStores(stor);
      setProducts(prod);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  const restaurants = stores.filter((s) => s.type === "restaurant");
  const quick = products.filter((p) => p.eta && /15-25|20-30/.test(p.eta)).slice(0, 6);
  const grocery = products.filter((p) => p.category === "grocery").slice(0, 4);
  const beauty = products.filter((p) => p.category === "beauty").slice(0, 4);
  const electronics = products.filter((p) => p.category === "electronics").slice(0, 4);
  const under499 = products.filter((p) => p.price < 499).slice(0, 4);

  if (loading) {
    return (
      <div className="space-y-7">
        <div className="flex items-center gap-3 animate-pulse">
          <div className="flex-1 space-y-2">
            <div className="h-3 w-20 bg-gray-200 rounded"></div>
            <div className="h-4 w-32 bg-gray-200 rounded"></div>
          </div>
        </div>
        <div className="h-32 bg-gray-200 rounded-3xl animate-pulse"></div>
        <div className="flex gap-3 overflow-x-auto">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="w-16 h-16 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
        <div className="flex gap-3 overflow-x-auto">
          {[1, 2, 3].map((i) => (
            <div key={i} className="w-44 h-32 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-7">
      {/* Top bar */}
      <motion.div variants={fade} initial="hidden" animate="show" className="flex items-center gap-3">
        <div className="flex-1 min-w-0">
          <p className="text-[11px] text-[hsl(var(--text-tertiary))] flex items-center gap-1">
            <MapPin className="w-3 h-3" /> Delivering to
          </p>
          <button className="press flex items-center gap-1 -ml-0.5">
            <span className="text-sm font-semibold text-[hsl(var(--text-primary))]">Home · {APP_CONFIG.city}</span>
            <ChevronDown className="w-4 h-4 text-[hsl(var(--text-tertiary))]" />
          </button>
        </div>
        <Link to="/notifications" className="press relative w-10 h-10 rounded-full glass grid place-items-center">
          <Bell className="w-4.5 h-4.5 text-[hsl(var(--text-primary))]" />
          <span className="absolute top-2 right-2.5 w-2 h-2 rounded-full bg-[hsl(var(--accent))]" />
        </Link>
        <Link to="/profile" className="press w-10 h-10 rounded-full bg-[hsl(var(--accent-soft))] grid place-items-center text-[hsl(var(--accent))] font-semibold text-sm">
          {user?.displayName?.charAt(0) || "U"}
        </Link>
      </motion.div>

      {/* Search */}
      <Link to="/explore" className="block">
        <motion.div variants={fade} custom={1} initial="hidden" animate="show"
          className="press flex items-center gap-2.5 h-12 px-4 rounded-2xl glass">
          <Search className="w-4.5 h-4.5 text-[hsl(var(--text-tertiary))]" />
          <span className="text-sm text-[hsl(var(--text-tertiary))]">What are you looking for?</span>
        </motion.div>
      </Link>

      <HeroBanner />

      {/* Categories */}
      <motion.section variants={fade} custom={2} initial="hidden" animate="show">
        <CategoryStrip categories={categories} />
      </motion.section>

      {/* Quick delivery */}
      {quick.length > 0 && (
        <motion.section variants={fade} custom={3} initial="hidden" animate="show">
          <SectionHeader title="Arrives in 15–30 min" subtitle="Express from nearby stores" to="/explore?cat=food" />
          <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4">
            {quick.map((p) => (
              <div key={p.id} className="w-44 shrink-0"><ProductCard product={p} /></div>
            ))}
          </div>
        </motion.section>
      )}

      {/* Restaurants */}
      {restaurants.length > 0 && (
        <motion.section variants={fade} custom={4} initial="hidden" animate="show">
          <SectionHeader title="Restaurants near you" subtitle="Top-rated local kitchens" to="/explore?type=restaurant" />
          <div className="flex gap-3 overflow-x-auto no-scrollbar -mx-4 px-4">
            {restaurants.map((s) => (
              <div key={s.id} className="w-64 shrink-0"><StoreCard store={s} /></div>
            ))}
          </div>
        </motion.section>
      )}

      {/* Everything store sections */}
      {grocery.length > 0 && (
        <motion.section variants={fade} custom={5} initial="hidden" animate="show">
          <SectionHeader title="Fresh groceries" to="/explore?cat=grocery" />
          <div className="grid grid-cols-2 gap-3">{grocery.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        </motion.section>
      )}

      {beauty.length > 0 && (
        <motion.section variants={fade} custom={6} initial="hidden" animate="show">
          <SectionHeader title="Beauty & personal care" to="/explore?cat=beauty" />
          <div className="grid grid-cols-2 gap-3">{beauty.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        </motion.section>
      )}

      {electronics.length > 0 && (
        <motion.section variants={fade} custom={7} initial="hidden" animate="show">
          <SectionHeader title="Trending electronics" to="/explore?cat=electronics" />
          <div className="grid grid-cols-2 gap-3">{electronics.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        </motion.section>
      )}

      {under499.length > 0 && (
        <motion.section variants={fade} custom={8} initial="hidden" animate="show">
          <SectionHeader title="Under ₹499" subtitle="Pocket-friendly picks" to="/explore" />
          <div className="grid grid-cols-2 gap-3">{under499.map((p) => <ProductCard key={p.id} product={p} />)}</div>
        </motion.section>
      )}

      {products.length === 0 && !loading && (
        <div className="text-center py-10">
          <p className="text-sm text-[hsl(var(--text-tertiary))]">No products available yet.</p>
          <p className="text-xs text-[hsl(var(--text-tertiary))] mt-1">Store owners can add products from the store panel.</p>
        </div>
      )}

      <div className="pt-2 text-center">
        <p className="text-[11px] text-[hsl(var(--text-tertiary))]">
          {APP_CONFIG.name} · {APP_CONFIG.tagline}
        </p>
      </div>
    </div>
  );
}
