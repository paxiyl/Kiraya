import React, { useState, useEffect } from "react";
import DataTable from "@/components/admin/DataTable";
import { formatPrice } from "@/lib/appConfig";
import { Pill } from "@/components/customer/StatusBadge";
import { X } from "lucide-react";
import { db } from "@/lib/firebase";
import { collection, query, where, getDocs } from "firebase/firestore";

export default function AdminCustomers() {
  const [detail, setDetail] = useState(null);
  const [customers, setCustomers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadCustomers(); }, []);

  const loadCustomers = async () => {
    try {
      const snap = await getDocs(query(collection(db, "users"), where("role", "==", "customer")));
      setCustomers(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const columns = [
    { key: "displayName", label: "Customer", render: (r) => <span className="font-medium">{r.displayName}</span>, sortable: true },
    { key: "phone", label: "Phone" },
    { key: "email", label: "Email" },
  ];

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /><div className="h-4 w-48 bg-gray-200 rounded" /></div>
      <div className="h-64 bg-gray-200 rounded-2xl animate-pulse" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Customers</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{customers.length} customers</p>
      </div>
      <DataTable columns={columns} rows={customers} searchKeys={["displayName", "phone", "email"]} onRowClick={setDetail} />
      {detail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm card-soft rounded-3xl p-5">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center font-bold">{(detail.displayName || "U").charAt(0)}</div>
              <div>
                <h3 className="text-base font-semibold">{detail.displayName}</h3>
                <Pill tone="accent">{detail.role}</Pill>
              </div>
              <button onClick={() => setDetail(null)} className="press ml-auto w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>
            <div className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Phone</span><span className="font-medium">{detail.phone || "—"}</span></div>
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Email</span><span className="font-medium">{detail.email}</span></div>
              <div className="flex justify-between"><span className="text-[hsl(var(--text-tertiary))]">Joined</span><span className="font-medium">{detail.createdAt ? new Date(detail.createdAt).toLocaleDateString() : "—"}</span></div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
