import React, { useState, useEffect } from "react";
import DataTable from "@/components/admin/DataTable";
import StatusBadge from "@/components/customer/StatusBadge";
import { getAllOrders } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { X } from "lucide-react";

const FILTERS = [
  { id: "all", label: "All" },
  { id: "PENDING", label: "Pending" },
  { id: "ACCEPTED", label: "Accepted" },
  { id: "PREPARING", label: "Preparing" },
  { id: "OUT_FOR_DELIVERY", label: "On the way" },
  { id: "DELIVERED", label: "Delivered" },
  { id: "CANCELLED", label: "Cancelled" },
];

export default function AdminOrders() {
  const [filter, setFilter] = useState("all");
  const [detail, setDetail] = useState(null);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadOrders(); }, []);

  const loadOrders = async () => {
    try {
      const data = await getAllOrders();
      setOrders(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const rows = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  const columns = [
    { key: "id", label: "Order", render: (r) => <span className="font-medium">{r.id?.slice(0, 8)}...</span>, sortable: true },
    { key: "customerName", label: "Customer", sortable: true },
    { key: "storeName", label: "Store" },
    { key: "total", label: "Amount", render: (r) => <span className="font-medium">{formatPrice(r.total)}</span>, sortable: true },
    { key: "paymentMethod", label: "Payment" },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /><div className="h-4 w-48 bg-gray-200 rounded" /></div>
      <div className="flex gap-2">{[1,2,3,4].map(i => <div key={i} className="w-20 h-9 bg-gray-200 rounded-full animate-pulse" />)}</div>
      <div className="h-64 bg-gray-200 rounded-2xl animate-pulse" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Orders</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Manage all platform orders</p>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {FILTERS.map((f) => (
          <button key={f.id} onClick={() => setFilter(f.id)}
            className={`press shrink-0 px-3.5 h-9 rounded-full text-sm font-medium ${filter === f.id ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {f.label}
          </button>
        ))}
      </div>

      <DataTable columns={columns} rows={rows} searchKeys={["id", "customerName", "storeName"]} onRowClick={setDetail} />

      {detail && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={() => setDetail(null)}>
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" />
          <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-md card-soft rounded-3xl p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold">{detail.id?.slice(0, 8)}...</h3>
              <button onClick={() => setDetail(null)} className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><X className="w-4 h-4" /></button>
            </div>
            <StatusBadge status={detail.status} />
            <div className="mt-4 space-y-2 text-sm">
              <Row k="Customer" v={detail.customerName} />
              <Row k="Store" v={detail.storeName} />
              <Row k="Payment" v={detail.paymentMethod} />
              <Row k="Amount" v={formatPrice(detail.total)} bold />
              <Row k="Items" v={detail.items?.map(i => `${i.name} ×${i.qty}`).join(", ") || "—"} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function Row({ k, v, bold }) {
  return (
    <div className="flex justify-between border-b border-[hsl(var(--border))] pb-2">
      <span className="text-[hsl(var(--text-tertiary))]">{k}</span>
      <span className={bold ? "font-bold" : "font-medium"}>{v}</span>
    </div>
  );
}
