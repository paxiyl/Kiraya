import React, { useState, useEffect } from "react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart, OrdersChart, CategoryPie } from "@/components/admin/Charts";
import { getWeeklyRevenue, getAllOrders } from "@/lib/firestore";
import { TrendingUp, Percent, Bike, Ban } from "lucide-react";

export default function AdminAnalytics() {
  const [weeklyData, setWeeklyData] = useState([]);
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadData(); }, []);

  const loadData = async () => {
    try {
      const [week, ords] = await Promise.all([getWeeklyRevenue(), getAllOrders()]);
      setWeeklyData(week);
      setOrders(ords);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const totalRev = weeklyData.reduce((s, d) => s + d.revenue, 0);
  const totalOrders = weeklyData.reduce((s, d) => s + d.orders, 0);
  const cancelled = orders.filter(o => o.status === "CANCELLED").length;
  const cancelRate = orders.length ? ((cancelled / orders.length) * 100).toFixed(1) : 0;

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /></div>
      <div className="h-64 bg-gray-200 rounded-2xl animate-pulse" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Analytics</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Performance insights</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Weekly Revenue" value={totalRev} prefix="₹" icon={TrendingUp} delta="+12.4%" up tone="accent" />
        <StatCard label="Weekly Orders" value={totalOrders} icon={Percent} delta="+6.1%" up tone="success" />
        <StatCard label="Avg Delivery Time" value={24} suffix=" min" icon={Bike} delta="-2 min" up tone="warning" />
        <StatCard label="Cancellation Rate" value={cancelRate} suffix="%" icon={Ban} tone="danger" />
      </div>
      <div className="grid lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Revenue trend</h3>
          <RevenueChart data={weeklyData} />
        </div>
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Category mix</h3>
          <CategoryPie data={[
            { name: "Food", value: 38, color: "hsl(152 58% 38%)" },
            { name: "Grocery", value: 24, color: "hsl(142 60% 42%)" },
            { name: "Electronics", value: 12, color: "hsl(220 70% 52%)" },
            { name: "Beauty", value: 10, color: "hsl(280 60% 60%)" },
            { name: "Other", value: 16, color: "hsl(38 92% 50%)" },
          ]} />
        </div>
      </div>
      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-3">Orders volume</h3>
        <OrdersChart data={weeklyData} />
      </div>
    </div>
  );
}
