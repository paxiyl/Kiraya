import React, { useState, useEffect } from "react";
import StatCard from "@/components/admin/StatCard";
import DataTable from "@/components/admin/DataTable";
import { Bike, Star, Navigation } from "lucide-react";
import { formatPrice } from "@/lib/appConfig";
import { Pill } from "@/components/customer/StatusBadge";
import { db } from "@/lib/firebase";
import { collection, getDocs } from "firebase/firestore";

export default function AdminDelivery() {
  const [partners, setPartners] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadPartners(); }, []);

  const loadPartners = async () => {
    try {
      const snap = await getDocs(collection(db, "deliveryPartners"));
      setPartners(snap.docs.map(d => ({ id: d.id, ...d.data() })));
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const cols = [
    { key: "name", label: "Partner", render: (r) => (
      <div className="flex items-center gap-2">
        <div className="w-8 h-8 rounded-full bg-[hsl(var(--accent-soft))] text-[hsl(var(--accent))] grid place-items-center text-xs font-bold">{(r.name || "D").charAt(0)}</div>
        <span className="font-medium">{r.name}</span>
      </div>
    ), sortable: true },
    { key: "vehicle", label: "Vehicle" },
    { key: "totalDeliveries", label: "Completed", sortable: true },
    { key: "earnings", label: "Earnings", render: (r) => formatPrice(r.earnings || 0), sortable: true },
    { key: "rating", label: "Rating", render: (r) => <span className="inline-flex items-center gap-0.5"><Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {r.rating || 0}</span>, sortable: true },
    { key: "isOnline", label: "Status", render: (r) => <Pill tone={r.isOnline ? "success" : "neutral"}><span className={`w-1.5 h-1.5 rounded-full ${r.isOnline ? "bg-current" : "bg-current opacity-40"}`} /> {r.isOnline ? "Online" : "Offline"}</Pill> },
  ];

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-48 bg-gray-200 rounded mb-2" /></div>
      <div className="h-64 bg-gray-200 rounded-2xl animate-pulse" />
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Delivery Partners</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">{partners.length} partners · real-time status</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Online Now" value={partners.filter(p => p.isOnline).length} icon={Bike} tone="accent" />
        <StatCard label="Total Partners" value={partners.length} icon={Navigation} tone="warning" />
        <StatCard label="Total Earnings" value={partners.reduce((s, p) => s + (p.earnings || 0), 0)} prefix="₹" icon={Bike} tone="success" />
        <StatCard label="Avg Rating" value={partners.length ? (partners.reduce((s, p) => s + (p.rating || 0), 0) / partners.length).toFixed(1) : "0"} icon={Star} tone="neutral" />
      </div>
      <DataTable columns={cols} rows={partners} searchKeys={["name", "vehicle"]} />
    </div>
  );
}
