import React, { useState, useEffect } from "react";
import StatCard from "@/components/admin/StatCard";
import DataTable from "@/components/admin/DataTable";
import { getAllOrders } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import { Wallet, TrendingUp, RefreshCw, CreditCard } from "lucide-react";
import { Pill } from "@/components/customer/StatusBadge";

export default function AdminPayments() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => { loadOrders(); }, []);

  const loadOrders = async () => {
    try {
      const data = await getAllOrders();
      setOrders(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const txns = orders.map((o) => ({
    ...o,
    txnId: "TXN" + o.id?.slice(0, 8),
    amount: o.total,
    method: o.paymentMethod,
    status: o.status === "CANCELLED" ? "Refunded" : o.paymentMethod === "cod" ? "COD" : "Paid",
  }));

  const cols = [
    { key: "txnId", label: "Txn ID", render: (r) => <span className="font-medium">{r.txnId}</span> },
    { key: "customerName", label: "Customer" },
    { key: "storeName", label: "Store" },
    { key: "method", label: "Method" },
    { key: "amount", label: "Amount", render: (r) => formatPrice(r.amount), sortable: true },
    { key: "status", label: "Status", render: (r) => <Pill tone={r.status === "Paid" ? "success" : r.status === "Refunded" ? "danger" : "neutral"}>{r.status}</Pill> },
  ];

  const total = txns.reduce((s, t) => s + (t.amount || 0), 0);

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /></div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">{[1,2,3,4].map(i => <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse" />)}</div>
    </div>
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Payments</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Transactions & settlement</p>
      </div>
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <StatCard label="Gross Volume" value={total} prefix="₹" icon={Wallet} tone="accent" />
        <StatCard label="Net Revenue" value={Math.round(total * 0.12)} prefix="₹" icon={TrendingUp} tone="success" />
        <StatCard label="Refunds" value={txns.filter(t => t.status === "Refunded").length} icon={RefreshCw} tone="danger" />
        <StatCard label="COD Orders" value={txns.filter(t => t.method === "cod").length} icon={CreditCard} tone="warning" />
      </div>
      <DataTable columns={cols} rows={txns} searchKeys={["txnId", "customerName", "storeName"]} />
    </div>
  );
}
