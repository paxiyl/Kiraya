import React, { useState, useEffect } from "react";
import { Wallet, ShoppingCart, Bike, Users, Store, Package, Clock, Ban } from "lucide-react";
import StatCard from "@/components/admin/StatCard";
import { RevenueChart, OrdersChart, CategoryPie } from "@/components/admin/Charts";
import DataTable from "@/components/admin/DataTable";
import { getAdminStats, getWeeklyRevenue, getAllOrders } from "@/lib/firestore";
import { formatPrice } from "@/lib/appConfig";
import StatusBadge from "@/components/customer/StatusBadge";

export default function AdminDashboard() {
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState([]);
  const [weeklyRevenue, setWeeklyRevenue] = useState([]);
  const [recentOrders, setRecentOrders] = useState([]);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      const [adminStatsData, weeklyData, orders] = await Promise.all([
        getAdminStats(),
        getWeeklyRevenue(),
        getAllOrders(),
      ]);

      setStats([
        { key: "revenue", label: "Total Revenue", value: adminStatsData.totalRevenue, prefix: "₹", delta: "+12.4%", up: true },
        { key: "orders", label: "Today's Orders", value: adminStatsData.todayOrders, delta: "+6.1%", up: true },
        { key: "activeDeliveries", label: "Active Deliveries", value: adminStatsData.pendingOrders, delta: "+3", up: true },
        { key: "customers", label: "Active Customers", value: adminStatsData.activeCustomers, delta: "+182", up: true },
        { key: "stores", label: "Active Stores", value: adminStatsData.activeStores, delta: "+4", up: true },
        { key: "partners", label: "Delivery Partners", value: adminStatsData.activePartners, delta: "+8", up: true },
        { key: "pending", label: "Pending Orders", value: adminStatsData.pendingOrders, delta: "—", up: null },
        { key: "cancelled", label: "Cancelled", value: adminStatsData.cancelledOrders, delta: "-4", up: false },
      ]);

      setWeeklyRevenue(weeklyData);
      setRecentOrders(orders.slice(0, 10));
    } catch (error) {
      console.error("Error loading dashboard data:", error);
    } finally {
      setLoading(false);
    }
  };

  const ICONS = {
    revenue: Wallet,
    orders: ShoppingCart,
    activeDeliveries: Bike,
    customers: Users,
    stores: Store,
    partners: Package,
    pending: Clock,
    cancelled: Ban,
  };

  const recentCols = [
    { key: "id", label: "Order", render: (r) => <span className="font-medium">{r.id?.slice(0, 8)}...</span> },
    { key: "customerName", label: "Customer" },
    { key: "storeName", label: "Store" },
    { key: "total", label: "Amount", render: (r) => formatPrice(r.total), sortable: true },
    { key: "status", label: "Status", render: (r) => <StatusBadge status={r.status} /> },
  ];

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse">
          <div className="h-6 w-48 bg-gray-200 rounded mb-2"></div>
          <div className="h-4 w-64 bg-gray-200 rounded"></div>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-24 bg-gray-200 rounded-2xl animate-pulse"></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 h-64 bg-gray-200 rounded-2xl animate-pulse"></div>
          <div className="h-64 bg-gray-200 rounded-2xl animate-pulse"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-sm text-[hsl(var(--text-tertiary))]">Overview of platform performance</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.slice(0, 4).map(({ key, ...rest }) => {
          const Icon = ICONS[key];
          const tone = key === "cancelled" ? "danger" : key === "pending" ? "warning" : "accent";
          return <StatCard key={key} {...rest} icon={Icon} tone={tone} />;
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Revenue (last 7 days)</h3>
          <RevenueChart data={weeklyRevenue} />
        </div>
        <div className="card-soft rounded-2xl p-4">
          <h3 className="text-sm font-semibold mb-3">Orders by category</h3>
          <CategoryPie data={[
            { name: "Food", value: 38, color: "hsl(152 58% 38%)" },
            { name: "Grocery", value: 24, color: "hsl(142 60% 42%)" },
            { name: "Electronics", value: 12, color: "hsl(220 70% 52%)" },
            { name: "Beauty", value: 10, color: "hsl(280 60% 60%)" },
            { name: "Other", value: 16, color: "hsl(38 92% 50%)" },
          ]} />
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {stats.slice(4).map(({ key, ...rest }) => {
          const Icon = ICONS[key];
          const tone = key === "cancelled" ? "danger" : "accent";
          return <StatCard key={key} {...rest} icon={Icon} tone={tone} />;
        })}
      </div>

      <div className="card-soft rounded-2xl p-4">
        <h3 className="text-sm font-semibold mb-1">Orders (last 7 days)</h3>
        <OrdersChart data={weeklyRevenue} />
      </div>

      <div>
        <h3 className="text-sm font-semibold mb-3">Recent orders</h3>
        <DataTable columns={recentCols} rows={recentOrders} searchKeys={["id", "customerName", "storeName"]} title="" />
      </div>
    </div>
  );
}
