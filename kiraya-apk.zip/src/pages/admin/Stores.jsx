import React, { useState, useEffect } from "react";
import { getStores } from "@/lib/firestore";
import { Star, Clock, MapPin, MoreVertical, BadgePercent } from "lucide-react";
import { Pill } from "@/components/customer/StatusBadge";

const STATUS = { true: "success", false: "warning" };

export default function AdminStores() {
  const [loading, setLoading] = useState(true);
  const [stores, setStores] = useState([]);
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => { loadStores(); }, []);

  const loadStores = async () => {
    try {
      const data = await getStores();
      setStores(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  const filtered = statusFilter === "all" ? stores : stores.filter((s) => String(s.isOpen) === statusFilter);

  if (loading) return (
    <div className="space-y-5">
      <div className="animate-pulse"><div className="h-6 w-32 bg-gray-200 rounded mb-2" /><div className="h-4 w-48 bg-gray-200 rounded" /></div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">{[1,2,3].map(i => <div key={i} className="h-40 bg-gray-200 rounded-2xl animate-pulse" />)}</div>
    </div>
  );

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-bold tracking-tight">Stores</h1>
          <p className="text-sm text-[hsl(var(--text-tertiary))]">{stores.length} total · manage status</p>
        </div>
      </div>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {[["all", "All"], ["true", "Open"], ["false", "Closed"]].map(([id, l]) => (
          <button key={id} onClick={() => setStatusFilter(id)}
            className={`press shrink-0 px-3.5 h-9 rounded-full text-sm font-medium ${statusFilter === id ? "bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]" : "bg-[hsl(var(--muted))] text-[hsl(var(--text-secondary))]"}`}>
            {l}
          </button>
        ))}
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((s) => (
          <div key={s.id} className="card-soft rounded-2xl p-4">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="text-sm font-semibold">{s.name}</h3>
                <p className="text-xs text-[hsl(var(--text-tertiary))]">{s.tag}</p>
              </div>
              <button className="press w-8 h-8 rounded-full grid place-items-center bg-[hsl(var(--muted))]"><MoreVertical className="w-4 h-4" /></button>
            </div>
            <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-secondary))]">
              <span className="inline-flex items-center gap-0.5 font-medium"><Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {s.rating || "—"}</span>
              {s.eta && <span className="inline-flex items-center gap-0.5"><Clock className="w-3 h-3" /> {s.eta}</span>}
            </div>
            <div className="flex items-center justify-between mt-3">
              <Pill tone={s.isOpen ? "success" : "neutral"}>{s.isOpen ? "Open" : "Closed"}</Pill>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
