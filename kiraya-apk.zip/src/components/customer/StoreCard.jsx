import React from "react";
import { Link } from "react-router-dom";
import { Star, Clock, MapPin, BadgePercent } from "lucide-react";
import { StoreMedia } from "@/components/customer/Media";
import { Pill } from "@/components/customer/StatusBadge";

export default function StoreCard({ store }) {
  return (
    <Link to={`/store/${store.id}`} className="block card-soft rounded-2xl overflow-hidden press group">
      <div className="relative">
        <StoreMedia src={store.image} category={store.category} label={store.name} className="w-full h-36" />
        {!store.isOpen && (
          <div className="absolute inset-0 bg-black/45 backdrop-blur-[1px] flex items-end p-3">
            <span className="text-white text-xs font-medium">Currently closed</span>
          </div>
        )}
        {store.isBusy && store.isOpen && (
          <span className="absolute top-2 left-2"><Pill tone="warning">Busy · longer wait</Pill></span>
        )}
        {store.offer && (
          <span className="absolute bottom-2 left-2 inline-flex items-center gap-1 px-2 py-1 rounded-full text-[11px] font-semibold bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))]">
            <BadgePercent className="w-3 h-3" /> {store.offer}
          </span>
        )}
      </div>
      <div className="p-3">
        <h3 className="text-sm font-semibold text-[hsl(var(--text-primary))] line-clamp-1">{store.name}</h3>
        <p className="text-xs text-[hsl(var(--text-tertiary))] line-clamp-1 mt-0.5">{store.tag}</p>
        <div className="flex items-center gap-3 mt-2 text-xs text-[hsl(var(--text-secondary))]">
          <span className="inline-flex items-center gap-0.5 font-medium text-[hsl(var(--text-primary))]">
            <Star className="w-3 h-3 fill-[hsl(var(--warning))] text-[hsl(var(--warning))]" /> {store.rating || "—"}
          </span>
          {store.eta && <span className="inline-flex items-center gap-0.5"><Clock className="w-3 h-3" /> {store.eta}</span>}
          {store.distance && <span className="inline-flex items-center gap-0.5"><MapPin className="w-3 h-3" /> {store.distance}</span>}
        </div>
      </div>
    </Link>
  );
}
