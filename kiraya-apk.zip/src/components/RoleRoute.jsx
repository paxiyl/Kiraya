import React from "react";
import { Navigate, Outlet } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

const Spinner = () => (
  <div className="fixed inset-0 grid place-items-center">
    <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin" />
  </div>
);

// Guards a panel by user role stored in Firestore profile.
export default function RoleRoute({ allow = [] }) {
  const { profile, isLoadingAuth, authChecked } = useAuth();

  if (isLoadingAuth || !authChecked) return <Spinner />;

  const role = profile?.role || "customer";
  if (!allow.includes(role)) return <Navigate to="/" replace />;
  return <Outlet />;
}
